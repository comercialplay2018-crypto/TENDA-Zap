import { Cable, MessageCircle, Mic, Receipt, Store } from "lucide-react";
import { createFileRoute } from "@tanstack/react-router";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Desk } from "@/components/balcao/desk";
import { Welcome } from "@/components/balcao/welcome";

export const Route = createFileRoute("/")({ component: Home });

const TABS = [
  { label: "Conversas", icon: MessageCircle },
  { label: "Prova", icon: Mic },
  { label: "Loja", icon: Store },
  { label: "Pix", icon: Receipt },
  { label: "Ligar", icon: Cable },
];

function Home() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <Opening />;
  if (!user) return <Welcome />;
  return <Desk />;
}

function Opening() {
  return (
    <div className="min-h-screen bg-bg text-ink">
      <div className="mx-auto flex min-h-screen w-full max-w-xl flex-col px-4 pb-24 pt-5">
        <p className="text-sm font-medium text-pine">WhatsApp do comércio</p>
        <h1 className="font-display text-4xl">Balcão</h1>
        <p className="mt-2 text-sm leading-6 text-muted">Abrindo o balcão…</p>
        <section className="mt-5 rounded-2xl border border-line bg-surface p-4">
          <h2 className="font-display text-xl">O que entra aqui</h2>
          <p className="mt-2 text-sm leading-6">
            Produtos, horário, promoção relâmpago, áudio, foto e comprovante de Pix.
          </p>
        </section>
      </div>
      <nav className="fixed inset-x-0 bottom-0 border-t border-line bg-surface">
        <div className="mx-auto grid max-w-xl grid-cols-5">
          {TABS.map((item) => {
            const Icon = item.icon;
            return (
              <div key={item.label} className="flex min-h-16 flex-col items-center justify-center gap-1 text-muted">
                <Icon size={20} strokeWidth={1.75} />
                <span className="text-xs">{item.label}</span>
              </div>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
