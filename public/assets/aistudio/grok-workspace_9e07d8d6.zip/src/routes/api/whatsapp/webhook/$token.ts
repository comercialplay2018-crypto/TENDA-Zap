import { createFileRoute } from "@tanstack/react-router";

function tokenFrom(request: Request): string {
  const parts = new URL(request.url).pathname.split("/").filter(Boolean);
  const index = parts.lastIndexOf("webhook");
  return index >= 0 ? decodeURIComponent(parts[index + 1] ?? "") : "";
}

export const Route = createFileRoute("/api/whatsapp/webhook/$token")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const token = tokenFrom(request);
        const url = new URL(request.url);
        const mode = url.searchParams.get("hub.mode");
        const verify = url.searchParams.get("hub.verify_token");
        const challenge = url.searchParams.get("hub.challenge") ?? "";
        const { userIdByVerifyToken, loadSecrets } = await import("@/lib/balcao/repo.server");
        const userId = await userIdByVerifyToken(token);
        if (!userId || mode !== "subscribe" || verify !== token) {
          return new Response("forbidden", { status: 403 });
        }
        const secrets = await loadSecrets(userId);
        if (!secrets || secrets.verifyToken !== token) return new Response("forbidden", { status: 403 });
        return new Response(challenge, { headers: { "Content-Type": "text/plain" } });
      },
      POST: async ({ request }) => {
        const token = tokenFrom(request);
        const raw = await request.text();
        const { userIdByVerifyToken, loadSecrets } = await import("@/lib/balcao/repo.server");
        const { verifyMetaSignature, ingestWebhook } = await import("@/lib/balcao/flow.server");
        const userId = await userIdByVerifyToken(token);
        if (!userId) return new Response("forbidden", { status: 403 });
        const secrets = await loadSecrets(userId);
        if (!secrets) return new Response("forbidden", { status: 403 });
        const header = request.headers.get("x-hub-signature-256");
        if (!verifyMetaSignature(raw, header, secrets.appSecret)) {
          return new Response("forbidden", { status: 403 });
        }
        try {
          const payload = raw ? (JSON.parse(raw) as unknown) : {};
          await ingestWebhook(userId, payload);
        } catch (error) {
          console.error("webhook", error instanceof Error ? error.message : "fail");
        }
        return new Response("ok");
      },
    },
  },
});
