import { useEffect } from "react";
import { claimPrintFn, failPrintFn, markPrintFn, releaseStuckPrintsFn, returnPrintFn } from "@/lib/balcao/fns";

const KEY = "balcao-auto-print";
const AGENT = "http://127.0.0.1:3921";

export function autoPrintEnabled(): boolean {
  try {
    return localStorage.getItem(KEY) !== "0";
  } catch {
    return true;
  }
}

export function setAutoPrint(on: boolean): void {
  localStorage.setItem(KEY, on ? "1" : "0");
}

export type LocalPrinters = { online: boolean; printer: string; printers: string[] };

export async function localPrinters(): Promise<LocalPrinters> {
  try {
    const health = await fetch(`${AGENT}/health`, { signal: AbortSignal.timeout(1500) });
    if (!health.ok) return { online: false, printer: "", printers: [] };
    const body = (await health.json()) as { printer?: string };
    const listed = await fetch(`${AGENT}/printers`, { signal: AbortSignal.timeout(1500) });
    const printers = listed.ok ? (((await listed.json()) as { printers?: string[] }).printers ?? []) : [];
    return { online: true, printer: body.printer || "", printers: Array.isArray(printers) ? printers : [] };
  } catch {
    return { online: false, printer: "", printers: [] };
  }
}

export async function chooseLocalPrinter(name: string): Promise<void> {
  await fetch(`${AGENT}/printer`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name }),
  });
}

export async function testLocalPrinter(): Promise<string> {
  try {
    const res = await fetch(`${AGENT}/test`, { method: "POST", signal: AbortSignal.timeout(40000) });
    const body = (await res.json().catch(() => ({}))) as { error?: string };
    if (!res.ok) return body.error || "A impressora não aceitou o teste.";
    return "Folha de teste enviada. Olhe a Epson.";
  } catch {
    return "O programa da impressora não está aberto neste computador.";
  }
}

function withRealMime(payload: string): string {
  const comma = payload.indexOf(",");
  if (comma < 0) return payload;
  let head = "";
  try {
    head = atob(payload.slice(comma + 1, comma + 24));
  } catch {
    return payload;
  }
  const byte = (index: number) => head.charCodeAt(index) || 0;
  let mime = "image/jpeg";
  if (byte(0) === 0x89 && byte(1) === 0x50) mime = "image/png";
  else if (head.startsWith("RIFF") && head.slice(8, 12) === "WEBP") mime = "image/webp";
  else if (head.startsWith("GIF")) mime = "image/gif";
  return `data:${mime};base64,${payload.slice(comma + 1)}`;
}

async function asJpeg(payload: string): Promise<string> {
  try {
    const image = new Image();
    image.src = withRealMime(payload);
    await image.decode();
    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth || image.width;
    canvas.height = image.naturalHeight || image.height;
    const pen = canvas.getContext("2d");
    if (!pen || canvas.width < 1 || canvas.height < 1) return payload;
    pen.fillStyle = "#fff";
    pen.fillRect(0, 0, canvas.width, canvas.height);
    pen.drawImage(image, 0, 0);
    return canvas.toDataURL("image/jpeg", 0.92);
  } catch {
    return payload;
  }
}

async function sendToAgent(payload: string, copies: number): Promise<"printed" | "offline" | string> {
  try {
    const dataUrl = await asJpeg(payload);
    const res = await fetch(`${AGENT}/print`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dataUrl, copies }),
      signal: AbortSignal.timeout(copies > 1 ? 120000 : 40000),
    });
    const body = (await res.json().catch(() => ({}))) as { error?: string };
    if (!res.ok) return body.error || "A impressora recusou o arquivo.";
    return "printed";
  } catch {
    return "offline";
  }
}

export function AutoPrint() {
  useEffect(() => {
    let stop = false;
    let busy = false;
    let booted = false;
    let waitUntil = 0;
    const tick = async () => {
      if (stop || busy || Date.now() < waitUntil || !autoPrintEnabled()) return;
      busy = true;
      try {
        if (!booted) {
          await releaseStuckPrintsFn();
          booted = true;
        }
        const job = await claimPrintFn();
        if (!job?.payload) return;
        window.dispatchEvent(new CustomEvent("balcao-print", { detail: "Mandando o documento para a Epson…" }));
        const sent = await sendToAgent(job.payload, job.copies || 1);
        if (sent === "printed") {
          await markPrintFn({ data: job.id });
          window.dispatchEvent(new CustomEvent("balcao-print", { detail: "Papel enviado para a impressora deste computador." }));
          return;
        }
        if (sent === "offline") {
          await returnPrintFn({ data: job.id });
          waitUntil = Date.now() + 12000;
        } else {
          await failPrintFn({ data: job.id });
        }
        window.dispatchEvent(
          new CustomEvent("balcao-print", {
            detail:
              sent === "offline"
                ? "O programa da impressora não está aberto. Dê dois cliques em Iniciar-Balcao e deixe a janela aberta."
                : sent,
          }),
        );
      } catch {
        waitUntil = Date.now() + 8000;
        window.dispatchEvent(
          new CustomEvent("balcao-print", { detail: "O documento não saiu daqui para o programa da impressora." }),
        );
      } finally {
        busy = false;
      }
    };
    void tick();
    const id = window.setInterval(() => void tick(), 2000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, []);
  return null;
}
