import type { ChatMessage } from "@/lib/balcao/types";
import { formatStamp } from "@/lib/balcao/time";

const KIND: Record<string, string> = {
  audio: "Áudio",
  image: "Foto",
  pdf: "PDF",
  nota: "Nota",
};

export function Bubbles({ messages, timeZone }: { messages: ChatMessage[]; timeZone: string }) {
  if (messages.length === 0) {
    return <p className="text-sm leading-6 text-muted">Nada por aqui ainda.</p>;
  }
  return (
    <div className="flex flex-col gap-2">
      {messages.map((message) => {
        const note = message.kind === "nota";
        const mine = message.direction === "out" && !note;
        const label = KIND[message.kind];
        return (
          <div key={message.id} className={mine ? "ml-8" : note ? "" : "mr-8"}>
            <div
              className={
                note
                  ? "text-xs leading-5 text-warn"
                  : mine
                    ? "rounded-2xl rounded-tr-md bg-moss px-3 py-2 text-sm leading-6 text-ink"
                    : "rounded-2xl rounded-tl-md border border-line bg-surface px-3 py-2 text-sm leading-6 text-ink"
              }
            >
              {label && !note ? <p className="mb-1 text-xs font-medium text-muted">{label}</p> : null}
              <p className="whitespace-pre-wrap">{message.body}</p>
            </div>
            {!note ? <p className="mt-1 text-xs text-muted">{formatStamp(message.createdAt, timeZone)}</p> : null}
          </div>
        );
      })}
    </div>
  );
}
