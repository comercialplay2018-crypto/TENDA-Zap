import { useEffect, useState } from "react";
import { Cable, MessageCircle, Mic, Receipt, Store } from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { getDesk, getReceipts, holdWaFn, setBotFn } from "@/lib/balcao/fns";
import { clockIn, openState } from "@/lib/balcao/time";
import type { Desk as DeskData, ReceiptRow } from "@/lib/balcao/types";
import { Inbox } from "./inbox";
import { AutoPrint } from "./auto-print";
import { Ligar } from "./ligar";
import { Loja } from "./loja";
import { PixPanel } from "./pix-panel";
import { Prova } from "./prova";

type Tab = "conversas" | "prova" | "loja" | "pix" | "ligar";

const TABS: { id: Tab; label: string; icon: typeof Store }[] = [
  { id: "conversas", label: "Conversas", icon: MessageCircle },
  { id: "prova", label: "Prova", icon: Mic },
  { id: "loja", label: "Loja", icon: Store },
  { id: "pix", label: "Pix", icon: Receipt },
  { id: "ligar", label: "Ligar", icon: Cable },
];

export function Desk() {
  const [desk, setDesk] = useState<DeskData | null>(null);
  const [receipts, setReceipts] = useState<ReceiptRow[]>([]);
  const [tab, setTab] = useState<Tab>("loja");
  const [openId, setOpenId] = useState<number | null>(null);
  const [err, setErr] = useState("");
  const [now, setNow] = useState(() => new Date());

  async function reload() {
    try {
      const [next, pix] = await Promise.all([getDesk(), getReceipts()]);
      setDesk(next);
      setReceipts(pix);
      setErr("");
    } catch (error) {
      setErr(error instanceof Error ? error.message : "Não carregou.");
    }
  }

  useEffect(() => {
    void reload();
    const clock = window.setInterval(() => setNow(new Date()), 30000);
    return () => window.clearInterval(clock);
  }, []);

  useEffect(() => {
    let stop = false;
    const loop = async () => {
      while (!stop) {
        try {
          const started = Date.now();
          await holdWaFn();
          if (Date.now() - started < 5000) await new Promise((resolve) => setTimeout(resolve, 3000));
        } catch {
          await new Promise((resolve) => setTimeout(resolve, 2000));
        }
      }
    };
    void loop();
    return () => {
      stop = true;
    };
  }, []);

  const state = desk ? openState(clockIn(desk.shop.timezone, now), desk.hours, desk.exceptions) : null;
  const pending = receipts.filter((row) => row.status === "liberado").length;

  return (
    <div className="min-h-screen bg-bg text-ink">
      <AutoPrint />
      <div className="mx-auto flex min-h-screen w-full max-w-xl flex-col px-4 pb-24 pt-5">
        <header className="flex items-start justify-between gap-3">
          <div>
            <p className="text-sm font-medium text-pine">{desk?.shop.name || "Sua loja"}</p>
            <h1 className="font-display text-4xl">Balcão</h1>
            {state ? (
              <p className={state.open ? "mt-1 text-sm text-pine" : "mt-1 text-sm text-clay"}>{state.reason}</p>
            ) : null}
          </div>
          <div className="flex flex-col items-end gap-2">
            <UserButton />
            {desk ? (
              <button
                type="button"
                className={
                  desk.shop.botEnabled
                    ? "min-h-11 rounded-full bg-pine px-3 text-sm text-pine-ink"
                    : "min-h-11 rounded-full bg-line px-3 text-sm text-ink"
                }
                onClick={() =>
                  void setBotFn({ data: !desk.shop.botEnabled }).then(reload)
                }
              >
                {desk.shop.botEnabled ? "Atendendo" : "Pausado"}
              </button>
            ) : null}
          </div>
        </header>

        <a
          className="mt-4 inline-flex min-h-11 items-center justify-center rounded-xl border border-line bg-surface px-4 text-sm font-medium text-ink"
          href="/impressora/Iniciar-Balcao.bat"
          download
        >
          Baixar programa da impressora
        </a>

        <div className="mt-5 flex-1">
          {!desk ? <div className="h-40 animate-pulse rounded-2xl bg-line" /> : null}
          {err ? <p className="text-sm text-warn">{err}</p> : null}
          {desk && tab === "conversas" ? (
            <Inbox
              timeZone={desk.shop.timezone}
              openId={openId}
              onOpen={(id) => {
                setOpenId(id);
                setTab("conversas");
              }}
            />
          ) : null}
          {desk && tab === "prova" ? <Prova timeZone={desk.shop.timezone} /> : null}
          {desk && tab === "loja" ? <Loja desk={desk} onChange={reload} /> : null}
          {desk && tab === "pix" ? (
            <PixPanel
              rows={receipts}
              onChange={reload}
              onOpen={(id) => {
                setOpenId(id);
                setTab("conversas");
              }}
            />
          ) : null}
          {desk && tab === "ligar" ? <Ligar desk={desk} onChange={reload} /> : null}
        </div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 border-t border-line bg-surface">
        <div className="mx-auto grid max-w-xl grid-cols-5">
          {TABS.map((item) => {
            const Icon = item.icon;
            const on = tab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={on ? "flex min-h-16 flex-col items-center justify-center gap-1 text-pine" : "flex min-h-16 flex-col items-center justify-center gap-1 text-muted"}
              >
                <span className="relative">
                  <Icon size={20} strokeWidth={1.75} />
                  {item.id === "pix" && pending > 0 ? (
                    <span className="absolute -right-2 -top-2 h-2.5 w-2.5 rounded-full bg-clay" />
                  ) : null}
                </span>
                <span className="text-xs">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
