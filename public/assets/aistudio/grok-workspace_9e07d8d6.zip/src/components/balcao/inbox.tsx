import { useEffect, useState } from "react";
import { getMessages, getOfficeFn, getThreads, humanSendFn, setPausedFn } from "@/lib/balcao/fns";
import { formatStamp } from "@/lib/balcao/time";
import type { ChatMessage, ThreadSummary } from "@/lib/balcao/types";
import { Bubbles } from "./bubbles";
import { Oficina } from "./oficina";
import { btnGhost, btnPrimary, inputClass } from "./ui";

export function Inbox({
  timeZone,
  openId,
  onOpen,
}: {
  timeZone: string;
  openId: number | null;
  onOpen: (id: number | null) => void;
}) {
  const [threads, setThreads] = useState<ThreadSummary[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState("");
  const [err, setErr] = useState("");
  const [pending, setPending] = useState(0);

  async function refreshThreads() {
    setThreads(await getThreads());
  }

  useEffect(() => {
    let stop = false;
    const tick = () => {
      void getThreads().then((rows) => {
        if (!stop) setThreads(rows);
      });
      void getOfficeFn({ data: 0 })
        .then((board) => {
          if (!stop) setPending(board.pending);
        })
        .catch(() => undefined);
    };
    tick();
    const id = window.setInterval(tick, 8000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, []);

  useEffect(() => {
    if (openId == null) return;
    let stop = false;
    const tick = () => {
      void getMessages({ data: openId }).then((rows) => {
        if (!stop) setMessages(rows);
      });
    };
    tick();
    const id = window.setInterval(tick, 5000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [openId]);

  const current = threads.find((thread) => thread.id === openId);

  if (openId != null && current) {
    return (
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between gap-2">
          <button type="button" className={btnGhost} onClick={() => onOpen(null)}>
            Voltar
          </button>
          <button
            type="button"
            className={btnGhost}
            onClick={() => void setPausedFn({ data: { contactId: current.id, paused: !current.botPaused } }).then(refreshThreads)}
          >
            {current.botPaused ? "Devolver ao atendente" : "Eu assumo"}
          </button>
        </div>
        <div>
          <h2 className="font-display text-2xl">{current.name}</h2>
          <p className="text-sm text-muted">{current.waId}</p>
        </div>
        <Oficina contactId={current.id} onNote={setErr} />
        <Bubbles messages={messages} timeZone={timeZone} />
        <textarea className={inputClass} rows={2} value={text} placeholder="Responder você mesmo" onChange={(e) => setText(e.target.value)} />
        <button
          type="button"
          className={btnPrimary}
          onClick={() =>
            void humanSendFn({ data: { contactId: current.id, text } }).then(async (res) => {
              if (!res.ok) setErr(res.error);
              else {
                setText("");
                setErr("");
                setMessages(await getMessages({ data: current.id }));
              }
            })
          }
        >
          Enviar no WhatsApp
        </button>
        {err ? <p className="text-sm text-warn">{err}</p> : null}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      {pending > 0 ? (
        <p className="text-sm leading-6 text-muted">
          {pending === 1 ? "Tem 1 arquivo na fila de impressão." : `Tem ${pending} arquivos na fila de impressão.`} Abra a conversa e toque em Imprimir.
        </p>
      ) : null}
      {threads.length === 0 ? (
        <p className="text-sm leading-6 text-muted">
          Quando alguém falar no número ligado, a conversa aparece aqui. Pra treinar o jeito de falar agora, abra Prova.
        </p>
      ) : null}
      {threads.map((thread) => (
        <button
          key={thread.id}
          type="button"
          onClick={() => onOpen(thread.id)}
          className="rounded-2xl border border-line bg-surface px-4 py-3 text-left"
        >
          <span className="flex items-center justify-between gap-2">
            <span className="font-medium">{thread.name}</span>
            <span className="text-xs text-muted">{formatStamp(thread.updatedAt, timeZone)}</span>
          </span>
          <span className="mt-1 block truncate text-sm text-muted">{thread.preview || "Sem texto"}</span>
          {thread.botPaused ? <span className="mt-1 block text-xs text-clay">Você assumiu</span> : null}
        </button>
      ))}
    </div>
  );
}
