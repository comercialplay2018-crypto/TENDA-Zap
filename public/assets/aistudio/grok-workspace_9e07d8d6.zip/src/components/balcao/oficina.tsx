import { useEffect, useState } from "react";
import {
  getOfficeFn,
  markPrintFn,
  resumeFileFn,
  resumeFromChatFn,
  saleFromChatFn,
  sendResumeFn,
} from "@/lib/balcao/fns";
import type { PrintJob, ShopJob } from "@/lib/balcao/types";
import { autoPrintEnabled, chooseLocalPrinter, localPrinters, setAutoPrint, testLocalPrinter } from "./auto-print";
import { btnGhost, btnPrimary } from "./ui";

function openPrint(payload: string, title: string): boolean {
  const win = window.open("", "_blank", "noopener,width=820,height=900");
  if (!win) return false;
  const safe = title.replace(/[&<>"]/g, "");
  const isPdf = payload.startsWith("data:application/pdf");
  const body = isPdf
    ? `<iframe src="${payload}" style="border:0;width:100%;height:100vh"></iframe>`
    : `<img alt="" src="${payload}" style="max-width:100%" />`;
  win.document.write(`<!doctype html><title>${safe}</title><body style="margin:0">${body}<script>setTimeout(function(){window.focus();window.print()},700)<\/script></body>`);
  win.document.close();
  return true;
}

export function Oficina({
  contactId,
  onNote,
}: {
  contactId: number;
  onNote: (text: string) => void;
}) {
  const [prints, setPrints] = useState<PrintJob[]>([]);
  const [jobs, setJobs] = useState<ShopJob[]>([]);
  const [busy, setBusy] = useState("");
  const [alone, setAlone] = useState(true);
  const [printer, setPrinter] = useState("");
  const [online, setOnline] = useState(false);
  const [printers, setPrinters] = useState<string[]>([]);
  const [chosen, setChosen] = useState("");

  useEffect(() => {
    setAlone(autoPrintEnabled());
    const onPrint = (event: Event) => {
      const detail = (event as CustomEvent<string>).detail;
      if (detail) setPrinter(detail);
    };
    window.addEventListener("balcao-print", onPrint);
    return () => window.removeEventListener("balcao-print", onPrint);
  }, []);

  useEffect(() => {
    let stop = false;
    const look = async () => {
      const link = await localPrinters();
      if (stop) return;
      setOnline(link.online);
      setPrinters(link.printers);
      setChosen(link.printer);
    };
    void look();
    const id = window.setInterval(() => void look(), 4000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, []);

  async function load() {
    const board = await getOfficeFn({ data: contactId });
    setPrints(board.prints);
    setJobs(board.jobs);
  }

  useEffect(() => {
    let stop = false;
    void getOfficeFn({ data: contactId })
      .then((board) => {
        if (stop) return;
        setPrints(board.prints);
        setJobs(board.jobs);
      })
      .catch(() => undefined);
    return () => {
      stop = true;
    };
  }, [contactId]);

  return (
    <div className="rounded-2xl border border-line bg-surface p-3">
      <p className="text-sm font-medium text-ink">Balcão da loja</p>
      <p className="mt-1 text-sm leading-5 text-muted">
        O currículo segue no WhatsApp para a pessoa ver. A impressão só começa depois que ela aprovar. Quem imprime é o programa neste computador, não o Chrome.
      </p>
      <p className={online ? "mt-2 text-sm text-pine" : "mt-2 text-sm text-clay"}>
        {online ? `Programa ligado. Impressora: ${chosen || "padrão do Windows"}` : "Programa da impressora fechado neste computador."}
      </p>
      {online && printers.length > 0 ? (
        <select
          className="mt-2 min-h-11 w-full rounded-xl border border-line bg-surface px-3 text-sm"
          value={chosen}
          onChange={(event) => {
            const name = event.target.value;
            setChosen(name);
            void chooseLocalPrinter(name);
          }}
        >
          {printers.map((name) => (
            <option key={name} value={name}>
              {name}
            </option>
          ))}
        </select>
      ) : null}
      <label className="mt-3 flex items-center gap-2 text-sm text-ink">
        <input
          type="checkbox"
          checked={alone}
          onChange={(event) => {
            setAlone(event.target.checked);
            setAutoPrint(event.target.checked);
          }}
        />
        Imprimir sozinho enquanto esta tela estiver aberta
      </label>
      <div className="mt-3 flex flex-wrap gap-2">
        <a className={btnGhost} href="/impressora/Iniciar-Balcao.bat" download>
          Baixar programa
        </a>
        <button
          type="button"
          className={btnGhost}
          onClick={() => {
            void testLocalPrinter().then(setPrinter);
          }}
        >
          Testar impressora
        </button>
      </div>
      {printer ? <p className="mt-2 text-sm leading-5 text-ink">{printer}</p> : null}
      <div className="mt-3 flex flex-wrap gap-2">
        <button
          type="button"
          className={btnGhost}
          disabled={busy !== ""}
          onClick={() => {
            setBusy("curriculo");
            void resumeFromChatFn({ data: contactId }).then((res) => {
              setBusy("");
              onNote(res.ok ? res.note : res.error);
              void load();
            });
          }}
        >
          {busy === "curriculo" ? "Montando…" : "Montar currículo"}
        </button>
        <button
          type="button"
          className={btnGhost}
          disabled={busy !== ""}
          onClick={() => {
            setBusy("venda");
            void saleFromChatFn({ data: contactId }).then((res) => {
              setBusy("");
              onNote(res.ok ? res.note : res.error);
              void load();
            });
          }}
        >
          {busy === "venda" ? "Lançando…" : "Lançar no PDV"}
        </button>
      </div>
      {prints.filter((job) => job.payload).map((job) => (
        <div key={job.id} className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm text-ink">
            {job.title}{" "}
            {job.status === "impresso"
              ? "· já saiu"
              : job.status === "aguardando"
                ? "· esperando o cliente"
                : job.status === "falhou"
                  ? "· não abriu"
                  : "· saindo agora"}
          </p>
          <button
            type="button"
            className={btnGhost}
            onClick={() => {
              if (!openPrint(job.payload, job.title)) {
                onNote("O navegador bloqueou a janela. Libere pop-up neste computador.");
                return;
              }
              void markPrintFn({ data: job.id }).then(load);
            }}
          >
            Imprimir de novo
          </button>
        </div>
      ))}
      {jobs.map((job) => (
        <div key={job.id} className="mt-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm text-ink">
            {job.kind === "venda" ? "PDV" : "Currículo"} · {job.title}
          </p>
          {job.kind === "curriculo" && job.hasFile ? (
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                className={btnGhost}
                onClick={() =>
                  void (async () => {
                    const res = await resumeFileFn({ data: job.id });
                    if (!res.ok) {
                      onNote(res.error);
                      return;
                    }
                    const blob = await fetch(res.payload).then((file) => file.blob());
                    window.open(URL.createObjectURL(blob), "_blank", "noopener");
                  })()
                }
              >
                Ver PDF
              </button>
              <button
                type="button"
                className={btnGhost}
                onClick={() =>
                  void resumeFileFn({ data: job.id }).then((res) => {
                    if (!res.ok) onNote(res.error);
                    else if (!openPrint(res.payload, res.title)) onNote("Libere pop-up para imprimir.");
                  })
                }
              >
                Imprimir PDF
              </button>
              <button
                type="button"
                className={btnGhost}
                onClick={() =>
                  void sendResumeFn({ data: job.id }).then((res) => {
                    onNote(res.ok ? "PDF enviado no WhatsApp." : res.error);
                  })
                }
              >
                Enviar no Zap
              </button>
            </div>
          ) : null}
        </div>
      ))}
    </div>
  );
}
