import type { ReactNode } from "react";

export const inputClass =
  "w-full rounded-xl border border-line bg-surface px-3 py-3 text-base text-ink outline-none focus:border-pine";

export const btnPrimary =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-pine px-4 text-sm font-medium text-pine-ink disabled:opacity-50";

export const btnGhost =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-4 text-sm font-medium text-ink disabled:opacity-50";

export const btnClay =
  "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-clay px-4 text-sm font-medium text-clay-ink disabled:opacity-50";

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm text-muted">{label}</span>
      {children}
    </label>
  );
}

export function Card({ children, title, hint }: { children: ReactNode; title?: string; hint?: string }) {
  return (
    <section className="rounded-2xl border border-line bg-surface p-4">
      {title ? <h2 className="font-display text-xl text-ink">{title}</h2> : null}
      {hint ? <p className="mt-1 text-sm leading-6 text-muted">{hint}</p> : null}
      <div className={title ? "mt-4 flex flex-col gap-3" : "flex flex-col gap-3"}>{children}</div>
    </section>
  );
}

export function Note({ children }: { children: ReactNode }) {
  return <p className="text-sm leading-6 text-warn">{children}</p>;
}
