import { useEffect, useState } from "react";
import { getWaLinkFn, saveConnectionFn, saveShopFn, startWaLinkFn, stopWaLinkFn, testSendFn } from "@/lib/balcao/fns";
import type { Desk, WaLinkStatus } from "@/lib/balcao/types";
import { Card, Field, Note, btnGhost, btnPrimary, inputClass } from "./ui";

export function Ligar({ desk, onChange }: { desk: Desk; onChange: () => Promise<void> }) {
  const [phoneNumberId, setPhoneNumberId] = useState(desk.connection.phoneNumberId);
  const [displayPhone, setDisplayPhone] = useState(desk.connection.displayPhone);
  const [accessToken, setAccessToken] = useState("");
  const [appSecret, setAppSecret] = useState("");
  const [pixKey, setPixKey] = useState(desk.shop.pixKey);
  const [pixFavorecido, setPixFavorecido] = useState(desk.shop.pixFavorecido);
  const [pixBanco, setPixBanco] = useState(desk.shop.pixBanco);
  const [to, setTo] = useState("");
  const [text, setText] = useState("oi, teste do balcão");
  const [msg, setMsg] = useState("");
  const [copied, setCopied] = useState(false);
  const [link, setLink] = useState<WaLinkStatus | null>(null);
  const [linking, setLinking] = useState(false);
  const path = `/api/whatsapp/webhook/${desk.connection.verifyToken}`;
  const full = typeof window !== "undefined" ? `${window.location.origin}${path}` : path;

  useEffect(() => {
    let stop = false;
    async function tick() {
      try {
        const next = await getWaLinkFn();
        if (!stop) setLink(next);
      } catch (error) {
        if (!stop) setMsg(error instanceof Error ? error.message : "Não li o WhatsApp.");
      }
    }
    void tick();
    const id = window.setInterval(() => void tick(), 2000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, []);

  async function saveLink() {
    const res = await saveConnectionFn({
      data: { phoneNumberId, displayPhone, accessToken, appSecret, clearSecret: false },
    });
    if (!res.ok) setMsg(res.error);
    else {
      setAccessToken("");
      setAppSecret("");
      setMsg("Ligação salva.");
      await onChange();
    }
  }

  async function savePix() {
    const res = await saveShopFn({
      data: { ...desk.shop, pixKey, pixFavorecido, pixBanco },
    });
    if (!res.ok) setMsg(res.error);
    else {
      setMsg("Pix salvo.");
      await onChange();
    }
  }

  async function showQr() {
    setLinking(true);
    try {
      setLink(await startWaLinkFn());
    } catch (error) {
      setMsg(error instanceof Error ? error.message : "Não gerou o QR.");
    } finally {
      setLinking(false);
    }
  }

  async function disconnect() {
    setLinking(true);
    try {
      setLink(await stopWaLinkFn());
    } catch (error) {
      setMsg(error instanceof Error ? error.message : "Não desligou.");
    } finally {
      setLinking(false);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <Card
        title="WhatsApp neste celular"
        hint="O Balcão entra como aparelho conectado. Você continua usando o WhatsApp no telefone, e o atendente responde sozinho com a mesma conversa da aba Prova."
      >
        <p className="text-sm leading-6 text-ink">{link?.note || "Ainda não ligado."}</p>
        {link?.qrDataUrl ? (
          <img
            src={link.qrDataUrl}
            alt="QR Code para conectar o WhatsApp"
            className="mx-auto w-56 rounded-xl bg-white p-3"
          />
        ) : null}
        <div className="flex flex-wrap gap-2">
          {link?.status === "open" ? (
            <button type="button" className={btnGhost} disabled={linking} onClick={() => void disconnect()}>
              Desligar
            </button>
          ) : (
            <button
              type="button"
              className={btnPrimary}
              disabled={linking || link?.status === "connecting" || link?.status === "qr"}
              onClick={() => void showQr()}
            >
              {link?.status === "qr" ? "Aguardando a leitura" : linking || link?.status === "connecting" ? "Conectando…" : "Mostrar QR"}
            </button>
          )}
        </div>
        <p className="text-sm leading-6 text-muted">
          A sessão fica neste servidor. Se ele reiniciar, religa sozinho depois do primeiro pareamento. Áudio, foto e PDF seguem o mesmo caminho de sempre.
        </p>
      </Card>
      <Card title="Teste de envio" hint="Com o QR ligado, manda uma frase para um número com DDI.">
        <Field label="Para">
          <input className={inputClass} inputMode="numeric" value={to} placeholder="5591999999999" onChange={(e) => setTo(e.target.value)} />
        </Field>
        <Field label="Texto">
          <input className={inputClass} value={text} onChange={(e) => setText(e.target.value)} />
        </Field>
        <button
          type="button"
          className={btnPrimary}
          onClick={() =>
            void testSendFn({ data: { to, text } }).then((res) => {
              setMsg(res.ok ? "Enviado. Olha o WhatsApp." : res.error);
            })
          }
        >
          Enviar teste
        </button>
      </Card>
      <Card title="Pix que você recebe" hint="O nome tem que ser o do comprovante, do favorecido. É com ele que o atendente libera ou segura.">
        <Field label="Nome do favorecido">
          <input className={inputClass} value={pixFavorecido} onChange={(e) => setPixFavorecido(e.target.value)} />
        </Field>
        <Field label="Banco">
          <input className={inputClass} value={pixBanco} onChange={(e) => setPixBanco(e.target.value)} />
        </Field>
        <Field label="Chave">
          <input className={inputClass} value={pixKey} onChange={(e) => setPixKey(e.target.value)} />
        </Field>
        <button type="button" className={btnPrimary} onClick={() => void savePix()}>
          Salvar Pix
        </button>
      </Card>
      <details className="rounded-2xl border border-line bg-surface p-4">
        <summary className="cursor-pointer text-sm font-medium text-ink">API oficial da Meta, se um dia quiser</summary>
        <div className="mt-4 flex flex-col gap-3">
          <Field label="Identificador do número">
            <input className={inputClass} value={phoneNumberId} onChange={(e) => setPhoneNumberId(e.target.value)} />
          </Field>
          <Field label="Número visível">
            <input className={inputClass} value={displayPhone} placeholder="5591…" onChange={(e) => setDisplayPhone(e.target.value)} />
          </Field>
          <Field label={desk.connection.tokenSet ? `Token (salvo, final ${desk.connection.tokenTail})` : "Token"}>
            <input
              className={inputClass}
              type="password"
              value={accessToken}
              placeholder={desk.connection.tokenSet ? "Em branco mantém o atual" : "Cole o token"}
              onChange={(e) => setAccessToken(e.target.value)}
              autoComplete="off"
            />
          </Field>
          <Field label={desk.connection.secretSet ? "Segredo do app (opcional, já salvo)" : "Segredo do app (opcional)"}>
            <input
              className={inputClass}
              type="password"
              value={appSecret}
              placeholder="Só se for conferir a assinatura"
              onChange={(e) => setAppSecret(e.target.value)}
              autoComplete="off"
            />
          </Field>
          <div className="flex flex-wrap gap-2">
            <button type="button" className={btnPrimary} onClick={() => void saveLink()}>
              Salvar ligação
            </button>
          </div>
          <Field label="Endereço do webhook">
            <input className={inputClass} readOnly value={full} />
          </Field>
          <Field label="Token de verificação">
            <input className={inputClass} readOnly value={desk.connection.verifyToken} />
          </Field>
          <button
            type="button"
            className={btnGhost}
            onClick={() => {
              void navigator.clipboard.writeText(`${full}\n${desk.connection.verifyToken}`).then(() => {
                setCopied(true);
              });
            }}
          >
            {copied ? "Copiado" : "Copiar endereço e token"}
          </button>
        </div>
      </details>
      {msg ? <Note>{msg}</Note> : null}
    </div>
  );
}
