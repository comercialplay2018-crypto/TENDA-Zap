import { setReceiptFn } from "@/lib/balcao/fns";
import { brl, type ReceiptRow } from "@/lib/balcao/types";
import { btnGhost, btnPrimary } from "./ui";

const LABEL: Record<string, string> = {
  liberado: "Liberado — falta o banco",
  duvida: "Segurou",
  recusado: "Segurou",
  conferido: "Conferido no banco",
  nao_caiu: "Não caiu",
};

export function PixPanel({
  rows,
  onChange,
  onOpen,
}: {
  rows: ReceiptRow[];
  onChange: () => Promise<void>;
  onOpen: (contactId: number) => void;
}) {
  const liberados = rows.filter((row) => row.status === "liberado");
  const others = rows.filter((row) => row.status !== "liberado");
  return (
    <div className="flex flex-col gap-4">
      <section className="rounded-2xl border border-line bg-surface p-4">
        <h2 className="font-display text-xl">Fila do banco</h2>
        <p className="mt-1 text-sm leading-6 text-muted">
          O atendente lê data, hora, favorecido, banco e valor. O que ele libera, você confirma no app do banco. Ele nunca diz que o dinheiro já caiu.
        </p>
      </section>
      {rows.length === 0 ? <p className="text-sm text-muted">Nenhum comprovante ainda.</p> : null}
      {[...liberados, ...others].map((row) => (
        <article key={row.id} className="rounded-2xl border border-line bg-surface p-4">
          <p className="text-xs font-medium text-pine">{LABEL[row.status] ?? row.status}</p>
          <p className="font-display mt-1 text-3xl tabular-nums">{row.amountCents != null ? brl(row.amountCents) : "Valor ?"}</p>
          <dl className="mt-3 grid grid-cols-1 gap-1 text-sm leading-6">
            <div>Favorecido: {row.favorecido || "—"}</div>
            <div>Banco: {row.banco || "—"}</div>
            <div>Quando: {row.paidAtText || row.paidDate || "—"}</div>
            <div>Pagador: {row.payerName || "—"}</div>
            <div>Id: {row.e2eId || "—"}</div>
            <div>Cliente: {row.contactName || row.waId}</div>
          </dl>
          <p className="mt-2 text-sm leading-6 text-muted">{row.decision}</p>
          {row.mediaDataUrl ? <img src={row.mediaDataUrl} alt="Comprovante enviado" className="mt-3 max-h-56 rounded-xl border border-line object-contain" /> : null}
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" className={btnPrimary} onClick={() => void setReceiptFn({ data: { id: row.id, status: "conferido" } }).then(onChange)}>
              Conferi no banco
            </button>
            <button type="button" className={btnGhost} onClick={() => void setReceiptFn({ data: { id: row.id, status: "nao_caiu" } }).then(onChange)}>
              Não caiu
            </button>
            {row.contactId ? (
              <button type="button" className={btnGhost} onClick={() => onOpen(row.contactId as number)}>
                Abrir conversa
              </button>
            ) : null}
          </div>
        </article>
      ))}
    </div>
  );
}
