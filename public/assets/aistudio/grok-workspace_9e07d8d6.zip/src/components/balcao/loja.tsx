import { useState } from "react";
import {
  addExceptionFn,
  addNoticeFn,
  addPromoFn,
  deleteExceptionFn,
  deleteNoticeFn,
  deleteProductFn,
  deletePromoFn,
  saveHoursFn,
  saveProductFn,
  saveShopFn,
  setNoticeFn,
  setPromoFn,
} from "@/lib/balcao/fns";
import { promoIsLive } from "@/lib/balcao/time";
import { WEEKDAY_LABELS, TIMEZONES, brl, type Desk, type ProductInput, type Shop, type WeekHours } from "@/lib/balcao/types";
import { Card, Field, Note, btnGhost, btnPrimary, inputClass } from "./ui";

type Slice = "fala" | "produtos" | "horario" | "avisos";

export function Loja({ desk, onChange }: { desk: Desk; onChange: () => Promise<void> }) {
  const [slice, setSlice] = useState<Slice>("fala");
  return (
    <div className="flex flex-col gap-4">
      <div className="flex gap-2 overflow-x-auto">
        {(
          [
            ["fala", "Fala"],
            ["produtos", "Produtos"],
            ["horario", "Horário"],
            ["avisos", "Avisos"],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setSlice(id)}
            className={
              slice === id
                ? "min-h-11 shrink-0 rounded-full bg-ink px-4 text-sm text-surface"
                : "min-h-11 shrink-0 rounded-full border border-line bg-surface px-4 text-sm text-ink"
            }
          >
            {label}
          </button>
        ))}
      </div>
      {slice === "fala" ? <Fala shop={desk.shop} onChange={onChange} /> : null}
      {slice === "produtos" ? <Produtos products={desk.products} onChange={onChange} /> : null}
      {slice === "horario" ? (
        <Horario hours={desk.hours} exceptions={desk.exceptions} onChange={onChange} />
      ) : null}
      {slice === "avisos" ? <Avisos desk={desk} onChange={onChange} /> : null}
    </div>
  );
}

function Fala({ shop, onChange }: { shop: Shop; onChange: () => Promise<void> }) {
  const [form, setForm] = useState(shop);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    setMsg("");
    const res = await saveShopFn({ data: form });
    setBusy(false);
    if (!res.ok) setMsg(res.error);
    else {
      setMsg("Salvo.");
      await onChange();
    }
  }
  return (
    <Card title="Como a loja fala" hint="O atendente usa isso em toda conversa. Sem isso, ele não inventa preço nem horário.">
      <Field label="Nome da loja">
        <input className={inputClass} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
      </Field>
      <Field label="Nome de quem atende">
        <input
          className={inputClass}
          value={form.attendantName}
          placeholder="Pode ficar em branco"
          onChange={(e) => setForm({ ...form, attendantName: e.target.value })}
        />
      </Field>
      <Field label="O que vocês fazem">
        <textarea
          className={inputClass}
          rows={3}
          value={form.about}
          onChange={(e) => setForm({ ...form, about: e.target.value })}
        />
      </Field>
      <Field label="Jeito de falar">
        <textarea
          className={inputClass}
          rows={3}
          value={form.voice}
          onChange={(e) => setForm({ ...form, voice: e.target.value })}
        />
      </Field>
      <Field label="Fuso">
        <select className={inputClass} value={form.timezone} onChange={(e) => setForm({ ...form, timezone: e.target.value })}>
          {TIMEZONES.map((zone) => (
            <option key={zone.id} value={zone.id}>
              {zone.label}
            </option>
          ))}
        </select>
      </Field>
      <button type="button" className={btnPrimary} disabled={busy} onClick={() => void save()}>
        {busy ? "Salvando…" : "Salvar a fala"}
      </button>
      {msg ? <Note>{msg}</Note> : null}
    </Card>
  );
}

function Produtos({ products, onChange }: { products: Desk["products"]; onChange: () => Promise<void> }) {
  const [form, setForm] = useState<ProductInput>({ id: 0, name: "", price: "", unit: "un", details: "", available: true });
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true);
    const res = await saveProductFn({ data: form });
    setBusy(false);
    if (!res.ok) setMsg(res.error);
    else {
      setForm({ id: 0, name: "", price: "", unit: "un", details: "", available: true });
      setMsg("");
      await onChange();
    }
  }
  return (
    <Card title="Produtos" hint="Preço do jeito que você fala: 10 ou 12,50.">
      {products.length === 0 ? <p className="text-sm text-muted">Nenhum produto ainda.</p> : null}
      {products.map((product) => (
        <div key={product.id} className="flex items-start justify-between gap-3 border-b border-line pb-3">
          <div>
            <p className="font-medium">
              {product.name}{" "}
              <span className="tabular-nums text-muted">{brl(product.priceCents)}</span>
            </p>
            <p className="text-sm text-muted">
              {product.unit}
              {product.available ? "" : " · em falta"}
              {product.details ? ` · ${product.details}` : ""}
            </p>
          </div>
          <button
            type="button"
            className="min-h-11 text-sm text-clay"
            onClick={() => void deleteProductFn({ data: product.id }).then(onChange)}
          >
            Tirar
          </button>
        </div>
      ))}
      <Field label="Nome">
        <input className={inputClass} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="Preço">
          <input className={inputClass} inputMode="decimal" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
        </Field>
        <Field label="Unidade">
          <input className={inputClass} value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} />
        </Field>
      </div>
      <Field label="Detalhe">
        <input className={inputClass} value={form.details} onChange={(e) => setForm({ ...form, details: e.target.value })} />
      </Field>
      <button type="button" className={btnPrimary} disabled={busy} onClick={() => void save()}>
        {busy ? "Salvando…" : "Adicionar produto"}
      </button>
      {msg ? <Note>{msg}</Note> : null}
    </Card>
  );
}

function Horario({
  hours,
  exceptions,
  onChange,
}: {
  hours: WeekHours[];
  exceptions: Desk["exceptions"];
  onChange: () => Promise<void>;
}) {
  const [rows, setRows] = useState(hours);
  const [date, setDate] = useState("");
  const [kind, setKind] = useState<"fechado" | "abre_tarde" | "fecha_cedo">("fechado");
  const [atTime, setAtTime] = useState("14:00");
  const [note, setNote] = useState("");
  const [msg, setMsg] = useState("");
  async function saveHours() {
    const res = await saveHoursFn({ data: rows });
    if (!res.ok) setMsg(res.error);
    else {
      setMsg("Horário salvo.");
      await onChange();
    }
  }
  async function addEx() {
    const res = await addExceptionFn({ data: { onDate: date, kind, atTime, note } });
    if (!res.ok) setMsg(res.error);
    else {
      setNote("");
      setMsg("");
      await onChange();
    }
  }
  return (
    <div className="flex flex-col gap-4">
      <Card title="Horário da semana" hint="Domingo começa fechado. Ajuste do seu jeito.">
        {rows.map((row, index) => (
          <div key={row.weekday} className="flex flex-col gap-2 border-b border-line pb-3">
            <p className="text-sm font-medium">{WEEKDAY_LABELS[row.weekday]}</p>
            <button
              type="button"
              className={row.closed ? btnGhost : btnPrimary}
              onClick={() => setRows(rows.map((item, i) => (i === index ? { ...item, closed: !item.closed } : item)))}
            >
              {row.closed ? "Fechado neste dia" : "Abre neste dia"}
            </button>
            {row.closed ? null : (
              <div className="grid grid-cols-2 gap-2">
                <input
                  aria-label={`Abre ${WEEKDAY_LABELS[row.weekday]}`}
                  className={inputClass}
                  type="time"
                  value={row.opens}
                  onChange={(e) => setRows(rows.map((item, i) => (i === index ? { ...item, opens: e.target.value } : item)))}
                />
                <input
                  aria-label={`Fecha ${WEEKDAY_LABELS[row.weekday]}`}
                  className={inputClass}
                  type="time"
                  value={row.closes}
                  onChange={(e) => setRows(rows.map((item, i) => (i === index ? { ...item, closes: e.target.value } : item)))}
                />
              </div>
            )}
          </div>
        ))}
        <button type="button" className={btnPrimary} onClick={() => void saveHours()}>
          Salvar horário
        </button>
      </Card>
      <Card title="Um dia diferente" hint="Fechar o dia, abrir mais tarde ou fechar mais cedo.">
        {exceptions.map((item) => (
          <div key={item.id} className="flex items-start justify-between gap-3">
            <p className="text-sm leading-6">
              {item.onDate.split("-").reverse().join("/")} · {item.kind.replace("_", " ")}
              {item.atTime ? ` ${item.atTime}` : ""}
              {item.note ? ` · ${item.note}` : ""}
            </p>
            <button type="button" className="min-h-11 text-sm text-clay" onClick={() => void deleteExceptionFn({ data: item.id }).then(onChange)}>
              Tirar
            </button>
          </div>
        ))}
        <Field label="Data">
          <input className={inputClass} type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
        <Field label="O que muda">
          <select className={inputClass} value={kind} onChange={(e) => setKind(e.target.value as typeof kind)}>
            <option value="fechado">Não abre</option>
            <option value="abre_tarde">Abre mais tarde</option>
            <option value="fecha_cedo">Fecha mais cedo</option>
          </select>
        </Field>
        {kind !== "fechado" ? (
          <Field label="Horário">
            <input className={inputClass} type="time" value={atTime} onChange={(e) => setAtTime(e.target.value)} />
          </Field>
        ) : null}
        <Field label="Aviso">
          <input className={inputClass} value={note} placeholder="Inventário, jogo, feriado…" onChange={(e) => setNote(e.target.value)} />
        </Field>
        <button type="button" className={btnGhost} onClick={() => void addEx()}>
          Guardar este dia
        </button>
        {msg ? <Note>{msg}</Note> : null}
      </Card>
    </div>
  );
}

function Avisos({ desk, onChange }: { desk: Desk; onChange: () => Promise<void> }) {
  const [body, setBody] = useState("");
  const [title, setTitle] = useState("");
  const [details, setDetails] = useState("");
  const [starts, setStarts] = useState("");
  const [ends, setEnds] = useState("");
  const [msg, setMsg] = useState("");
  return (
    <div className="flex flex-col gap-4">
      <Card title="Promoções relâmpago" hint="Só vale no intervalo. O atendente cita quando a conversa for de preço ou do item, não em toda frase.">
        {desk.promos.map((promo) => (
          <div key={promo.id} className="border-b border-line pb-3">
            <p className="font-medium">{promo.title}</p>
            <p className="text-sm text-muted">{promo.details}</p>
            <p className="text-xs text-muted">{promoIsLive(promo) && promo.active ? "Valendo agora" : promo.active ? "Fora do horário" : "Pausada"}</p>
            <div className="mt-2 flex gap-2">
              <button type="button" className={btnGhost} onClick={() => void setPromoFn({ data: { id: promo.id, active: !promo.active } }).then(onChange)}>
                {promo.active ? "Pausar" : "Ativar"}
              </button>
              <button type="button" className="min-h-11 px-2 text-sm text-clay" onClick={() => void deletePromoFn({ data: promo.id }).then(onChange)}>
                Tirar
              </button>
            </div>
          </div>
        ))}
        <Field label="Nome da promoção">
          <input className={inputClass} value={title} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label="Como é">
          <input className={inputClass} value={details} onChange={(e) => setDetails(e.target.value)} />
        </Field>
        <Field label="Começa">
          <input className={inputClass} type="datetime-local" value={starts} onChange={(e) => setStarts(e.target.value)} />
        </Field>
        <Field label="Termina">
          <input className={inputClass} type="datetime-local" value={ends} onChange={(e) => setEnds(e.target.value)} />
        </Field>
        <button
          type="button"
          className={btnPrimary}
          onClick={() =>
            void addPromoFn({ data: { title, details, startsLocal: starts, endsLocal: ends, active: true } }).then(async (res) => {
              if (!res.ok) setMsg(res.error);
              else {
                setTitle("");
                setDetails("");
                setMsg("");
                await onChange();
              }
            })
          }
        >
          Criar promoção
        </button>
      </Card>
      <Card title="Avisos soltos" hint="Algo que o atendente precisa saber hoje, além do horário.">
        {desk.notices.map((notice) => (
          <div key={notice.id} className="flex items-start justify-between gap-3">
            <p className="text-sm leading-6">{notice.body}</p>
            <div className="flex shrink-0 flex-col">
              <button type="button" className="min-h-11 text-sm" onClick={() => void setNoticeFn({ data: { id: notice.id, active: !notice.active } }).then(onChange)}>
                {notice.active ? "Ativo" : "Pausado"}
              </button>
              <button type="button" className="min-h-11 text-sm text-clay" onClick={() => void deleteNoticeFn({ data: notice.id }).then(onChange)}>
                Tirar
              </button>
            </div>
          </div>
        ))}
        <Field label="Aviso">
          <textarea className={inputClass} rows={2} value={body} onChange={(e) => setBody(e.target.value)} />
        </Field>
        <button
          type="button"
          className={btnGhost}
          onClick={() =>
            void addNoticeFn({ data: body }).then(async (res) => {
              if (!res.ok) setMsg(res.error);
              else {
                setBody("");
                await onChange();
              }
            })
          }
        >
          Guardar aviso
        </button>
        {msg ? <Note>{msg}</Note> : null}
      </Card>
    </div>
  );
}
