import { GROK_PROVIDERS, signIn } from "@/lib/auth/client";

export function Welcome() {
  return (
    <main className="mx-auto flex min-h-screen w-full max-w-xl flex-col gap-6 px-5 py-6">
      <header>
        <p className="text-sm font-medium tracking-wide text-pine">WhatsApp do comércio</p>
        <h1 className="font-display mt-2 text-5xl text-ink">Balcão</h1>
        <p className="mt-3 text-lg leading-7 text-ink">
          Um atendente que fala solto, lê áudio, foto e comprovante de Pix, e responde no WhatsApp de verdade.
        </p>
      </header>

      <div className="flex flex-col gap-2 rounded-2xl border border-line bg-sand p-4">
        <p className="max-w-[85%] rounded-2xl rounded-tl-md bg-surface px-3 py-2 text-sm leading-6">
          tem a promoção da lata ainda?
        </p>
        <p className="ml-auto max-w-[85%] rounded-2xl rounded-tr-md bg-moss px-3 py-2 text-sm leading-6">
          tem sim, as três por dez até as 18h. quer que eu separe quantas?
        </p>
        <p className="max-w-[85%] rounded-2xl rounded-tl-md bg-surface px-3 py-2 text-sm leading-6">áudio: manda duas geladas</p>
        <p className="ml-auto max-w-[85%] rounded-2xl rounded-tr-md bg-moss px-3 py-2 text-sm leading-6">
          duas então. quando mandar o Pix, manda o comprovante que eu olho na hora.
        </p>
      </div>

      <ul className="flex flex-col gap-3 text-sm leading-6 text-ink">
        <li>Cadastra produto, horário, promoção relâmpago e o dia que vai abrir mais tarde ou nem abrir.</li>
        <li>Áudio vira texto. Foto e PDF de Pix mostram valor, hora, favorecido e banco.</li>
        <li>Ele libera o que parece certo. Você só confere no app do banco o que foi liberado.</li>
      </ul>

      <div className="flex flex-col gap-2 pb-8 md:mt-auto">
        {GROK_PROVIDERS.map((provider) => (
          <button
            key={provider.providerId}
            type="button"
            onClick={() => signIn(provider.providerId, { callbackURL: "/" })}
            className="inline-flex min-h-11 items-center justify-center rounded-xl bg-pine px-4 text-sm font-medium text-pine-ink"
          >
            Entrar com {provider.label}
          </button>
        ))}
      </div>
    </main>
  );
}
