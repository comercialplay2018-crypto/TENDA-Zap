import { useEffect, useRef, useState } from "react";
import { getProvaFn, provaSendFn } from "@/lib/balcao/fns";
import type { ChatMessage } from "@/lib/balcao/types";
import { bytesToBase64, downsample, encodeWavPCM } from "@/lib/balcao/wav";
import { Bubbles } from "./bubbles";
import { btnGhost, btnPrimary, inputClass } from "./ui";

export function Prova({ timeZone }: { timeZone: string }) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState("");
  const [err, setErr] = useState("");
  const [rec, setRec] = useState(false);
  const chunks = useRef<Float32Array[]>([]);
  const audio = useRef<{ ctx: AudioContext; stream: MediaStream } | null>(null);

  useEffect(() => {
    void getProvaFn().then(setMessages);
  }, []);

  async function send(payload: { text: string; attachment?: { kind: "audio" | "image" | "pdf"; base64: string; mime: string; filename: string } }) {
    setBusy(payload.attachment?.kind === "audio" ? "Ouvindo…" : payload.attachment ? "Lendo…" : "Respondendo…");
    setErr("");
    const res = await provaSendFn({ data: payload });
    setBusy("");
    if (!res.ok) {
      setErr(res.error);
      return;
    }
    setText("");
    setMessages(res.messages);
  }

  async function toggleMic() {
    if (rec && audio.current) {
      const { ctx, stream } = audio.current;
      const rate = ctx.sampleRate;
      stream.getTracks().forEach((track) => track.stop());
      await ctx.close();
      audio.current = null;
      setRec(false);
      const length = chunks.current.reduce((sum, chunk) => sum + chunk.length, 0);
      const merged = new Float32Array(length);
      let offset = 0;
      for (const chunk of chunks.current) {
        merged.set(chunk, offset);
        offset += chunk.length;
      }
      chunks.current = [];
      if (merged.length < rate / 4) {
        setErr("Áudio curto demais.");
        return;
      }
      const wav = encodeWavPCM(downsample(merged, rate, 16000), 16000);
      await send({ text: "", attachment: { kind: "audio", base64: bytesToBase64(wav), mime: "audio/wav", filename: "audio.wav" } });
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ctx = new AudioContext();
      await ctx.resume();
      const source = ctx.createMediaStreamSource(stream);
      const processor = ctx.createScriptProcessor(4096, 1, 1);
      const gain = ctx.createGain();
      gain.gain.value = 0;
      processor.onaudioprocess = (event) => {
        chunks.current.push(new Float32Array(event.inputBuffer.getChannelData(0)));
      };
      source.connect(processor);
      processor.connect(gain);
      gain.connect(ctx.destination);
      audio.current = { ctx, stream };
      chunks.current = [];
      setRec(true);
    } catch {
      setErr("Não consegui usar o microfone.");
      setRec(false);
    }
  }

  async function onFile(file: File, kind: "image" | "pdf" | "audio") {
    const base64 = await fileToBase64(file);
    await send({
      text: "",
      attachment: { kind, base64, mime: file.type || (kind === "pdf" ? "application/pdf" : "application/octet-stream"), filename: file.name },
    });
  }

  return (
    <div className="flex flex-col gap-3">
      <section className="rounded-2xl border border-line bg-surface p-4">
        <h2 className="font-display text-xl">Prova</h2>
        <p className="mt-1 text-sm leading-6 text-muted">
          O mesmo atendente das conversas reais. Manda texto, áudio, foto ou PDF. Nada disso sai para um cliente.
        </p>
      </section>
      <Bubbles messages={messages} timeZone={timeZone} />
      <textarea className={inputClass} rows={2} value={text} placeholder="Escreve como um cliente" onChange={(e) => setText(e.target.value)} />
      <div className="flex flex-wrap gap-2">
        <button type="button" className={btnPrimary} disabled={Boolean(busy)} onClick={() => void send({ text })}>
          {busy || "Mandar"}
        </button>
        <button type="button" className={rec ? "inline-flex min-h-11 items-center rounded-xl bg-clay px-4 text-sm text-clay-ink" : btnGhost} onClick={() => void toggleMic()}>
          {rec ? "Parar e enviar áudio" : "Gravar áudio"}
        </button>
        <label className={btnGhost}>
          Foto
          <input
            className="sr-only"
            type="file"
            accept="image/*"
            onChange={(e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              if (file) void onFile(file, "image");
            }}
          />
        </label>
        <label className={btnGhost}>
          PDF
          <input
            className="sr-only"
            type="file"
            accept="application/pdf,.pdf"
            onChange={(e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              if (file) void onFile(file, "pdf");
            }}
          />
        </label>
      </div>
      {err ? <p className="text-sm text-warn">{err}</p> : null}
    </div>
  );
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const value = String(reader.result ?? "");
      const index = value.indexOf(",");
      resolve(index >= 0 ? value.slice(index + 1) : value);
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
