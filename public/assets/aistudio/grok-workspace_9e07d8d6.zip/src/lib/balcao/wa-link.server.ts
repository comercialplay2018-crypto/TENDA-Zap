import { existsSync } from "node:fs";
import { mkdir, readFile, readdir, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { WaLinkStatus } from "./types";

type Slot = {
  status: WaLinkStatus["status"];
  qrDataUrl: string | null;
  phone: string;
  note: string;
  want: boolean;
  starting: boolean;
  since: number;
  generation: number;
  sock: WaSock | null;
  jids: Map<string, string>;
  tail: Promise<void>;
};

type WaSock = {
  user?: { id?: string };
  ev: {
    on: (event: string, listener: (payload: never) => void) => void;
  };
  sendMessage: (jid: string, content: Record<string, unknown>) => Promise<unknown>;
  sendPresenceUpdate?: (type: "composing" | "paused", jid: string) => Promise<unknown>;
  readMessages?: (keys: unknown[]) => Promise<unknown>;
  onWhatsApp?: (jid: string) => Promise<{ exists?: boolean; jid?: string }[]>;
  updateMediaMessage?: (message: unknown) => Promise<unknown>;
  logout?: () => Promise<void>;
  end?: (error?: unknown) => void;
  ws?: { readyState?: number };
};

type WaKey = { id?: string | null; remoteJid?: string | null; fromMe?: boolean | null };

type WaMsg = {
  key: WaKey;
  pushName?: string | null;
  messageTimestamp?: unknown;
  message?: Record<string, unknown> | null;
};

function writableRoot(): string {
  const cwd = process.cwd();
  const frozen = Boolean(process.env.VERCEL) || cwd === "/var/task" || cwd.startsWith("/var/task");
  return frozen ? join(tmpdir(), "balcao-wa-auth") : join(cwd, "data", "wa-auth");
}

let rootDir = writableRoot();

async function ensureRoot(): Promise<void> {
  try {
    await mkdir(rootDir, { recursive: true });
  } catch {
    rootDir = join(tmpdir(), "balcao-wa-auth");
    await mkdir(rootDir, { recursive: true });
  }
}

function readableLinkError(error: unknown): string {
  const message = error instanceof Error ? error.message : "";
  if (!message) return "Não conectou.";
  if (message.includes("ENOENT") || message.includes("EACCES") || message.includes("EROFS") || message.includes("mkdir")) {
    return "O servidor não deixou gravar a sessão. Tenta de novo em alguns segundos.";
  }
  return message;
}

function slots(): Map<string, Slot> {
  const g = globalThis as typeof globalThis & { __balcaoWa?: Map<string, Slot> };
  if (!g.__balcaoWa) g.__balcaoWa = new Map();
  return g.__balcaoWa;
}

function folderFor(userId: string): string {
  const safe = userId.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 80) || "user";
  return join(rootDir, safe);
}

function getSlot(userId: string): Slot {
  const all = slots();
  let slot = all.get(userId);
  if (!slot) {
    slot = {
      status: "off",
      qrDataUrl: null,
      phone: "",
      note: "Ainda não ligado.",
      want: false,
      starting: false,
      since: 0,
      generation: 0,
      sock: null,
      jids: new Map(),
      tail: Promise.resolve(),
    };
    all.set(userId, slot);
  }
  return slot;
}

function view(slot: Slot): WaLinkStatus {
  return {
    status: slot.status,
    qrDataUrl: slot.qrDataUrl,
    phone: slot.phone,
    note: slot.note,
  };
}

async function readJids(folder: string): Promise<Record<string, string>> {
  try {
    const raw = await readFile(join(folder, "jids.json"), "utf8");
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== "object") return {};
    const out: Record<string, string> = {};
    for (const [key, value] of Object.entries(parsed)) {
      if (typeof value === "string" && value.includes("@")) out[key] = value;
    }
    return out;
  } catch {
    return {};
  }
}

async function writeJid(folder: string, waId: string, jid: string, slot: Slot): Promise<void> {
  slot.jids.set(waId, jid);
  const body: Record<string, string> = {};
  for (const [key, value] of slot.jids) body[key] = value;
  await mkdir(folder, { recursive: true });
  await writeFile(join(folder, "jids.json"), JSON.stringify(body));
}

function paired(userId: string): boolean {
  return existsSync(join(folderFor(userId), "creds.json"));
}

const HOLDER = `${process.pid}-${Math.random().toString(36).slice(2, 10)}`;

function socketLive(sock: WaSock | null): boolean {
  const state = sock?.ws?.readyState;
  if (typeof state === "number") return state === 1;
  return Boolean(sock);
}

async function restoreAuth(userId: string, folder: string): Promise<boolean> {
  try {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const rows = await sql<{ name: string; body: string }>`
      select name, body from wa_auth_files where user_id = ${userId}
    `;
    if (!rows.length) return false;
    await mkdir(folder, { recursive: true });
    for (const row of rows) {
      if (!/^[\w.-]+$/.test(row.name)) continue;
      await writeFile(join(folder, row.name), row.body);
    }
    return rows.some((row) => row.name === "creds.json");
  } catch {
    return false;
  }
}

async function persistAuth(userId: string, folder: string): Promise<void> {
  try {
    const names = await readdir(folder);
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    for (const name of names) {
      if (!name.endsWith(".json") || !/^[\w.-]+$/.test(name)) continue;
      const body = await readFile(join(folder, name), "utf8");
      if (body.length > 1_500_000) continue;
      await sql`
        insert into wa_auth_files (user_id, name, body, updated_at)
        values (${userId}, ${name}, ${body}, now())
        on conflict (user_id, name) do update set body = excluded.body, updated_at = now()
      `;
    }
  } catch (error) {
    console.error("wa auth save", error instanceof Error ? error.message : "fail");
  }
}

async function forgetAuth(userId: string): Promise<void> {
  try {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    await sql`delete from wa_auth_files where user_id = ${userId}`;
    await sql`delete from wa_link_state where user_id = ${userId}`;
  } catch {
    /* session files are still removed */
  }
}

async function claimLink(userId: string, slot: Slot): Promise<boolean> {
  try {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const rows = await sql<{ user_id: string }>`
      insert into wa_link_state (user_id, holder, status, phone, note, qr, beat)
      values (${userId}, ${HOLDER}, ${slot.status}, ${slot.phone}, ${slot.note}, ${slot.qrDataUrl ?? ""}, now())
      on conflict (user_id) do update set
        holder = ${HOLDER},
        status = ${slot.status},
        phone = ${slot.phone},
        note = ${slot.note},
        qr = ${slot.qrDataUrl ?? ""},
        beat = now()
      where wa_link_state.holder = ${HOLDER}
         or wa_link_state.beat < now() - interval '20 seconds'
      returning user_id
    `;
    return Boolean(rows[0]);
  } catch {
    return true;
  }
}

async function publishState(userId: string, slot: Slot): Promise<void> {
  try {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    await sql`
      update wa_link_state
      set status = ${slot.status},
          phone = ${slot.phone},
          note = ${slot.note},
          qr = ${slot.status === "qr" ? (slot.qrDataUrl ?? "") : ""},
          beat = now()
      where user_id = ${userId} and holder = ${HOLDER}
    `;
  } catch {
    /* local status still works */
  }
}

async function sharedStatus(userId: string): Promise<WaLinkStatus | null> {
  try {
    const { getSql } = await import("@/lib/db");
    const sql = await getSql();
    const rows = await sql<{
      holder: string;
      status: WaLinkStatus["status"];
      phone: string;
      note: string;
      qr: string;
      fresh: boolean;
    }>`
      select holder, status, phone, note, qr, beat > now() - interval '20 seconds' as fresh
      from wa_link_state
      where user_id = ${userId}
    `;
    const row = rows[0];
    if (!row?.fresh || row.holder === HOLDER) return null;
    if (row.status !== "open" && row.status !== "qr" && row.status !== "connecting") return null;
    return {
      status: row.status,
      qrDataUrl: row.qr || null,
      phone: row.phone,
      note: row.note,
    };
  } catch {
    return null;
  }
}

function stampOf(value: unknown): number {
  if (typeof value === "number") return value;
  if (typeof value === "bigint") return Number(value);
  if (typeof value === "string") return Number(value) || 0;
  if (value && typeof value === "object") {
    const record = value as { toNumber?: () => number; low?: number };
    if (typeof record.toNumber === "function") return record.toNumber();
    if (typeof record.low === "number") return record.low;
  }
  return 0;
}

function unwrap(message: Record<string, unknown> | null | undefined): Record<string, unknown> | null {
  let current = message ?? null;
  for (let i = 0; i < 5 && current; i += 1) {
    const inner =
      (current.ephemeralMessage as { message?: Record<string, unknown> } | undefined)?.message ||
      (current.viewOnceMessage as { message?: Record<string, unknown> } | undefined)?.message ||
      (current.viewOnceMessageV2 as { message?: Record<string, unknown> } | undefined)?.message ||
      (current.viewOnceMessageV2Extension as { message?: Record<string, unknown> } | undefined)?.message ||
      (current.documentWithCaptionMessage as { message?: Record<string, unknown> } | undefined)?.message ||
      (current.editedMessage as { message?: Record<string, unknown> } | undefined)?.message;
    if (!inner) break;
    current = inner;
  }
  return current;
}

function kick(userId: string): void {
  const slot = getSlot(userId);
  if (!slot.want || slot.starting || slot.status === "open" || slot.status === "qr") return;
  slot.starting = true;
  slot.since = Date.now();
  slot.status = "connecting";
  slot.note = "Conectando no WhatsApp…";
  void connect(userId).finally(() => {
    slot.starting = false;
  });
}

export function linkStatus(userId: string): WaLinkStatus {
  return view(getSlot(userId));
}

export async function resumeIfPaired(userId: string): Promise<WaLinkStatus> {
  const remote = await sharedStatus(userId);
  if (remote) return remote;
  const slot = getSlot(userId);
  if ((slot.status === "open" || slot.status === "qr") && !socketLive(slot.sock)) {
    slot.sock = null;
    slot.status = "off";
  }
  if (!paired(userId)) await restoreAuth(userId, folderFor(userId));
  if (!paired(userId) && !slot.want) return view(slot);
  const mine = await claimLink(userId, slot);
  if (!mine) return (await sharedStatus(userId)) ?? view(slot);
  return ensureLink(userId);
}

export async function holdLink(userId: string): Promise<WaLinkStatus> {
  const first = await resumeIfPaired(userId);
  const slot = getSlot(userId);
  if (!slot.want || slot.status === "off") return first;
  const end = Date.now() + 20000;
  while (Date.now() < end) {
    if ((slot.status === "open" || slot.status === "qr") && !socketLive(slot.sock)) {
      slot.sock = null;
      slot.status = "off";
      kick(userId);
    }
    await publishState(userId, slot);
    await new Promise((resolve) => setTimeout(resolve, 2000));
  }
  return view(slot);
}

export function ensureLink(userId: string): WaLinkStatus {
  const slot = getSlot(userId);
  slot.want = true;
  const stuck = slot.status === "connecting" && !slot.starting && Date.now() - slot.since > 20000;
  if (slot.status === "off" || stuck) kick(userId);
  return view(slot);
}

export async function ensureLinkReady(userId: string): Promise<WaLinkStatus> {
  const slot = getSlot(userId);
  ensureLink(userId);
  const deadline = Date.now() + 20000;
  while (Date.now() < deadline) {
    if (slot.qrDataUrl || slot.status === "open") return view(slot);
    if (slot.status === "off" && !slot.starting) return view(slot);
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  return view(slot);
}

export async function stopLink(userId: string): Promise<WaLinkStatus> {
  const slot = getSlot(userId);
  slot.want = false;
  slot.generation += 1;
  slot.qrDataUrl = null;
  slot.phone = "";
  slot.status = "off";
  slot.note = "Desligado. O celular segue normal.";
  const sock = slot.sock;
  slot.sock = null;
  try {
    await sock?.logout?.();
  } catch {
    try {
      sock?.end?.();
    } catch {
      /* already gone */
    }
  }
  await rm(folderFor(userId), { recursive: true, force: true });
  await forgetAuth(userId);
  slot.jids.clear();
  return view(slot);
}

export async function sendTextToContact(
  userId: string,
  waId: string,
  text: string,
): Promise<"sent" | "offline" | "failed"> {
  const slot = slots().get(userId);
  if (!slot || slot.status !== "open" || !slot.sock) return "offline";
  const folder = folderFor(userId);
  if (slot.jids.size === 0) {
    const saved = await readJids(folder);
    for (const [key, value] of Object.entries(saved)) slot.jids.set(key, value);
  }
  let jid = slot.jids.get(waId) || "";
  if (!jid) {
    const digits = waId.replace(/\D/g, "");
    if (digits.length < 10) return "failed";
    try {
      const listed = await slot.sock.onWhatsApp?.(digits);
      const hit = listed?.find((row) => row.exists && row.jid);
      jid = hit?.jid || `${digits}@s.whatsapp.net`;
    } catch {
      jid = `${digits}@s.whatsapp.net`;
    }
    await writeJid(folder, waId, jid, slot);
  }
  try {
    try {
      await slot.sock.sendPresenceUpdate?.("composing", jid);
    } catch {
      /* presença é só um detalhe */
    }
    await slot.sock.sendMessage(jid, { text });
    try {
      await slot.sock.sendPresenceUpdate?.("paused", jid);
    } catch {
      /* ignore */
    }
    return "sent";
  } catch (error) {
    slot.note = error instanceof Error ? error.message : "Não saiu no WhatsApp.";
    return "failed";
  }
}

export async function sendFileToContact(
  userId: string,
  waId: string,
  bytes: Uint8Array,
  mime: string,
  fileName: string,
): Promise<"sent" | "offline" | "failed"> {
  const slot = slots().get(userId);
  if (!slot || slot.status !== "open" || !slot.sock) return "offline";
  const folder = folderFor(userId);
  if (slot.jids.size === 0) {
    const saved = await readJids(folder);
    for (const [key, value] of Object.entries(saved)) slot.jids.set(key, value);
  }
  const jid = slot.jids.get(waId) || `${waId.replace(/\D/g, "")}@s.whatsapp.net`;
  try {
    await slot.sock.sendMessage(jid, {
      document: Buffer.from(bytes),
      mimetype: mime,
      fileName,
    });
    return "sent";
  } catch {
    return "failed";
  }
}

async function connect(userId: string): Promise<void> {
  const slot = getSlot(userId);
  const generation = ++slot.generation;
  const previous = slot.sock;
  slot.sock = null;
  try {
    previous?.end?.();
  } catch {
    /* ignore */
  }
  try {
    await ensureRoot();
    const folder = folderFor(userId);
    const baileys = await import("@whiskeysockets/baileys");
    const qrcode = await import("qrcode");
    const { default: pino } = await import("pino");
    await mkdir(folder, { recursive: true });
    await restoreAuth(userId, folder);
    const saved = await readJids(folder);
    slot.jids = new Map(Object.entries(saved));
    const { state, saveCreds } = await baileys.useMultiFileAuthState(folder);
    const logger = pino({ level: "silent" });
    let version: [number, number, number] | undefined;
    try {
      version = (await baileys.fetchLatestBaileysVersion()).version;
    } catch {
      version = undefined;
    }
    const sock = baileys.default({
      auth: state,
      version,
      logger,
      printQRInTerminal: false,
      browser: ["Balcão", "Chrome", "120.0.0"],
      syncFullHistory: false,
      markOnlineOnConnect: false,
      generateHighQualityLinkPreview: false,
      getMessage: async () => undefined,
    }) as unknown as WaSock;
    if (slot.generation !== generation || !slot.want) {
      sock.end?.();
      return;
    }
    slot.sock = sock;
    slot.note = paired(userId) ? "Religando o WhatsApp…" : "Gerando o QR…";
    sock.ev.on("creds.update", (async () => {
      await saveCreds();
      await persistAuth(userId, folder);
    }) as never);
    sock.ev.on("connection.update", ((update: {
      connection?: string;
      qr?: string;
      lastDisconnect?: { error?: { output?: { statusCode?: number } } };
    }) => {
      void onUpdate(userId, generation, update, qrcode.default);
    }) as never);
    sock.ev.on("messages.upsert", ((payload: { type?: string; messages?: WaMsg[] }) => {
      void onMessages(userId, generation, payload);
    }) as never);
  } catch (error) {
    if (slot.generation !== generation) return;
    slot.status = "off";
    slot.qrDataUrl = null;
    slot.note = readableLinkError(error);
  }
}

async function onUpdate(
  userId: string,
  generation: number,
  update: {
    connection?: string;
    qr?: string;
    lastDisconnect?: { error?: { output?: { statusCode?: number } } };
  },
  QRCode: { toDataURL: (text: string, options: { margin: number; width: number }) => Promise<string> },
): Promise<void> {
  const slot = getSlot(userId);
  if (slot.generation !== generation) return;
  if (update.qr) {
    slot.qrDataUrl = await QRCode.toDataURL(update.qr, { margin: 1, width: 320 });
    slot.status = "qr";
    slot.note = "No celular: WhatsApp, Aparelhos conectados, Conectar aparelho.";
  }
  if (update.connection === "open") {
    slot.status = "open";
    slot.qrDataUrl = null;
    const raw = String(slot.sock?.user?.id ?? "");
    slot.phone = raw.split(":")[0]?.split("@")[0] ?? "";
    slot.note = slot.phone
      ? `Ligado em ${slot.phone}. O celular continua no WhatsApp.`
      : "WhatsApp ligado. O celular continua funcionando.";
    await persistAuth(userId, folderFor(userId));
    await publishState(userId, slot);
    if (slot.phone) {
      try {
        const { getSql } = await import("@/lib/db");
        const sql = await getSql();
        await sql`update wa_connection set display_phone = ${slot.phone} where user_id = ${userId} and display_phone = ''`;
      } catch {
        /* desk still shows the status */
      }
    }
  }
  if (update.connection === "close") {
    const baileys = await import("@whiskeysockets/baileys");
    const code = update.lastDisconnect?.error?.output?.statusCode;
    const fatal =
      code === baileys.DisconnectReason.loggedOut ||
      code === baileys.DisconnectReason.forbidden ||
      code === baileys.DisconnectReason.badSession;
    slot.sock = null;
    slot.qrDataUrl = null;
    if (!slot.want || fatal) {
      slot.status = "off";
      slot.phone = "";
      slot.note = fatal
        ? "O WhatsApp encerrou a sessão. Escaneie de novo."
        : "Desligado.";
      if (fatal) {
        await rm(folderFor(userId), { recursive: true, force: true });
        await forgetAuth(userId);
        slot.jids.clear();
      }
      await publishState(userId, slot);
      return;
    }
    slot.status = "connecting";
    slot.note = "Reconectando…";
    const wait = code === baileys.DisconnectReason.restartRequired ? 500 : 1600;
    setTimeout(() => {
      if (slot.want && slot.generation === generation) kick(userId);
    }, wait);
  }
}

async function onMessages(
  userId: string,
  generation: number,
  payload: { type?: string; messages?: WaMsg[] },
): Promise<void> {
  const slot = getSlot(userId);
  if (slot.generation !== generation || payload.type !== "notify") return;
  for (const message of payload.messages ?? []) {
    slot.tail = slot.tail
      .then(() => handleOne(userId, generation, message))
      .catch((error: unknown) => {
        console.error("wa message", error instanceof Error ? error.message : "fail");
      });
  }
}

async function handleOne(userId: string, generation: number, message: WaMsg): Promise<void> {
  const slot = getSlot(userId);
  if (slot.generation !== generation || slot.status !== "open" || !slot.sock) return;
  if (message.key.fromMe || !message.key.remoteJid || !message.message) return;
  const baileys = await import("@whiskeysockets/baileys");
  const jid = message.key.remoteJid;
  if (
    baileys.isJidGroup(jid) ||
    baileys.isJidBroadcast(jid) ||
    baileys.isJidStatusBroadcast(jid) ||
    baileys.isJidNewsletter(jid)
  ) {
    return;
  }
  const sentAt = stampOf(message.messageTimestamp);
  const now = Math.floor(Date.now() / 1000);
  if (sentAt > 0 && now - sentAt > 120) return;

  const content = unwrap(message.message);
  if (!content) return;
  const kind = baileys.getContentType(content as never);
  if (!kind || kind === "protocolMessage" || kind === "reactionMessage" || kind === "senderKeyDistributionMessage") {
    return;
  }

  const waId = jid.split("@")[0]?.split(":")[0] || "";
  if (!waId) return;
  await writeJid(folderFor(userId), waId, jid, slot);
  try {
    await slot.sock.readMessages?.([message.key]);
  } catch {
    /* ticks are optional */
  }

  const inbound = {
    userId,
    waId,
    profileName: message.pushName || "",
    waMessageId: message.key.id || null,
    kind: "outro" as "text" | "audio" | "image" | "pdf" | "outro",
    text: "",
    bytes: undefined as Uint8Array | undefined,
    mime: undefined as string | undefined,
    filename: undefined as string | undefined,
    deliver: false,
  };

  if (kind === "conversation") {
    inbound.kind = "text";
    inbound.text = String(content.conversation ?? "");
  } else if (kind === "extendedTextMessage") {
    inbound.kind = "text";
    inbound.text = String((content.extendedTextMessage as { text?: string } | undefined)?.text ?? "");
  } else if (kind === "imageMessage") {
    inbound.kind = "image";
    inbound.text = String((content.imageMessage as { caption?: string } | undefined)?.caption ?? "");
    inbound.mime = String((content.imageMessage as { mimetype?: string } | undefined)?.mimetype ?? "image/jpeg");
    inbound.bytes = await downloadBytes(slot, message);
  } else if (kind === "audioMessage") {
    inbound.kind = "audio";
    inbound.mime = String((content.audioMessage as { mimetype?: string } | undefined)?.mimetype ?? "audio/ogg");
    inbound.bytes = await downloadBytes(slot, message);
  } else if (kind === "documentMessage") {
    const doc = content.documentMessage as { mimetype?: string; caption?: string; fileName?: string } | undefined;
    const mime = doc?.mimetype || "";
    const name = doc?.fileName || "";
    inbound.text = doc?.caption || name || "";
    inbound.filename = doc?.fileName;
    inbound.mime = mime;
    inbound.bytes = await downloadBytes(slot, message);
    const looksPdf = mime.includes("pdf") || name.toLowerCase().endsWith(".pdf");
    if (looksPdf) inbound.kind = "pdf";
    else if (mime.startsWith("image/")) inbound.kind = "image";
    else inbound.kind = "outro";
    if (inbound.kind === "outro" && !inbound.text) inbound.text = "[a pessoa mandou um arquivo]";
  } else if (kind === "videoMessage") {
    inbound.text = String((content.videoMessage as { caption?: string } | undefined)?.caption || "[a pessoa mandou um vídeo]");
  } else if (kind === "stickerMessage") {
    inbound.text = "[a pessoa mandou uma figurinha]";
  } else if (kind === "locationMessage") {
    const name = (content.locationMessage as { name?: string } | undefined)?.name;
    inbound.text = name ? `[localização: ${name}]` : "[a pessoa mandou uma localização]";
  } else if (kind === "contactMessage") {
    inbound.kind = "text";
    inbound.text = String((content.contactMessage as { displayName?: string } | undefined)?.displayName || "[contato]");
  } else if (kind === "buttonsResponseMessage") {
    inbound.kind = "text";
    inbound.text = String(
      (content.buttonsResponseMessage as { selectedDisplayText?: string } | undefined)?.selectedDisplayText ?? "",
    );
  } else if (kind === "listResponseMessage") {
    inbound.kind = "text";
    const list = content.listResponseMessage as { title?: string; singleSelectReply?: { selectedRowId?: string } } | undefined;
    inbound.text = list?.title || list?.singleSelectReply?.selectedRowId || "";
  } else {
    inbound.text = "[mensagem de um tipo que o balcão não abre]";
  }

  if (!inbound.text && !inbound.bytes) return;
  const { handleIncoming } = await import("./flow.server");
  const result = await handleIncoming(inbound);
  if (!result.reply || slot.generation !== generation || !slot.sock || slot.status !== "open") return;
  try {
    try {
      await slot.sock.sendPresenceUpdate?.("composing", jid);
    } catch {
      /* ignore */
    }
    await slot.sock.sendMessage(jid, { text: result.reply });
    try {
      await slot.sock.sendPresenceUpdate?.("paused", jid);
    } catch {
      /* ignore */
    }
  } catch (error) {
    const { insertMessage } = await import("./repo.server");
    const detail = error instanceof Error ? error.message : "falha";
    await insertMessage(userId, result.contactId, "out", "nota", `Não saiu no WhatsApp: ${detail}`);
  }
}

async function downloadBytes(slot: Slot, message: WaMsg): Promise<Uint8Array | undefined> {
  try {
    const baileys = await import("@whiskeysockets/baileys");
    const { default: pino } = await import("pino");
    const buf = await baileys.downloadMediaMessage(message as never, "buffer", {}, {
      logger: pino({ level: "silent" }),
      reuploadRequest: async (current: unknown) => {
        if (!slot.sock?.updateMediaMessage) return current;
        return slot.sock.updateMediaMessage(current);
      },
    } as never);
    const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf as ArrayBuffer);
    if (bytes.byteLength > 8_000_000) return undefined;
    return bytes;
  } catch {
    return undefined;
  }
}
