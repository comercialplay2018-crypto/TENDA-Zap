const STOP = new Set(["de", "da", "do", "dos", "das", "e"]);

export function norm(s: string): string {
  return s
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[^a-z0-9 ]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokens(s: string): string[] {
  return norm(s)
    .split(" ")
    .filter((t) => t.length >= 2 && !STOP.has(t));
}

export function namesMatch(expected: string, found: string): boolean | null {
  const a = tokens(expected);
  const b = tokens(found);
  if (a.length === 0 || b.length === 0) return null;
  const firstOk = b.some((x) => x === a[0] || x.startsWith(a[0]) || a[0].startsWith(x));
  if (!firstOk) return false;
  const hit = a.filter((t) => b.some((x) => x === t || x.startsWith(t) || t.startsWith(x)));
  return hit.length === a.length || hit.length >= Math.min(a.length, 2);
}

export type ReceiptDecision = {
  status: "liberado" | "duvida" | "recusado";
  nameMatches: boolean | null;
  decision: string;
};

export function decideReceipt(input: {
  isReceipt: boolean;
  amountCents: number | null;
  favorecido: string;
  expectedFavorecido: string;
  paidDate: string;
  today: string;
  yesterday: string;
  confidence: string;
  banco: string;
}): ReceiptDecision {
  if (!input.isReceipt) {
    return { status: "recusado", nameMatches: null, decision: "Não parece comprovante de Pix." };
  }
  const nameMatches = namesMatch(input.expectedFavorecido, input.favorecido);
  const bits: string[] = [];
  if (!input.expectedFavorecido.trim()) bits.push("cadastre o nome de quem recebe o Pix");
  else if (nameMatches === false) bits.push("o favorecido não bate com o cadastrado");
  else if (nameMatches === null) bits.push("não deu para ler o favorecido");
  if (input.amountCents == null) bits.push("sem valor");
  if (!input.paidDate) bits.push("sem data");
  else if (input.paidDate !== input.today && input.paidDate !== input.yesterday) {
    bits.push("a data não é de hoje nem de ontem");
  }
  if (input.confidence === "baixa") bits.push("leitura fraca");
  if (input.banco) bits.push(`banco lido: ${input.banco}`);

  if (bits.some((b) => !b.startsWith("banco lido"))) {
    const hard = nameMatches === false;
    return {
      status: hard ? "recusado" : "duvida",
      nameMatches,
      decision: bits.join(". ") + ".",
    };
  }
  return {
    status: "liberado",
    nameMatches: true,
    decision: `Liberado para a conferência no banco. ${bits.join(". ")}.`.replace("..", "."),
  };
}

export function parseBrlToCents(raw: string): number | null {
  const t = raw.trim().replace(/\s/g, "").replace(/^R\$/i, "");
  if (!t) return null;
  const normalized = t.includes(",") ? t.replace(/\./g, "").replace(",", ".") : t;
  const n = Number(normalized);
  if (!Number.isFinite(n) || n < 0 || n > 1_000_000) return null;
  return Math.round(n * 100);
}
