import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import type {
  ChatMessage,
  ConnInput,
  Desk,
  ExceptionInput,
  ProductInput,
  PromoInput,
  ProvaInput,
  ReceiptRow,
  Shop,
  ShopJob,
  ThreadSummary,
  PrintJob,
  WaLinkStatus,
  WeekHours,
} from "./types";

function fail(error: unknown): { ok: false; error: string } {
  return { ok: false, error: error instanceof Error ? error.message : "Não deu." };
}

export const getDesk = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Desk> => {
    const { loadDesk } = await import("./repo.server");
    const desk = await loadDesk(context.userId);
    void import("./wa-link.server")
      .then((mod) => mod.resumeIfPaired(context.userId))
      .catch(() => undefined);
    return desk;
  });

export const saveShopFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: Shop) => input)
  .handler(async ({ context, data }) => {
    try {
      const { saveShop } = await import("./repo.server");
      await saveShop(context.userId, data);
      return { ok: true as const };
    } catch (error) {
      return fail(error);
    }
  });

export const saveHoursFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: WeekHours[]) => input)
  .handler(async ({ context, data }) => {
    try {
      const { saveHours } = await import("./repo.server");
      await saveHours(context.userId, data);
      return { ok: true as const };
    } catch (error) {
      return fail(error);
    }
  });

export const addExceptionFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: ExceptionInput) => input)
  .handler(async ({ context, data }) => {
    try {
      const { addException } = await import("./repo.server");
      await addException(context.userId, data);
      return { ok: true as const };
    } catch (error) {
      return fail(error);
    }
  });

export const deleteExceptionFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data }) => {
    const { deleteException } = await import("./repo.server");
    await deleteException(context.userId, data);
    return { ok: true as const };
  });

export const saveProductFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: ProductInput) => input)
  .handler(async ({ context, data }) => {
    try {
      const { saveProduct } = await import("./repo.server");
      await saveProduct(context.userId, data);
      return { ok: true as const };
    } catch (error) {
      return fail(error);
    }
  });

export const deleteProductFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data }) => {
    const { deleteProduct } = await import("./repo.server");
    await deleteProduct(context.userId, data);
    return { ok: true as const };
  });

export const addPromoFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: PromoInput) => input)
  .handler(async ({ context, data }) => {
    try {
      const { addPromo } = await import("./repo.server");
      await addPromo(context.userId, data);
      return { ok: true as const };
    } catch (error) {
      return fail(error);
    }
  });

export const setPromoFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; active: boolean }) => input)
  .handler(async ({ context, data }) => {
    const { setPromoActive } = await import("./repo.server");
    await setPromoActive(context.userId, data.id, data.active);
    return { ok: true as const };
  });

export const deletePromoFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data }) => {
    const { deletePromo } = await import("./repo.server");
    await deletePromo(context.userId, data);
    return { ok: true as const };
  });

export const addNoticeFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((body: string) => body)
  .handler(async ({ context, data }) => {
    try {
      const { addNotice } = await import("./repo.server");
      await addNotice(context.userId, data);
      return { ok: true as const };
    } catch (error) {
      return fail(error);
    }
  });

export const setNoticeFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; active: boolean }) => input)
  .handler(async ({ context, data }) => {
    const { setNoticeActive } = await import("./repo.server");
    await setNoticeActive(context.userId, data.id, data.active);
    return { ok: true as const };
  });

export const deleteNoticeFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data }) => {
    const { deleteNotice } = await import("./repo.server");
    await deleteNotice(context.userId, data);
    return { ok: true as const };
  });

export const saveConnectionFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: ConnInput) => input)
  .handler(async ({ context, data }) => {
    try {
      const { saveConnection } = await import("./repo.server");
      await saveConnection(context.userId, data);
      return { ok: true as const };
    } catch (error) {
      return fail(error);
    }
  });

export const setBotFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((enabled: boolean) => enabled)
  .handler(async ({ context, data }) => {
    const { setBotEnabled } = await import("./repo.server");
    await setBotEnabled(context.userId, data);
    return { ok: true as const };
  });

export const getThreads = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ThreadSummary[]> => {
    const { listThreads, mapThread } = await import("./repo.server");
    const rows = await listThreads(context.userId);
    return rows.map(mapThread);
  });

export const getMessages = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((contactId: number) => contactId)
  .handler(async ({ context, data }): Promise<ChatMessage[]> => {
    const { listMessages, mapMessage } = await import("./repo.server");
    const rows = await listMessages(context.userId, data);
    return rows.map(mapMessage).reverse();
  });

export const setPausedFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { contactId: number; paused: boolean }) => input)
  .handler(async ({ context, data }) => {
    const { setPaused } = await import("./repo.server");
    await setPaused(context.userId, data.contactId, data.paused);
    return { ok: true as const };
  });

export const humanSendFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { contactId: number; text: string }) => input)
  .handler(async ({ context, data }) => {
    try {
      const { sendHuman } = await import("./flow.server");
      await sendHuman(context.userId, data.contactId, data.text);
      return { ok: true as const };
    } catch (error) {
      return fail(error);
    }
  });

export const getReceipts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ReceiptRow[]> => {
    const { listReceipts } = await import("./repo.server");
    const rows = await listReceipts(context.userId);
    return rows.map((row) => ({
      id: row.id,
      contactId: row.contact_id,
      contactName: row.contact_name,
      waId: row.wa_id,
      payerName: row.payer_name,
      favorecido: row.favorecido,
      banco: row.banco,
      amountCents: row.amount_cents,
      paidAtText: row.paid_at_text,
      paidDate: row.paid_date,
      e2eId: row.e2e_id,
      confidence: row.confidence,
      nameMatches: row.name_matches,
      decision: row.decision,
      status: row.status,
      note: row.note,
      mediaDataUrl: row.media_data_url,
      createdAt: row.created_at instanceof Date ? row.created_at.toISOString() : String(row.created_at ?? ""),
    }));
  });

export const setReceiptFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; status: string }) => input)
  .handler(async ({ context, data }) => {
    try {
      const { setReceiptStatus } = await import("./repo.server");
      await setReceiptStatus(context.userId, data.id, data.status);
      return { ok: true as const };
    } catch (error) {
      return fail(error);
    }
  });

export const provaSendFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: ProvaInput) => input)
  .handler(async ({ context, data }) => {
    try {
      const attachment = data.attachment;
      if (attachment && attachment.base64.length > 6_000_000) {
        return { ok: false as const, error: "Arquivo grande demais." };
      }
      const { handleIncoming, provaWaId } = await import("./flow.server");
      const { listMessages, mapMessage } = await import("./repo.server");
      const bytes = attachment ? Buffer.from(attachment.base64, "base64") : undefined;
      const result = await handleIncoming({
        userId: context.userId,
        waId: provaWaId(),
        profileName: "Prova",
        waMessageId: null,
        kind: attachment?.kind ?? "text",
        text: data.text ?? "",
        bytes,
        mime: attachment?.mime,
        filename: attachment?.filename,
        deliver: false,
      });
      const rows = await listMessages(context.userId, result.contactId);
      const messages = rows.map(mapMessage).reverse();
      return { ok: true as const, messages, reply: result.reply };
    } catch (error) {
      return { ok: false as const, error: error instanceof Error ? error.message : "Não deu.", messages: [] as ChatMessage[] };
    }
  });

export const getProvaFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ChatMessage[]> => {
    const { provaWaId } = await import("./flow.server");
    const { listMessages, mapMessage, upsertContact } = await import("./repo.server");
    const contact = await upsertContact(context.userId, provaWaId(), "Prova");
    const rows = await listMessages(context.userId, contact.id);
    return rows.map(mapMessage).reverse();
  });

export const holdWaFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<WaLinkStatus> => {
    const { holdLink } = await import("./wa-link.server");
    return holdLink(context.userId);
  });

export const getWaLinkFn = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<WaLinkStatus> => {
    const { resumeIfPaired } = await import("./wa-link.server");
    return resumeIfPaired(context.userId);
  });

export const startWaLinkFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<WaLinkStatus> => {
    const { ensureLinkReady } = await import("./wa-link.server");
    return ensureLinkReady(context.userId);
  });

export const stopWaLinkFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<WaLinkStatus> => {
    const { stopLink } = await import("./wa-link.server");
    return stopLink(context.userId);
  });

export const getOfficeFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((contactId: number) => contactId)
  .handler(async ({ context, data }): Promise<{ prints: PrintJob[]; jobs: ShopJob[]; pending: number }> => {
    const office = await import("./office.server");
    const [prints, jobs, pending] = await Promise.all([
      office.listPrintJobs(context.userId, data),
      office.listShopJobs(context.userId, data),
      office.pendingPrints(context.userId),
    ]);
    return { prints, jobs, pending };
  });

export const claimPrintFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<PrintJob | null> => {
    const office = await import("./office.server");
    return office.claimNextPrint(context.userId);
  });

export const releaseStuckPrintsFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const { releaseStuckPrints } = await import("./office.server");
    await releaseStuckPrints(context.userId);
    return { ok: true as const };
  });

export const markPrintFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data }) => {
    const { markPrinted } = await import("./office.server");
    await markPrinted(context.userId, data);
    return { ok: true as const };
  });

export const returnPrintFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data }) => {
    const { returnPrint } = await import("./office.server");
    await returnPrint(context.userId, data);
    return { ok: true as const };
  });

export const failPrintFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data }) => {
    const { failPrint } = await import("./office.server");
    await failPrint(context.userId, data);
    return { ok: true as const };
  });

export const resumeFromChatFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((contactId: number) => contactId)
  .handler(async ({ context, data }) => {
    try {
      const { attendOffice } = await import("./office.server");
      const { recentHistory } = await import("./repo.server");
      const { getSql } = await import("@/lib/db");
      const sql = await getSql();
      const rows = await sql<{ wa_id: string }>`select wa_id from contacts where id = ${data} and user_id = ${context.userId}`;
      const waId = rows[0]?.wa_id;
      if (!waId) return { ok: false as const, error: "Conversa não encontrada." };
      const history = await recentHistory(data);
      const note = await attendOffice({
        userId: context.userId,
        contactId: data,
        waId,
        customerText: "Pode montar o currículo com o que já foi dito.",
        history,
        pix: null,
        kind: "text",
        force: "curriculo",
      });
      return { ok: true as const, note: note || "Ainda falta nome e experiência ou escolaridade." };
    } catch (error) {
      return fail(error);
    }
  });

export const saleFromChatFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((contactId: number) => contactId)
  .handler(async ({ context, data }) => {
    try {
      const { attendOffice } = await import("./office.server");
      const { recentHistory } = await import("./repo.server");
      const { getSql } = await import("@/lib/db");
      const sql = await getSql();
      const rows = await sql<{ wa_id: string }>`select wa_id from contacts where id = ${data} and user_id = ${context.userId}`;
      const waId = rows[0]?.wa_id;
      if (!waId) return { ok: false as const, error: "Conversa não encontrada." };
      if (waId.startsWith("local:")) return { ok: false as const, error: "A Prova não lança venda no PDV." };
      const history = await recentHistory(data);
      const note = await attendOffice({
        userId: context.userId,
        contactId: data,
        waId,
        customerText: "Pode lançar a venda combinada.",
        history,
        pix: null,
        kind: "text",
        force: "venda",
      });
      return { ok: true as const, note: note || "Não deu para saber os itens da venda." };
    } catch (error) {
      return fail(error);
    }
  });

export const sendResumeFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data }) => {
    try {
      const { resendJob } = await import("./office.server");
      await resendJob(context.userId, data);
      return { ok: true as const };
    } catch (error) {
      return fail(error);
    }
  });

export const resumeFileFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => id)
  .handler(async ({ context, data }) => {
    const { jobFile } = await import("./office.server");
    const file = await jobFile(context.userId, data);
    if (!file) return { ok: false as const, error: "PDF não encontrado." };
    return { ok: true as const, ...file };
  });

export const testSendFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { to: string; text: string }) => input)
  .handler(async ({ context, data }) => {
    try {
      const { sendTest } = await import("./flow.server");
      await sendTest(context.userId, data.to, data.text);
      return { ok: true as const };
    } catch (error) {
      return fail(error);
    }
  });
