import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { getSql } from "@/lib/db";
import { askJson } from "./ai.server";
import { insertMessage } from "./repo.server";
import type { PixRead } from "./ai.server";

const PDV_KEY = "AIzaSyBRecRzbvY29QVgc0q1IKTQF-fuh00KoA4";
const PDV_BASE = `https://firestore.googleapis.com/v1/projects/tenda-pro-57fff/databases/(default)/documents`;

type PdvProduct = {
  id: string;
  name: string;
  unitPrice: number;
  stock: number;
};

type HistoryLine = { direction: string; body: string };

export type PrintJobRow = {
  id: number;
  contactId: number | null;
  title: string;
  kind: string;
  mime: string;
  payload: string;
  status: string;
  copies: number;
  createdAt: string;
};

export type ShopJobRow = {
  id: number;
  contactId: number | null;
  kind: string;
  title: string;
  detail: string;
  status: string;
  hasFile: boolean;
  createdAt: string;
};

type ResumeDraft = {
  ready?: boolean;
  name?: string;
  phone?: string;
  email?: string;
  city?: string;
  address?: string;
  neighborhood?: string;
  birthDate?: string;
  maritalStatus?: string;
  education?: string;
  courses?: { name?: string; institution?: string }[];
  experience?: { company?: string; role?: string; period?: string }[];
  objective?: string;
};

type SaleDraft = {
  ready?: boolean;
  payment?: string;
  lines?: { name?: string; qty?: number }[];
};

function clip(value: string, max: number): string {
  return value.trim().slice(0, max);
}

function norm(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9 ]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function latin(value: string): string {
  return value.normalize("NFC").replace(/[^\u0000-\u00ff]/g, "").trim();
}

function dataUrl(bytes: Uint8Array, mime: string): string | null {
  if (bytes.byteLength > 4_000_000) return null;
  return `data:${mime.split(";")[0]};base64,${Buffer.from(bytes).toString("base64")}`;
}

function asRecord(text: string): Record<string, unknown> | null {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const value = JSON.parse(text.slice(start, end + 1)) as unknown;
    return value && typeof value === "object" ? (value as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

function numField(value: number): { integerValue: string } | { doubleValue: number } {
  const rounded = Math.round(value * 100) / 100;
  if (Number.isInteger(rounded)) return { integerValue: String(rounded) };
  return { doubleValue: rounded };
}

function readNumber(field: { integerValue?: string; doubleValue?: number } | undefined): number {
  if (!field) return 0;
  if (field.integerValue != null) return Number(field.integerValue);
  if (field.doubleValue != null) return field.doubleValue;
  return 0;
}

async function pdvProducts(): Promise<PdvProduct[]> {
  const g = globalThis as typeof globalThis & { __pdvProducts?: { at: number; rows: PdvProduct[] } };
  if (g.__pdvProducts && Date.now() - g.__pdvProducts.at < 10 * 60 * 1000) return g.__pdvProducts.rows;
  const rows: PdvProduct[] = [];
  let page = "";
  for (let i = 0; i < 5; i += 1) {
    const url = `${PDV_BASE}/products?pageSize=200&key=${PDV_KEY}${page ? `&pageToken=${encodeURIComponent(page)}` : ""}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
    if (!res.ok) break;
    const body = (await res.json()) as {
      documents?: { name: string; fields?: Record<string, { stringValue?: string; integerValue?: string; doubleValue?: number }> }[];
      nextPageToken?: string;
    };
    for (const doc of body.documents ?? []) {
      const fields = doc.fields ?? {};
      const name = fields.name?.stringValue ?? "";
      if (!name) continue;
      rows.push({
        id: doc.name.split("/").pop() || "",
        name,
        unitPrice: readNumber(fields.unitPrice),
        stock: readNumber(fields.stock),
      });
    }
    if (!body.nextPageToken) break;
    page = body.nextPageToken;
  }
  g.__pdvProducts = { at: Date.now(), rows };
  return rows;
}

function matchProduct(products: PdvProduct[], spoken: string): PdvProduct | null {
  const want = norm(spoken);
  if (want.length < 3) return null;
  let best: { score: number; product: PdvProduct } | null = null;
  for (const product of products) {
    const have = norm(product.name);
    if (!have) continue;
    let score = 0;
    if (have === want) score = 100;
    else if (have.includes(want) || want.includes(have)) score = 80;
    else {
      const tokens = want.split(" ").filter((token) => token.length > 2);
      const hits = tokens.filter((token) => have.includes(token)).length;
      if (tokens.length && hits === tokens.length) score = 70;
      else if (hits >= 2) score = 50;
    }
    if (score && (!best || score > best.score)) best = { score, product };
  }
  return best && best.score >= 50 ? best.product : null;
}

async function pdfPages(bytes: Uint8Array): Promise<Uint8Array[]> {
  try {
    const { getDocumentProxy, renderPageAsImage } = await import("unpdf");
    const doc = await getDocumentProxy(bytes.slice());
    const total = Math.min(doc.numPages || 1, 6);
    const pages: Uint8Array[] = [];
    for (let page = 1; page <= total; page += 1) {
      const image = await renderPageAsImage(bytes.slice(), page, {
        canvasImport: () => import("@napi-rs/canvas"),
        scale: 1.3,
      });
      pages.push(new Uint8Array(image));
    }
    return pages;
  } catch (error) {
    console.error("pdf print", error instanceof Error ? error.message : "fail");
    return [];
  }
}

export async function queueCustomerFile(input: {
  userId: string;
  contactId: number;
  kind: string;
  text: string;
  bytes?: Uint8Array;
  mime?: string;
  filename?: string;
  isReceipt: boolean;
}): Promise<void> {
  if ((input.kind !== "pdf" && input.kind !== "image") || !input.bytes) return;
  const asked = /imprim|impress|xerox|c[oó]pia|print/i.test(input.text);
  if (input.kind === "image" && input.isReceipt && !asked) return;
  const sql = await getSql();
  await sql`
    delete from print_jobs
    where user_id = ${input.userId} and contact_id = ${input.contactId} and status = 'aguardando'
  `;
  const mime = input.mime || (input.kind === "pdf" ? "application/pdf" : "image/jpeg");
  const payload = dataUrl(input.bytes, mime);
  const title = input.filename || (input.kind === "pdf" ? "PDF do cliente" : "Foto do cliente");
  if (!payload) return;
  const rows = await sql<{ id: number }>`
    insert into print_jobs (user_id, contact_id, title, kind, mime, payload, status)
    values (${input.userId}, ${input.contactId}, ${clip(title, 120)}, ${input.kind}, ${mime}, ${payload}, 'aguardando')
    returning id
  `;
  if (asked && rows[0]?.id) await activateOne(input.userId, rows[0].id, copiesOf(input.text));
}

function copiesOf(text: string): number {
  const said = text
    .toLowerCase()
    .replace(/[óòõ]/g, "o")
    .replace(/[áàãâ]/g, "a")
    .replace(/[éê]/g, "e")
    .replace(/[í]/g, "i");
  const digit = said.match(/(\d{1,2})\s*(copias|vias|vezes|x\b)/) || said.match(/(?:imprim\w*|manda\w*|quero|faz\w*|tira\w*)\s+(\d{1,2})\b/);
  const raw = digit?.[1] || digit?.[2];
  if (raw) {
    const count = Number(raw);
    if (count >= 1 && count <= 10) return count;
  }
  const words: Array<[string, number]> = [
    ["duas", 2],
    ["dois", 2],
    ["tres", 3],
    ["quatro", 4],
    ["cinco", 5],
    ["seis", 6],
    ["sete", 7],
    ["oito", 8],
    ["nove", 9],
    ["dez", 10],
  ];
  for (const [word, count] of words) {
    if (new RegExp(`${word}\\s*(copias|vias|vezes)`).test(said)) return count;
  }
  if (/triplic/.test(said)) return 3;
  if (/duplic/.test(said)) return 2;
  return 1;
}

async function activateOne(userId: string, id: number, copies: number): Promise<void> {
  const sql = await getSql();
  const count = Math.min(10, Math.max(1, copies));
  await sql`
    delete from print_jobs
    where user_id = ${userId}
      and id <> ${id}
      and status in ('na_fila', 'imprimindo', 'aguardando')
  `;
  await sql`
    update print_jobs
    set status = 'na_fila', created_at = now(), copies = ${count}
    where id = ${id} and user_id = ${userId}
  `;
}

function clienteAutorizou(text: string): boolean {
  const said = (text.split("\n")[0] ?? "").trim();
  if (!said || said.length > 80) return false;
  return /imprim|xerox|c[oó]pia|vias|\bprint\b|^sim$|^pode$|^ok$|^isso$|^manda$|^quero$|^pode sim$|^t[aá]$/i.test(said);
}

async function hasWaitingFile(userId: string, contactId: number): Promise<boolean> {
  const sql = await getSql();
  const rows = await sql<{ id: number }>`
    select id from print_jobs
    where user_id = ${userId} and contact_id = ${contactId} and status = 'aguardando' and kind <> 'curriculo'
    limit 1
  `;
  return Boolean(rows[0]);
}

export async function activateWaiting(userId: string, contactId: number, text: string): Promise<string> {
  const sql = await getSql();
  const rows = await sql<{ id: number; title: string }>`
    select id, title from print_jobs
    where user_id = ${userId} and contact_id = ${contactId} and status = 'aguardando' and kind <> 'curriculo'
    order by id desc
    limit 1
  `;
  const job = rows[0];
  const copies = copiesOf(text);
  if (!job) {
    if (copies <= 1) return "";
    const queued = await sql<{ id: number; title: string }>`
      select id, title from print_jobs
      where user_id = ${userId} and contact_id = ${contactId} and status = 'na_fila' and kind <> 'curriculo'
      order by id desc
      limit 1
    `;
    const waiting = queued[0];
    if (!waiting) return "";
    await sql`update print_jobs set copies = ${copies} where id = ${waiting.id} and user_id = ${userId} and status = 'na_fila'`;
    return `O cliente pediu ${copies} cópias de ${waiting.title}. Vai sair essa quantidade. Confirme numa frase.`;
  }
  await activateOne(userId, job.id, copies);
  const vezes = copies > 1 ? ` São ${copies} cópias.` : "";
  return `O cliente autorizou. ${job.title} está saindo na impressora agora.${vezes} Confirme numa frase curta. Não fale de fila nem de sistema.`;
}

async function draftResume(transcript: string): Promise<ResumeDraft | null> {
  const raw = await askJson(
    `Extraia um currículo brasileiro do diálogo. Responda só JSON:
{"ready":false,"name":"","phone":"","email":"","city":"","address":"","neighborhood":"","birthDate":"","maritalStatus":"","education":"","courses":[{"name":"","institution":""}],"experience":[{"company":"","role":"","period":""}],"objective":""}
ready true só se houver nome e pelo menos escolaridade, um curso ou uma experiência. Não invente emprego, data ou cidade que a pessoa não disse.`,
    transcript.slice(0, 6000),
  );
  return asRecord(raw) as ResumeDraft | null;
}

async function draftSale(transcript: string): Promise<SaleDraft | null> {
  const raw = await askJson(
    `Extraia a venda que ficou combinada. Responda só JSON:
{"ready":false,"payment":"Pix","lines":[{"name":"","qty":1}]}
payment é um de: Pix, Dinheiro, Crédito, Débito, Crediário.
ready true só se der para saber o que foi vendido e a quantidade. Não invente item. qty é número.`,
    transcript.slice(0, 6000),
  );
  return asRecord(raw) as SaleDraft | null;
}

function transcriptOf(history: HistoryLine[], current: string): string {
  const lines = history.map((item) => `${item.direction === "out" ? "Balcão" : "Cliente"}: ${item.body}`);
  lines.push(`Cliente: ${current}`);
  return lines.join("\n");
}

async function buildResumePdf(draft: ResumeDraft): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  const page = doc.addPage([595, 842]);
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  const ink = rgb(0.1, 0.14, 0.2);
  const pine = rgb(0.1, 0.35, 0.28);
  let y = 800;
  const write = (text: string, size: number, strong = false, color = ink) => {
    const clean = latin(text);
    if (!clean) return;
    const face = strong ? bold : font;
    const words = clean.split(/\s+/);
    let line = "";
    const flush = () => {
      if (!line || y < 48) return;
      page.drawText(line, { x: 48, y, size, font: face, color });
      y -= size + 4;
      line = "";
    };
    for (const word of words) {
      const next = line ? `${line} ${word}` : word;
      if (face.widthOfTextAtSize(next, size) > 500) flush();
      line = line ? `${line} ${word}` : word;
    }
    flush();
  };
  write(draft.name || "Currículo", 20, true, pine);
  const contact = [draft.phone, draft.email, draft.city, draft.neighborhood, draft.address].filter(Boolean).join(" · ");
  write(contact, 10);
  const extra = [draft.birthDate && `Nascimento: ${draft.birthDate}`, draft.maritalStatus].filter(Boolean).join(" · ");
  write(extra, 10);
  y -= 8;
  write("Objetivo", 13, true, pine);
  write(
    draft.objective ||
      "Contribuir com minhas habilidades para o crescimento da empresa, buscando sempre o aperfeiçoamento profissional e a excelência no atendimento.",
    11,
  );
  y -= 6;
  if (draft.education) {
    write("Escolaridade", 13, true, pine);
    write(draft.education, 11);
    y -= 6;
  }
  const courses = (draft.courses ?? []).filter((course) => course.name);
  if (courses.length) {
    write("Cursos", 13, true, pine);
    for (const course of courses) write(`- ${course.name}${course.institution ? ` - ${course.institution}` : ""}`, 11);
    y -= 6;
  }
  const jobs = (draft.experience ?? []).filter((job) => job.company || job.role);
  if (jobs.length) {
    write("Experiência", 13, true, pine);
    for (const job of jobs) {
      write(`- ${[job.role, job.company, job.period].filter(Boolean).join(" - ")}`, 11);
    }
  }
  return doc.save();
}

async function alreadyDone(userId: string, contactId: number, kind: string, detail: string): Promise<boolean> {
  const sql = await getSql();
  const rows = await sql<{ id: number }>`
    select id from shop_jobs
    where user_id = ${userId} and contact_id = ${contactId} and kind = ${kind} and detail = ${detail}
      and created_at > now() - interval '12 hours'
    limit 1
  `;
  return Boolean(rows[0]);
}

async function saveShopJob(input: {
  userId: string;
  contactId: number;
  kind: string;
  title: string;
  detail: string;
  externalId?: string;
  payload?: string;
}): Promise<void> {
  const sql = await getSql();
  await sql`
    insert into shop_jobs (user_id, contact_id, kind, title, detail, external_id, payload)
    values (
      ${input.userId},
      ${input.contactId},
      ${input.kind},
      ${clip(input.title, 140)},
      ${clip(input.detail, 400)},
      ${input.externalId ?? ""},
      ${input.payload ?? ""}
    )
  `;
}

async function postSale(input: {
  userId: string;
  contactId: number;
  waId: string;
  draft: SaleDraft;
}): Promise<string> {
  const lines = (input.draft.lines ?? []).filter((line) => line.name && (line.qty ?? 0) > 0);
  if (!input.draft.ready || lines.length === 0) return "";
  const products = await pdvProducts();
  const items: {
    product: PdvProduct;
    qty: number;
  }[] = [];
  for (const line of lines) {
    const product = matchProduct(products, line.name || "");
    if (!product) continue;
    items.push({ product, qty: Math.min(99, Math.max(0.1, Number(line.qty) || 1)) });
  }
  if (items.length === 0) return "Não achei esses itens no PDV, então não lancei a venda.";
  const payment = ["Pix", "Dinheiro", "Crédito", "Débito", "Crediário"].includes(input.draft.payment || "")
    ? (input.draft.payment as string)
    : "Pix";
  const fingerprint = `${payment}|${items.map((item) => `${item.product.id}x${item.qty}`).join(",")}`;
  if (await alreadyDone(input.userId, input.contactId, "venda", fingerprint)) {
    return "Essa venda já está no PDV.";
  }
  const subtotal = items.reduce((sum, item) => sum + item.qty * item.product.unitPrice, 0);
  const fees = payment === "Crédito" ? subtotal * 0.055 : payment === "Débito" ? subtotal * 0.025 : 0;
  const total = Math.round((subtotal + fees) * 100) / 100;
  const fields: Record<string, unknown> = {
    date: { timestampValue: new Date().toISOString() },
    sellerId: { stringValue: "admin-francisco" },
    sellerName: { stringValue: "Balcão (Zap)" },
    customerName: { stringValue: "WhatsApp" },
    paymentMethod: { stringValue: payment },
    status: { stringValue: "completed" },
    subtotal: numField(subtotal),
    fees: numField(fees),
    discount: numField(0),
    total: numField(total),
    cashbackUsed: numField(0),
    cashbackEarned: numField(0),
    items: {
      arrayValue: {
        values: items.map((item) => ({
          mapValue: {
            fields: {
              productId: { stringValue: item.product.id },
              name: { stringValue: item.product.name },
              quantity: numField(item.qty),
              price: numField(item.product.unitPrice),
              originalPrice: numField(item.product.unitPrice),
              discount: numField(0),
              total: numField(item.qty * item.product.unitPrice),
            },
          },
        })),
      },
    },
  };
  if (payment === "Dinheiro") {
    fields.receivedAmount = numField(total);
    fields.change = numField(0);
  }
  const res = await fetch(`${PDV_BASE}/sales?key=${PDV_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fields }),
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) return "O PDV não aceitou a venda agora.";
  const created = (await res.json()) as { name?: string };
  const saleId = created.name?.split("/").pop() || "";
  for (const item of items) {
    const next = item.product.stock - item.qty;
    item.product.stock = next;
    await fetch(`${PDV_BASE}/products/${item.product.id}?updateMask.fieldPaths=stock&key=${PDV_KEY}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fields: { stock: numField(next) } }),
      signal: AbortSignal.timeout(10000),
    }).catch(() => undefined);
  }
  const names = items.map((item) => `${item.qty} ${item.product.name}`).join(", ");
  const money = total.toFixed(2).replace(".", ",");
  await saveShopJob({
    userId: input.userId,
    contactId: input.contactId,
    kind: "venda",
    title: `Venda R$ ${money}`,
    detail: fingerprint,
    externalId: saleId,
  });
  await insertMessage(
    input.userId,
    input.contactId,
    "out",
    "nota",
    `Venda lançada no PDV (${payment}): ${names}. Total R$ ${money}.`,
  );
  return `A venda já foi lançada no PDV: ${names}, ${payment}, R$ ${money}.`;
}

async function makeResume(input: {
  userId: string;
  contactId: number;
  waId: string;
  draft: ResumeDraft;
}): Promise<string> {
  if (!input.draft.ready || !input.draft.name) return "";
  const fingerprint = norm(input.draft.name);
  if (await alreadyDone(input.userId, input.contactId, "curriculo", fingerprint)) {
    return "O currículo dessa pessoa já foi montado hoje.";
  }
  const bytes = await buildResumePdf(input.draft);
  const payload = dataUrl(bytes, "application/pdf") ?? "";
  const { sendFileToContact } = await import("./wa-link.server");
  const sent = input.waId.startsWith("local:")
    ? "offline"
    : await sendFileToContact(input.userId, input.waId, bytes, "application/pdf", `Curriculo-${input.draft.name}.pdf`);
  await saveShopJob({
    userId: input.userId,
    contactId: input.contactId,
    kind: "curriculo",
    title: input.draft.name,
    detail: fingerprint,
    payload,
  });
  const prova = input.waId.startsWith("local:");
  await insertMessage(
    input.userId,
    input.contactId,
    "out",
    "nota",
    prova
      ? `Currículo de ${input.draft.name} montado na Prova. Ainda não foi para a impressora.`
      : sent === "sent"
        ? `Currículo de ${input.draft.name} enviado no WhatsApp para a pessoa ver. Ainda não foi para a impressora.`
        : `Currículo de ${input.draft.name} montado, mas o WhatsApp não estava ligado.`,
  );
  if (prova) {
    return `Isto é a Prova, não o WhatsApp. O PDF de ${input.draft.name} está na conversa, no botão Ver PDF. Não diga que mandou no Zap nem que já pode buscar. Pergunte se ficou do agrado. Só imprime depois que a pessoa aprovar.`;
  }
  if (sent === "sent") {
    return `O PDF do currículo de ${input.draft.name} já foi enviado no WhatsApp para a pessoa ver. Não diga que já imprimiu nem que pode buscar. Pergunte se ficou do agrado. Só imprime depois que ela aprovar.`;
  }
  return `O currículo de ${input.draft.name} foi montado, mas o WhatsApp não estava ligado, então o PDF não chegou na pessoa. Não diga que já foi impresso.`;
}

function aprovouImpressao(text: string): boolean {
  return /(pode|manda|quero|deixa).{0,24}imprim|imprim.{0,16}(sim|agora|pode)|gostei|ficou bom|ficou [oó]timo|aprovo|aprovado|do meu agrado/i.test(
    text,
  );
}

async function queueResumePrint(userId: string, contactId: number, text: string): Promise<string> {
  const sql = await getSql();
  const ready = await sql<{ id: number; title: string; payload: string }>`
    select id, title, payload from shop_jobs
    where user_id = ${userId} and contact_id = ${contactId} and kind = 'curriculo' and payload <> ''
    order by id desc
    limit 1
  `;
  const job = ready[0];
  if (!job) return "";
  const queued = await sql<{ id: number }>`
    select id from print_jobs
    where user_id = ${userId} and contact_id = ${contactId} and kind = 'curriculo'
      and status in ('na_fila', 'imprimindo')
    limit 1
  `;
  if (queued[0]) return "O currículo já está saindo na impressora.";
  const rows = await sql<{ id: number }>`
    insert into print_jobs (user_id, contact_id, title, kind, mime, payload, status)
    values (${userId}, ${contactId}, ${clip(`Currículo ${job.title}`, 120)}, 'curriculo', 'application/pdf', ${job.payload}, 'aguardando')
    returning id
  `;
  if (rows[0]?.id) await activateOne(userId, rows[0].id, copiesOf(text));
  await insertMessage(userId, contactId, "out", "nota", `Currículo de ${job.title} aprovado e enviado para a impressora.`);
  return `A pessoa aprovou o currículo de ${job.title}. Ele vai sair na impressora agora. Confirme numa frase, sem falar de sistema.`;
}

export async function attendOffice(input: {
  userId: string;
  contactId: number;
  waId: string;
  customerText: string;
  history: HistoryLine[];
  pix: PixRead | null;
  kind: string;
  force?: "curriculo" | "venda";
}): Promise<string> {
  const blob = `${input.history.map((item) => item.body).join("\n")}\n${input.customerText}`;
  const wantsResume = input.force === "curriculo" || /curr[ií]culo|curriculum/i.test(blob);
  const wantsSale =
    input.force === "venda" ||
    input.pix?.decision.status === "liberado" ||
    /pode lan[cç]ar|anota(r)? (a )?venda|pedido fechado|pode registrar|fecha(r)? o pedido/i.test(input.customerText);
  const text = transcriptOf(input.history, input.customerText);
  const notes: string[] = [];
  let acabouDeMontar = false;
  if (wantsResume) {
    const draft = await draftResume(text);
    if (draft) {
      const note = await makeResume({ ...input, draft });
      if (note) {
        notes.push(note);
        acabouDeMontar =
          note.startsWith("Isto é a Prova") ||
          note.startsWith("O PDF do currículo") ||
          note.startsWith("O currículo de");
      }
    }
  }
  if (!acabouDeMontar && input.force !== "venda" && aprovouImpressao(input.customerText)) {
    const waiting = await hasWaitingFile(input.userId, input.contactId);
    if (!waiting) notes.push(await queueResumePrint(input.userId, input.contactId, input.customerText));
  }
  const arquivo = input.kind === "pdf" || input.kind === "image";
  const autorizou = clienteAutorizou(input.customerText);
  if (autorizou) {
    const printed = await activateWaiting(input.userId, input.contactId, input.customerText);
    if (printed) notes.push(printed);
    else if (arquivo) notes.push("O documento está saindo na impressora agora. Confirme numa frase. Não fale de fila.");
  } else if (arquivo) {
    notes.push("Acabou de chegar um arquivo. Pergunte se pode imprimir. Não diga que já está na impressora.");
  }
  if (wantsSale && !input.waId.startsWith("local:")) {
    const draft = await draftSale(text);
    if (draft) notes.push(await postSale({ ...input, draft }));
  }
  return notes.filter(Boolean).join(" ");
}

export async function listPrintJobs(userId: string, contactId: number): Promise<PrintJobRow[]> {
  const sql = await getSql();
  const rows = await sql<{
    id: number;
    contact_id: number | null;
    title: string;
    kind: string;
    mime: string;
    payload: string;
    status: string;
    created_at: Date | string;
  }>`
    select id, contact_id, title, kind, mime, payload, status, created_at
    from print_jobs
    where user_id = ${userId} and contact_id = ${contactId}
    order by id desc
    limit 8
  `;
  return rows.map((row) => ({
    id: row.id,
    contactId: row.contact_id,
    title: row.title,
    kind: row.kind,
    mime: row.mime,
    payload: row.payload,
    status: row.status,
    copies: 1,
    createdAt: row.created_at instanceof Date ? row.created_at.toISOString() : String(row.created_at),
  }));
}

export async function releaseStuckPrints(userId: string): Promise<void> {
  const sql = await getSql();
  await sql`
    delete from print_jobs
    where user_id = ${userId}
      and kind = 'curriculo'
      and status in ('na_fila', 'imprimindo', 'aguardando')
  `;
  await sql`
    delete from print_jobs
    where user_id = ${userId}
      and status in ('na_fila', 'imprimindo')
      and created_at < now() - interval '3 minutes'
  `;
}

export async function claimNextPrint(userId: string): Promise<PrintJobRow | null> {
  const sql = await getSql();
  const found = await sql<{ id: number }>`
    select id from print_jobs
    where user_id = ${userId} and status = 'na_fila' and payload <> ''
    order by id asc
    limit 1
  `;
  const id = found[0]?.id;
  if (!id) return null;
  const rows = await sql<{
    id: number;
    contact_id: number | null;
    title: string;
    kind: string;
    mime: string;
    payload: string;
    status: string;
    copies: number;
    created_at: Date | string;
  }>`
    update print_jobs set status = 'imprimindo'
    where id = ${id} and user_id = ${userId} and status = 'na_fila'
    returning id, contact_id, title, kind, mime, payload, status, copies, created_at
  `;
  const row = rows[0];
  if (!row) return null;
  const copies = Math.min(10, Math.max(1, Number(row.copies) || 1));
  return {
    id: row.id,
    contactId: row.contact_id,
    title: row.title,
    kind: row.kind,
    mime: row.mime,
    payload: row.payload,
    status: row.status,
    copies,
    createdAt: row.created_at instanceof Date ? row.created_at.toISOString() : String(row.created_at),
  };
}

export async function pendingPrints(userId: string): Promise<number> {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`
    select count(*)::int as n from print_jobs where user_id = ${userId} and status = 'na_fila'
  `;
  return Number(rows[0]?.n ?? 0);
}

export async function markPrinted(userId: string, id: number): Promise<void> {
  const sql = await getSql();
  await sql`update print_jobs set status = 'impresso' where id = ${id} and user_id = ${userId}`;
}

export async function returnPrint(userId: string, id: number): Promise<void> {
  const sql = await getSql();
  await sql`
    update print_jobs set status = 'na_fila'
    where id = ${id} and user_id = ${userId} and status = 'imprimindo'
  `;
}

export async function failPrint(userId: string, id: number): Promise<void> {
  const sql = await getSql();
  await sql`
    update print_jobs set status = 'falhou'
    where id = ${id} and user_id = ${userId} and status in ('na_fila', 'imprimindo')
  `;
}

export async function listShopJobs(userId: string, contactId: number): Promise<ShopJobRow[]> {
  const sql = await getSql();
  const rows = await sql<{
    id: number;
    contact_id: number | null;
    kind: string;
    title: string;
    detail: string;
    status: string;
    payload: string;
    created_at: Date | string;
  }>`
    select id, contact_id, kind, title, detail, status, payload, created_at
    from shop_jobs
    where user_id = ${userId} and contact_id = ${contactId}
    order by id desc
    limit 6
  `;
  return rows.map((row) => ({
    id: row.id,
    contactId: row.contact_id,
    kind: row.kind,
    title: row.title,
    detail: row.detail,
    status: row.status,
    hasFile: Boolean(row.payload),
    createdAt: row.created_at instanceof Date ? row.created_at.toISOString() : String(row.created_at),
  }));
}

export async function jobFile(userId: string, id: number): Promise<{ payload: string; mime: string; title: string } | null> {
  const sql = await getSql();
  const rows = await sql<{ payload: string; title: string; kind: string }>`
    select payload, title, kind from shop_jobs where id = ${id} and user_id = ${userId}
  `;
  const row = rows[0];
  if (!row?.payload) return null;
  return { payload: row.payload, mime: "application/pdf", title: row.title };
}

export async function resendJob(userId: string, id: number): Promise<void> {
  const sql = await getSql();
  const rows = await sql<{ payload: string; title: string; contact_id: number }>`
    select payload, title, contact_id from shop_jobs where id = ${id} and user_id = ${userId}
  `;
  const row = rows[0];
  if (!row?.payload || !row.contact_id) throw new Error("Esse currículo não está mais aqui.");
  const contact = await sql<{ wa_id: string }>`
    select wa_id from contacts where id = ${row.contact_id} and user_id = ${userId}
  `;
  const waId = contact[0]?.wa_id;
  if (!waId || waId.startsWith("local:")) throw new Error("Essa conversa não está no WhatsApp.");
  const bytes = Buffer.from(row.payload.split(",")[1] || "", "base64");
  const { sendFileToContact } = await import("./wa-link.server");
  const sent = await sendFileToContact(userId, waId, bytes, "application/pdf", `Curriculo-${row.title}.pdf`);
  if (sent !== "sent") throw new Error("O WhatsApp não está ligado agora.");
}
