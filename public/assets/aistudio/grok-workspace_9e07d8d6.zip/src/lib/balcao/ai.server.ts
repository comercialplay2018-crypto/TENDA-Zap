import { decideReceipt, parseBrlToCents, type ReceiptDecision } from "./match";
import { brl, type Desk } from "./types";
import { clockIn, openState, promoIsLive, shiftDate } from "./time";

const MODELS = ["grok-4.20", "grok-4.7"];

function key(): string | null {
  const value = process.env.XAI_API_KEY;
  return value && value.trim() ? value.trim() : null;
}

export function aiReady(): boolean {
  return Boolean(key());
}

async function grok(
  messages: unknown[],
  temperature: number,
  maxTokens: number,
): Promise<string> {
  const apiKey = key();
  if (!apiKey) throw new Error("A inteligência do atendente não está disponível agora.");
  let last = "falha";
  for (const model of MODELS) {
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      signal: AbortSignal.timeout(22000),
      body: JSON.stringify({
        model,
        temperature,
        max_tokens: maxTokens,
        messages,
      }),
    });
    if (res.ok) {
      const body = (await res.json()) as {
        choices?: { message?: { content?: string } }[];
      };
      return (body.choices?.[0]?.message?.content ?? "").trim();
    }
    last = `${model} ${res.status}`;
    if (res.status !== 400 && res.status !== 404 && res.status !== 410) break;
  }
  throw new Error(`Falha ao pensar a resposta (${last}).`);
}

export async function transcribe(bytes: Uint8Array, mime: string, hints: string[]): Promise<string> {
  const apiKey = key();
  if (!apiKey) throw new Error("Sem transcrição agora.");
  const form = new FormData();
  form.append("model", "grok-voice-transcribe-2.0");
  form.append("language", "pt");
  form.append("format", "true");
  for (const hint of hints.slice(0, 8)) {
    if (hint.trim()) form.append("keyterm", hint.trim().slice(0, 50));
  }
  const copy = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(copy).set(bytes);
  const type = mime.split(";")[0] || "audio/wav";
  const ext = type.includes("ogg") ? "ogg" : type.includes("mpeg") || type.includes("mp3") ? "mp3" : type.includes("mp4") ? "m4a" : "wav";
  form.append("file", new Blob([copy], { type }), `audio.${ext}`);
  const res = await fetch("https://api.x.ai/v1/stt", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}` },
    body: form,
    signal: AbortSignal.timeout(28000),
  });
  if (!res.ok) throw new Error(`Não ouvi o áudio (${res.status}).`);
  const body = (await res.json()) as { text?: string };
  return (body.text ?? "").trim();
}

export type PixRead = {
  isReceipt: boolean;
  description: string;
  amountCents: number | null;
  paidAtText: string;
  paidDate: string;
  payerName: string;
  favorecido: string;
  banco: string;
  e2eId: string;
  confidence: string;
  decision: ReceiptDecision;
};

function asRecord(text: string): Record<string, unknown> | null {
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = fence?.[1] ?? text;
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const value = JSON.parse(raw.slice(start, end + 1)) as unknown;
    return value && typeof value === "object" ? (value as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

function str(value: unknown, max = 180): string {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

const PIX_PROMPT = `Você lê comprovantes brasileiros de Pix (foto ou texto de PDF) e também descreve outras imagens.
Responda só um JSON, sem markdown, neste formato:
{"isReceipt":false,"description":"","amount":"","paidAt":"","paidDate":"","payerName":"","favorecido":"","banco":"","e2eId":"","confidence":"baixa"}
Regras:
- isReceipt true só se for comprovante de pagamento/Pix/transferência.
- amount exatamente como impresso, ex "50,00".
- paidAt é data e hora impressas, ex "26/10/2026 10:22".
- paidDate só a data AAAA-MM-DD impressa no comprovante. Não converta fuso.
- favorecido é quem RECEBEU. Não confunda com o pagador.
- banco é o banco do favorecido ou o que aparece como instituição de destino.
- e2eId é o identificador da transação se houver.
- confidence: alta, media ou baixa.
- description: uma frase do que é a imagem, mesmo quando não for comprovante.`;

export async function readVisual(input: {
  bytes?: Uint8Array;
  mime?: string;
  pdfText?: string;
  expectedFavorecido: string;
  today: string;
  yesterday: string;
}): Promise<PixRead> {
  const content: unknown[] = [{ type: "text", text: PIX_PROMPT }];
  if (input.pdfText) {
    content.push({
      type: "text",
      text: `Texto extraído do PDF:\n${input.pdfText.slice(0, 8000)}`,
    });
  }
  if (input.bytes && input.mime?.startsWith("image/")) {
    const mime = input.mime.split(";")[0] || "image/jpeg";
    const b64 = Buffer.from(input.bytes).toString("base64");
    content.push({ type: "image_url", image_url: { url: `data:${mime};base64,${b64}` } });
  }
  let raw = "";
  try {
    raw = await grok(
      [
        { role: "system", content: "Você extrai dados. Só JSON." },
        { role: "user", content },
      ],
      0.1,
      450,
    );
  } catch {
    raw = "";
  }
  const json = asRecord(raw) ?? {};
  const amountRaw = str(json.amount, 40);
  const paidDate = /^\d{4}-\d{2}-\d{2}$/.test(str(json.paidDate, 10)) ? str(json.paidDate, 10) : "";
  const read: Omit<PixRead, "decision"> = {
    isReceipt: json.isReceipt === true,
    description: str(json.description, 240),
    amountCents: parseBrlToCents(amountRaw),
    paidAtText: str(json.paidAt, 40),
    paidDate,
    payerName: str(json.payerName),
    favorecido: str(json.favorecido),
    banco: str(json.banco),
    e2eId: str(json.e2eId, 80),
    confidence: str(json.confidence, 12).toLowerCase() || "baixa",
  };
  const decision = decideReceipt({
    isReceipt: read.isReceipt,
    amountCents: read.amountCents,
    favorecido: read.favorecido,
    expectedFavorecido: input.expectedFavorecido,
    paidDate: read.paidDate,
    today: input.today,
    yesterday: input.yesterday,
    confidence: read.confidence,
    banco: read.banco,
  });
  return { ...read, decision };
}

function facts(desk: Desk): string {
  const clock = clockIn(desk.shop.timezone);
  const state = openState(clock, desk.hours, desk.exceptions);
  const lines: string[] = [];
  lines.push(`Agora: ${clock.label} (${desk.shop.timezone}).`);
  lines.push(state.reason);
  const shopName = desk.shop.name || "comércio sem nome cadastrado";
  lines.push(`Loja: ${shopName}.`);
  if (desk.shop.attendantName) lines.push(`Quem fala se chama ${desk.shop.attendantName}.`);
  if (desk.shop.about) lines.push(`O que fazem: ${desk.shop.about}`);
  if (desk.shop.voice) lines.push(`Jeito pedido pelo dono: ${desk.shop.voice}`);
  if (desk.products.length === 0) lines.push("Nenhum produto cadastrado. Não invente preço.");
  else {
    lines.push("Produtos:");
    for (const product of desk.products) {
      const flag = product.available ? "disponível" : "em falta";
      lines.push(`- ${product.name}: ${brl(product.priceCents)} / ${product.unit} (${flag})${product.details ? ` — ${product.details}` : ""}`);
    }
  }
  const promos = desk.promos.filter((p) => promoIsLive(p));
  if (promos.length === 0) lines.push("Nenhuma promoção relâmpago valendo agora.");
  else {
    lines.push("Promoções valendo agora (só cite se o assunto for preço, promoção ou o item):");
    for (const promo of promos) lines.push(`- ${promo.title}: ${promo.details}`);
  }
  const notices = desk.notices.filter((n) => n.active);
  if (notices.length) {
    lines.push("Avisos que importam:");
    for (const notice of notices) lines.push(`- ${notice.body}`);
  }
  if (desk.shop.pixFavorecido || desk.shop.pixKey) {
    lines.push(
      `Pix cadastrado: favorecido "${desk.shop.pixFavorecido || "?"}", banco "${desk.shop.pixBanco || "?"}", chave "${desk.shop.pixKey || "?"}". Só passe a chave se pedirem para pagar.`,
    );
  }
  return lines.join("\n");
}

function cleanReply(text: string): string {
  let out = text.replace(/^["“]|["”]$/g, "").replace(/\*\*/g, "").trim();
  out = out.replace(/^(atendente|assistente|balcão)\s*:\s*/i, "");
  if (out.length > 700) out = out.slice(0, 700).trim();
  return out;
}

export async function composeReply(input: {
  desk: Desk;
  history: { direction: string; body: string; kind: string }[];
  customerText: string;
  pix: PixRead | null;
  extraFact?: string;
}): Promise<string> {
  const who = input.desk.shop.attendantName
    ? `Você é ${input.desk.shop.attendantName} e atende no WhatsApp`
    : "Você atende no WhatsApp";
  const place = input.desk.shop.name ? ` da ${input.desk.shop.name}` : " deste comércio";
  let pixBlock = "Nenhum comprovante nesta mensagem.";
  if (input.pix?.isReceipt) {
    const amount = input.pix.amountCents != null ? brl(input.pix.amountCents) : "valor não lido";
    pixBlock = [
      `Parecer do comprovante: ${input.pix.decision.status.toUpperCase()}.`,
      input.pix.decision.decision,
      `Valor ${amount}. Quando: ${input.pix.paidAtText || "sem hora"}. Favorecido lido: ${input.pix.favorecido || "?"}. Banco: ${input.pix.banco || "?"}. Pagador: ${input.pix.payerName || "?"}.`,
      "Nunca diga que o dinheiro já caiu na conta. Se LIBERADO, diga que recebeu e que segue o pedido, com a conferência final rapidinha no banco. Se DÚVIDA ou RECUSADO, explique o problema numa frase e peça outro comprovante ou a correção, sem ser seco.",
    ].join(" ");
  } else if (input.pix?.description) {
    pixBlock = `A pessoa mandou uma imagem ou PDF que não é comprovante: ${input.pix.description}`;
  }
  let system = `${who}${place}. Escreva como gente de verdade no Zap, em português do Brasil.

Regras:
- 1 a 3 frases. Só passe de umas 40 palavras se pedirem preços ou a lista.
- Proibido: "Olá! Como posso ajudar?", "Claro!", "Certamente", "fico à disposição", menu numerado, "sou uma inteligência artificial", "sou um assistente virtual".
- Não comece igual às mensagens anteriores. Varie o jeito.
- Uma pergunta por vez, e só se precisar.
- Não invente produto, preço, horário, estoque ou promoção. Use só os FATOS.
- Se estiver fechado, diga isso com naturalidade e ofereça anotar para quando abrir. Não prometa entrega agora.
- Promoção relâmpago só entra se a pessoa falar de preço, de promoção, ou do item. Não cole em toda fala.
- Áudio já vem transcrito. Se parecer torto, confirme em uma frase o que entendeu.
- Emoji: no máximo um, e na maioria das vezes nenhum.
- Sem markdown e sem asterisco.
- Se perguntarem se é robô, não faça discurso. Responda curto, no tom do balcão, e volte pro pedido.

FATOS:
${facts(input.desk)}

${pixBlock}`;
  if (input.extraFact) {
    system += `\n\nFATO DESTA HORA (se couber, mencione numa frase, no mesmo tom, sem anunciar sistema):\n${input.extraFact}`;
  }

  const history = input.history.slice(0, -1).map((item) => ({
    role: item.direction === "out" ? "assistant" : "user",
    content: item.body.slice(0, 800),
  }));
  const messages = [
    { role: "system", content: system },
    ...history,
    { role: "user", content: input.customerText.slice(0, 2000) },
  ];
  try {
    const text = cleanReply(await grok(messages, 0.9, 220));
    return text || "Manda de novo? Não peguei direito.";
  } catch {
    return "Deu uma travada aqui. Manda de novo daqui a pouco?";
  }
}

export async function askJson(system: string, user: string): Promise<string> {
  return grok(
    [
      { role: "system", content: system },
      { role: "user", content: user },
    ],
    0.1,
    800,
  );
}
export function todayPair(timeZone: string): { today: string; yesterday: string } {
  const clock = clockIn(timeZone);
  return { today: clock.date, yesterday: shiftDate(clock.date, -1) };
}
