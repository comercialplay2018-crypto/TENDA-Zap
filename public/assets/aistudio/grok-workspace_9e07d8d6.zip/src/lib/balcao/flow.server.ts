import { createHmac, timingSafeEqual } from "node:crypto";
import { extractText, getDocumentProxy } from "unpdf";
import { getSql } from "@/lib/db";
import { composeReply, readVisual, transcribe, todayPair, type PixRead } from "./ai.server";
import {
  countRecentInbound,
  insertMessage,
  insertReceipt,
  loadBundle,
  pauseContact,
  recentHistory,
  seenOnce,
  upsertContact,
  type Bundle,
} from "./repo.server";

const PROVA_ID = "local:prova";

export type Inbound = {
  userId: string;
  waId: string;
  profileName: string;
  waMessageId: string | null;
  kind: "text" | "audio" | "image" | "pdf" | "outro";
  text: string;
  bytes?: Uint8Array;
  mime?: string;
  filename?: string;
  deliver: boolean;
};

async function sendWhatsApp(phoneNumberId: string, token: string, to: string, body: string): Promise<string | null> {
  const res = await fetch(`https://graph.facebook.com/v21.0/${phoneNumberId}/messages`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    signal: AbortSignal.timeout(20000),
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to,
      type: "text",
      text: { body, preview_url: false },
    }),
  });
  if (res.ok) return null;
  let detail = `erro ${res.status}`;
  try {
    const json = (await res.json()) as { error?: { message?: string } };
    if (json.error?.message) detail = json.error.message;
  } catch {
    /* keep status */
  }
  return detail;
}

async function pdfText(bytes: Uint8Array): Promise<string> {
  const doc = await getDocumentProxy(bytes.slice());
  const result = (await extractText(doc, { mergePages: true })) as { text: string | string[] };
  return Array.isArray(result.text) ? result.text.join("\n") : result.text;
}

async function pdfFirstPage(bytes: Uint8Array): Promise<Uint8Array | null> {
  try {
    const { renderPageAsImage } = await import("unpdf");
    const image = await renderPageAsImage(bytes.slice(), 1, {
      canvasImport: () => import("@napi-rs/canvas"),
      scale: 1.4,
    });
    return new Uint8Array(image);
  } catch (error) {
    console.error("pdf page", error instanceof Error ? error.message : "fail");
    return null;
  }
}

function dataUrl(bytes: Uint8Array, mime: string): string | null {
  if (bytes.byteLength > 350_000) return null;
  return `data:${mime.split(";")[0]};base64,${Buffer.from(bytes).toString("base64")}`;
}

async function understand(
  desk: Bundle,
  inbound: Inbound,
): Promise<{ body: string; pix: PixRead | null; storeImage: string | null }> {
  const { today, yesterday } = todayPair(desk.shop.timezone);
  if (inbound.kind === "audio" && inbound.bytes) {
    if (inbound.bytes.byteLength > 8_000_000) {
      return { body: "[áudio grande demais]", pix: null, storeImage: null };
    }
    try {
      const hints = [desk.shop.name, desk.shop.pixFavorecido, "Pix", ...desk.products.slice(0, 5).map((p) => p.name)];
      const text = await transcribe(inbound.bytes, inbound.mime || "audio/wav", hints);
      return { body: text || "[áudio sem fala entendida]", pix: null, storeImage: null };
    } catch {
      return { body: "[áudio que não deu para ouvir]", pix: null, storeImage: null };
    }
  }
  if ((inbound.kind === "image" || inbound.kind === "pdf") && (inbound.bytes || inbound.text)) {
    if (inbound.bytes && inbound.bytes.byteLength > 4_000_000) {
      return { body: `${inbound.text}\n[arquivo grande demais para ler]`.trim(), pix: null, storeImage: null };
    }
    let extracted = "";
    if (inbound.kind === "pdf" && inbound.bytes) {
      try {
        extracted = (await pdfText(inbound.bytes)).replace(/\s+/g, " ").trim().slice(0, 8000);
      } catch {
        extracted = "";
      }
    }
    let visualBytes = inbound.kind === "image" ? inbound.bytes : undefined;
    let visualMime = inbound.mime;
    if (inbound.kind === "pdf" && inbound.bytes && extracted.length < 40) {
      const page = await pdfFirstPage(inbound.bytes);
      if (page) {
        visualBytes = page;
        visualMime = "image/png";
      }
    }
    const pix = await readVisual({
      bytes: visualBytes,
      mime: visualMime,
      pdfText: extracted || undefined,
      expectedFavorecido: desk.shop.pixFavorecido,
      today,
      yesterday,
    });
    const caption = inbound.text ? `${inbound.text}\n` : "";
    if (pix.isReceipt) {
      const amount =
        pix.amountCents != null ? `R$ ${(pix.amountCents / 100).toFixed(2).replace(".", ",")}` : "valor ?";
      return {
        body: `${caption}Comprovante: ${amount}. ${pix.favorecido || "favorecido ?"}. ${pix.banco || "banco ?"}. ${pix.paidAtText || pix.paidDate || "sem data"}.`,
        pix,
        storeImage: inbound.kind === "image" && inbound.bytes && inbound.mime ? dataUrl(inbound.bytes, inbound.mime) : null,
      };
    }
    return {
      body: `${caption}${pix.description || extracted.slice(0, 500) || "[arquivo sem leitura]"}`.trim(),
      pix: pix.description || extracted ? pix : null,
      storeImage: null,
    };
  }
  return { body: inbound.text || "[mensagem vazia]", pix: null, storeImage: null };
}

export async function handleIncoming(inbound: Inbound): Promise<{ reply: string | null; contactId: number }> {
  if (inbound.waMessageId) {
    const fresh = await seenOnce(inbound.userId, inbound.waMessageId);
    if (!fresh) {
      const contact = await upsertContact(inbound.userId, inbound.waId, inbound.profileName);
      return { reply: null, contactId: contact.id };
    }
  }
  const desk = await loadBundle(inbound.userId);
  const contact = await upsertContact(inbound.userId, inbound.waId, inbound.profileName);
  let understood: { body: string; pix: PixRead | null; storeImage: string | null };
  try {
    understood = await understand(desk, inbound);
  } catch {
    understood = { body: inbound.text || "[não consegui ler esta mensagem]", pix: null, storeImage: null };
  }
  await insertMessage(inbound.userId, contact.id, "in", inbound.kind, understood.body);

  try {
    const { queueCustomerFile } = await import("./office.server");
    await queueCustomerFile({
      userId: inbound.userId,
      contactId: contact.id,
      kind: inbound.kind,
      text: inbound.text,
      bytes: inbound.bytes,
      mime: inbound.mime,
      filename: inbound.filename,
      isReceipt: Boolean(understood.pix?.isReceipt),
    });
  } catch (error) {
    console.error("print queue", error instanceof Error ? error.message : "fail");
  }

  if (understood.pix?.isReceipt) {
    await insertReceipt({
      userId: inbound.userId,
      contactId: contact.id,
      contactName: contact.name || inbound.profileName,
      waId: inbound.waId,
      payerName: understood.pix.payerName,
      favorecido: understood.pix.favorecido,
      banco: understood.pix.banco,
      amountCents: understood.pix.amountCents,
      paidAtText: understood.pix.paidAtText,
      paidDate: understood.pix.paidDate,
      e2eId: understood.pix.e2eId,
      confidence: understood.pix.confidence,
      nameMatches: understood.pix.decision.nameMatches,
      decision: understood.pix.decision.decision,
      status: understood.pix.decision.status,
      note: understood.pix.description,
      mediaDataUrl: understood.storeImage,
    });
  }

  const burst = await countRecentInbound(contact.id);
  if (burst > 20) {
    await pauseContact(contact.id, inbound.userId);
    await insertMessage(
      inbound.userId,
      contact.id,
      "out",
      "nota",
      "Pausa automática: muitas mensagens seguidas. O atendente parou nesta conversa.",
    );
    return { reply: null, contactId: contact.id };
  }
  if (!desk.shop.botEnabled || contact.botPaused) {
    return { reply: null, contactId: contact.id };
  }

  const history = await recentHistory(contact.id);
  let extraFact = "";
  try {
    const { attendOffice } = await import("./office.server");
    extraFact = await attendOffice({
      userId: inbound.userId,
      contactId: contact.id,
      waId: inbound.waId,
      customerText: understood.body,
      history,
      pix: understood.pix,
      kind: inbound.kind,
    });
  } catch (error) {
    console.error("office", error instanceof Error ? error.message : "fail");
  }
  const reply = await composeReply({
    desk,
    history,
    customerText: understood.body,
    pix: understood.pix && (understood.pix.isReceipt || understood.pix.description) ? understood.pix : null,
    extraFact,
  });
  await insertMessage(inbound.userId, contact.id, "out", "text", reply);

  if (inbound.deliver && desk.secrets.phoneNumberId && desk.secrets.accessToken && !inbound.waId.startsWith("local:")) {
    const error = await sendWhatsApp(desk.secrets.phoneNumberId, desk.secrets.accessToken, inbound.waId, reply);
    if (error) {
      await insertMessage(inbound.userId, contact.id, "out", "nota", `Não saiu no WhatsApp: ${error}`);
    }
  }
  return { reply, contactId: contact.id };
}

export async function sendHuman(userId: string, contactId: number, text: string): Promise<void> {
  const body = text.trim();
  if (!body) throw new Error("Escreva a mensagem.");
  const sql = await getSql();
  const rows = await sql<{ wa_id: string }>`select wa_id from contacts where id = ${contactId} and user_id = ${userId}`;
  const waId = rows[0]?.wa_id;
  if (!waId) throw new Error("Conversa não encontrada.");
  const desk = await loadBundle(userId);
  await insertMessage(userId, contactId, "out", "text", body);
  if (!waId.startsWith("local:")) {
    const { sendTextToContact } = await import("./wa-link.server");
    const via = await sendTextToContact(userId, waId, body);
    if (via === "sent") return;
    if (via === "failed") throw new Error("Não saiu no WhatsApp ligado.");
    if (desk.secrets.phoneNumberId && desk.secrets.accessToken) {
      const error = await sendWhatsApp(desk.secrets.phoneNumberId, desk.secrets.accessToken, waId, body);
      if (error) throw new Error(error);
    }
  }
}

export async function sendTest(userId: string, to: string, text: string): Promise<void> {
  const digits = to.replace(/\D/g, "");
  if (digits.length < 10 || digits.length > 15) throw new Error("Número com DDI, só dígitos. Exemplo: 5591999999999.");
  const body = text.trim();
  if (!body) throw new Error("Escreva o teste.");
  const { sendTextToContact } = await import("./wa-link.server");
  const via = await sendTextToContact(userId, digits, body);
  if (via === "sent") return;
  if (via === "failed") throw new Error("O WhatsApp ligado não enviou. Tente de novo.");
  const desk = await loadBundle(userId);
  if (!desk.secrets.phoneNumberId || !desk.secrets.accessToken) {
    throw new Error("Ligue o WhatsApp pelo QR antes de testar.");
  }
  const error = await sendWhatsApp(desk.secrets.phoneNumberId, desk.secrets.accessToken, digits, body);
  if (error) throw new Error(error);
}

export function provaWaId(): string {
  return PROVA_ID;
}

export function verifyMetaSignature(raw: string, header: string | null, secret: string): boolean {
  if (!secret) return true;
  if (!header?.startsWith("sha256=")) return false;
  const expected = createHmac("sha256", secret).update(raw).digest("hex");
  const got = header.slice("sha256=".length);
  if (got.length !== expected.length) return false;
  return timingSafeEqual(Buffer.from(got), Buffer.from(expected));
}

type WaMessage = {
  from?: string;
  id?: string;
  type?: string;
  text?: { body?: string };
  audio?: { id?: string };
  image?: { id?: string; caption?: string; mime_type?: string };
  document?: { id?: string; caption?: string; mime_type?: string; filename?: string };
  button?: { text?: string };
  interactive?: { button_reply?: { title?: string }; list_reply?: { title?: string } };
  video?: { caption?: string };
  sticker?: { id?: string };
  location?: { name?: string };
};

type WaValue = {
  metadata?: { phone_number_id?: string; display_phone_number?: string };
  contacts?: { profile?: { name?: string }; wa_id?: string }[];
  messages?: WaMessage[];
};

async function downloadMedia(mediaId: string, token: string): Promise<{ bytes: Uint8Array; mime: string }> {
  const metaRes = await fetch(`https://graph.facebook.com/v21.0/${mediaId}`, {
    headers: { Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(15000),
  });
  if (!metaRes.ok) throw new Error("mídia");
  const meta = (await metaRes.json()) as { url?: string; mime_type?: string };
  if (!meta.url) throw new Error("mídia sem url");
  const fileRes = await fetch(meta.url, {
    headers: { Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(20000),
  });
  if (!fileRes.ok) throw new Error("download");
  const bytes = new Uint8Array(await fileRes.arrayBuffer());
  return { bytes, mime: meta.mime_type || fileRes.headers.get("content-type") || "application/octet-stream" };
}

export async function handleWebhookPayload(userId: string, value: WaValue): Promise<void> {
  const messages = value.messages ?? [];
  if (messages.length === 0) return;
  const desk = await loadBundle(userId);
  const metaPhone = value.metadata?.phone_number_id ?? "";
  if (desk.secrets.phoneNumberId && metaPhone && desk.secrets.phoneNumberId !== metaPhone) return;
  for (const message of messages) {
    const from = message.from ?? "";
    if (!from || !message.id) continue;
    const profile = value.contacts?.find((c) => c.wa_id === from)?.profile?.name ?? "";
    const type = message.type ?? "outro";
    const inbound: Inbound = {
      userId,
      waId: from,
      profileName: profile,
      waMessageId: message.id,
      kind: "outro",
      text: "",
      deliver: true,
    };
    try {
      if (type === "text") {
        inbound.kind = "text";
        inbound.text = message.text?.body ?? "";
      } else if (type === "button" || type === "interactive") {
        inbound.kind = "text";
        inbound.text =
          message.button?.text ||
          message.interactive?.button_reply?.title ||
          message.interactive?.list_reply?.title ||
          "";
      } else if (type === "audio" && message.audio?.id && desk.secrets.accessToken) {
        inbound.kind = "audio";
        const media = await downloadMedia(message.audio.id, desk.secrets.accessToken);
        inbound.bytes = media.bytes;
        inbound.mime = media.mime;
      } else if (type === "image" && message.image?.id && desk.secrets.accessToken) {
        inbound.kind = "image";
        inbound.text = message.image.caption ?? "";
        const media = await downloadMedia(message.image.id, desk.secrets.accessToken);
        inbound.bytes = media.bytes;
        inbound.mime = media.mime || message.image.mime_type || "image/jpeg";
      } else if (type === "document" && message.document?.id && desk.secrets.accessToken) {
        const mime = message.document.mime_type || "";
        inbound.text = message.document.caption || message.document.filename || "";
        const media = await downloadMedia(message.document.id, desk.secrets.accessToken);
        inbound.bytes = media.bytes;
        inbound.mime = media.mime || mime;
        if ((inbound.mime || mime).includes("pdf")) inbound.kind = "pdf";
        else if ((inbound.mime || mime).startsWith("image/")) inbound.kind = "image";
        else inbound.kind = "outro";
      } else if (type === "video") {
        inbound.kind = "outro";
        inbound.text = message.video?.caption || "[a pessoa mandou um vídeo]";
      } else if (type === "sticker") {
        inbound.kind = "outro";
        inbound.text = "[a pessoa mandou uma figurinha]";
      } else if (type === "location") {
        inbound.kind = "outro";
        inbound.text = `[a pessoa mandou uma localização${message.location?.name ? `: ${message.location.name}` : ""}]`;
      } else {
        inbound.kind = "outro";
        inbound.text = "[mensagem de um tipo que o balcão não abre]";
      }
      await handleIncoming(inbound);
    } catch (error) {
      console.error("webhook message", error instanceof Error ? error.message : "fail");
    }
  }
}

export async function ingestWebhook(userId: string, payload: unknown): Promise<void> {
  const body = payload as { entry?: { changes?: { value?: WaValue }[] }[] };
  const entries = body.entry ?? [];
  for (const entry of entries) {
    for (const change of entry.changes ?? []) {
      if (change.value) await handleWebhookPayload(userId, change.value);
    }
  }
}
