alter table print_jobs add column if not exists copies integer not null default 1;
