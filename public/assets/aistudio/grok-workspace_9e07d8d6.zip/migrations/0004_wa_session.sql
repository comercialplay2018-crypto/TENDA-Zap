create table if not exists wa_auth_files (
  user_id text not null,
  name text not null,
  body text not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, name)
);

create table if not exists wa_link_state (
  user_id text primary key,
  holder text not null default '',
  status text not null default 'off',
  phone text not null default '',
  note text not null default '',
  qr text not null default '',
  beat timestamptz not null default now()
);
