create table if not exists shop (
  user_id text primary key,
  name text not null default '',
  attendant_name text not null default '',
  about text not null default '',
  voice text not null default 'Fale curto, do jeito de Zap. Sem texto de robô e sem repetir a mesma abertura. Uma pergunta por vez.',
  pix_key text not null default '',
  pix_favorecido text not null default '',
  pix_banco text not null default '',
  timezone text not null default 'America/Belem',
  bot_enabled boolean not null default true
);

create table if not exists shop_hours (
  user_id text not null,
  weekday int not null,
  closed boolean not null default false,
  opens text not null default '08:00',
  closes text not null default '18:00',
  primary key (user_id, weekday)
);

create table if not exists shop_exceptions (
  id serial primary key,
  user_id text not null,
  on_date date not null,
  kind text not null,
  at_time text,
  note text not null default ''
);

create table if not exists products (
  id serial primary key,
  user_id text not null,
  name text not null,
  price_cents int not null,
  unit text not null default 'un',
  details text not null default '',
  available boolean not null default true
);

create table if not exists promos (
  id serial primary key,
  user_id text not null,
  title text not null,
  details text not null default '',
  starts_at timestamptz,
  ends_at timestamptz,
  active boolean not null default true
);

create table if not exists notices (
  id serial primary key,
  user_id text not null,
  body text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists wa_connection (
  user_id text primary key,
  phone_number_id text not null default '',
  display_phone text not null default '',
  access_token text not null default '',
  verify_token text not null,
  app_secret text not null default ''
);

create table if not exists contacts (
  id serial primary key,
  user_id text not null,
  wa_id text not null,
  name text not null default '',
  bot_paused boolean not null default false,
  updated_at timestamptz not null default now(),
  unique (user_id, wa_id)
);

create table if not exists messages (
  id serial primary key,
  user_id text not null,
  contact_id int not null,
  direction text not null,
  kind text not null default 'text',
  body text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists messages_contact_idx on messages (contact_id, id);

create table if not exists wa_seen (
  user_id text not null,
  wa_message_id text not null,
  primary key (user_id, wa_message_id)
);

create table if not exists receipts (
  id serial primary key,
  user_id text not null,
  contact_id int,
  contact_name text not null default '',
  wa_id text not null default '',
  payer_name text not null default '',
  favorecido text not null default '',
  banco text not null default '',
  amount_cents int,
  paid_at_text text not null default '',
  paid_date text not null default '',
  e2e_id text not null default '',
  confidence text not null default '',
  name_matches boolean,
  decision text not null default '',
  status text not null default 'duvida',
  note text not null default '',
  media_data_url text,
  created_at timestamptz not null default now()
);
