create table if not exists print_jobs (
  id serial primary key,
  user_id text not null,
  contact_id int,
  title text not null default '',
  kind text not null default 'arquivo',
  mime text not null default '',
  payload text not null default '',
  status text not null default 'na_fila',
  created_at timestamptz not null default now()
);

create index if not exists print_jobs_user_idx on print_jobs (user_id, id desc);

create table if not exists shop_jobs (
  id serial primary key,
  user_id text not null,
  contact_id int,
  kind text not null,
  title text not null default '',
  detail text not null default '',
  external_id text not null default '',
  status text not null default 'feito',
  payload text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists shop_jobs_user_idx on shop_jobs (user_id, contact_id, id desc);
