import { o as __toESM } from "../_runtime.mjs";
import { existsSync } from "node:fs";
import { join } from "node:path";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
//#region node_modules/.nitro/vite/services/ssr/assets/wa-link.server-_dZ8_V2n.js
var ROOT = join(process.cwd(), "data", "wa-auth");
function slots() {
	const g = globalThis;
	if (!g.__balcaoWa) g.__balcaoWa = /* @__PURE__ */ new Map();
	return g.__balcaoWa;
}
function folderFor(userId) {
	const safe = userId.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 80) || "user";
	return join(ROOT, safe);
}
function getSlot(userId) {
	const all = slots();
	let slot = all.get(userId);
	if (!slot) {
		slot = {
			status: "off",
			qrDataUrl: null,
			phone: "",
			note: "Ainda não ligado.",
			want: false,
			starting: false,
			since: 0,
			generation: 0,
			sock: null,
			jids: /* @__PURE__ */ new Map(),
			tail: Promise.resolve()
		};
		all.set(userId, slot);
	}
	return slot;
}
function view(slot) {
	return {
		status: slot.status,
		qrDataUrl: slot.qrDataUrl,
		phone: slot.phone,
		note: slot.note
	};
}
async function readJids(folder) {
	try {
		const raw = await readFile(join(folder, "jids.json"), "utf8");
		const parsed = JSON.parse(raw);
		if (!parsed || typeof parsed !== "object") return {};
		const out = {};
		for (const [key, value] of Object.entries(parsed)) if (typeof value === "string" && value.includes("@")) out[key] = value;
		return out;
	} catch {
		return {};
	}
}
async function writeJid(folder, waId, jid, slot) {
	slot.jids.set(waId, jid);
	const body = {};
	for (const [key, value] of slot.jids) body[key] = value;
	await mkdir(folder, { recursive: true });
	await writeFile(join(folder, "jids.json"), JSON.stringify(body));
}
function paired(userId) {
	return existsSync(join(folderFor(userId), "creds.json"));
}
function stampOf(value) {
	if (typeof value === "number") return value;
	if (typeof value === "bigint") return Number(value);
	if (typeof value === "string") return Number(value) || 0;
	if (value && typeof value === "object") {
		const record = value;
		if (typeof record.toNumber === "function") return record.toNumber();
		if (typeof record.low === "number") return record.low;
	}
	return 0;
}
function unwrap(message) {
	let current = message ?? null;
	for (let i = 0; i < 5 && current; i += 1) {
		const inner = current.ephemeralMessage?.message || current.viewOnceMessage?.message || current.viewOnceMessageV2?.message || current.viewOnceMessageV2Extension?.message || current.documentWithCaptionMessage?.message || current.editedMessage?.message;
		if (!inner) break;
		current = inner;
	}
	return current;
}
function kick(userId) {
	const slot = getSlot(userId);
	if (!slot.want || slot.starting || slot.status === "open" || slot.status === "qr") return;
	slot.starting = true;
	slot.since = Date.now();
	slot.status = "connecting";
	if (!slot.note) slot.note = "Conectando no WhatsApp…";
	connect(userId).finally(() => {
		slot.starting = false;
	});
}
function resumeIfPaired(userId) {
	if (!paired(userId)) return view(getSlot(userId));
	return ensureLink(userId);
}
function ensureLink(userId) {
	const slot = getSlot(userId);
	slot.want = true;
	const stuck = slot.status === "connecting" && !slot.starting && Date.now() - slot.since > 2e4;
	if (slot.status === "off" || stuck) kick(userId);
	return view(slot);
}
async function stopLink(userId) {
	const slot = getSlot(userId);
	slot.want = false;
	slot.generation += 1;
	slot.qrDataUrl = null;
	slot.phone = "";
	slot.status = "off";
	slot.note = "Desligado. O celular segue normal.";
	const sock = slot.sock;
	slot.sock = null;
	try {
		await sock?.logout?.();
	} catch {
		try {
			sock?.end?.();
		} catch {}
	}
	await rm(folderFor(userId), {
		recursive: true,
		force: true
	});
	slot.jids.clear();
	return view(slot);
}
async function sendTextToContact(userId, waId, text) {
	const slot = slots().get(userId);
	if (!slot || slot.status !== "open" || !slot.sock) return "offline";
	const folder = folderFor(userId);
	if (slot.jids.size === 0) {
		const saved = await readJids(folder);
		for (const [key, value] of Object.entries(saved)) slot.jids.set(key, value);
	}
	let jid = slot.jids.get(waId) || "";
	if (!jid) {
		const digits = waId.replace(/\D/g, "");
		if (digits.length < 10) return "failed";
		try {
			jid = ((await slot.sock.onWhatsApp?.(digits))?.find((row) => row.exists && row.jid))?.jid || `${digits}@s.whatsapp.net`;
		} catch {
			jid = `${digits}@s.whatsapp.net`;
		}
		await writeJid(folder, waId, jid, slot);
	}
	try {
		try {
			await slot.sock.sendPresenceUpdate?.("composing", jid);
		} catch {}
		await slot.sock.sendMessage(jid, { text });
		try {
			await slot.sock.sendPresenceUpdate?.("paused", jid);
		} catch {}
		return "sent";
	} catch (error) {
		slot.note = error instanceof Error ? error.message : "Não saiu no WhatsApp.";
		return "failed";
	}
}
async function connect(userId) {
	const slot = getSlot(userId);
	const generation = ++slot.generation;
	const previous = slot.sock;
	slot.sock = null;
	try {
		previous?.end?.();
	} catch {}
	const folder = folderFor(userId);
	try {
		const baileys = await import("../_libs/@whiskeysockets/baileys.mjs").then((n) => n.t);
		const qrcode = await import("../_libs/qrcode.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
		const { default: pino } = await import("../_libs/@whiskeysockets/baileys.mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
		await mkdir(folder, { recursive: true });
		const saved = await readJids(folder);
		slot.jids = new Map(Object.entries(saved));
		const { state, saveCreds } = await baileys.useMultiFileAuthState(folder);
		const logger = pino({ level: "silent" });
		let version;
		try {
			version = (await baileys.fetchLatestBaileysVersion()).version;
		} catch {
			version = void 0;
		}
		const sock = baileys.default({
			auth: state,
			version,
			logger,
			printQRInTerminal: false,
			browser: [
				"Balcão",
				"Chrome",
				"120.0.0"
			],
			syncFullHistory: false,
			markOnlineOnConnect: false,
			generateHighQualityLinkPreview: false,
			getMessage: async () => void 0
		});
		if (slot.generation !== generation || !slot.want) {
			sock.end?.();
			return;
		}
		slot.sock = sock;
		slot.note = paired(userId) ? "Religando o WhatsApp…" : "Gerando o QR…";
		sock.ev.on("creds.update", saveCreds);
		sock.ev.on("connection.update", ((update) => {
			onUpdate(userId, generation, update, qrcode.default);
		}));
		sock.ev.on("messages.upsert", ((payload) => {
			onMessages(userId, generation, payload);
		}));
	} catch (error) {
		if (slot.generation !== generation) return;
		slot.status = "off";
		slot.qrDataUrl = null;
		slot.note = error instanceof Error ? error.message : "Não conectou.";
	}
}
async function onUpdate(userId, generation, update, QRCode) {
	const slot = getSlot(userId);
	if (slot.generation !== generation) return;
	if (update.qr) {
		slot.qrDataUrl = await QRCode.toDataURL(update.qr, {
			margin: 1,
			width: 320
		});
		slot.status = "qr";
		slot.note = "No celular: WhatsApp, Aparelhos conectados, Conectar aparelho.";
	}
	if (update.connection === "open") {
		slot.status = "open";
		slot.qrDataUrl = null;
		slot.phone = String(slot.sock?.user?.id ?? "").split(":")[0]?.split("@")[0] ?? "";
		slot.note = slot.phone ? `Ligado em ${slot.phone}. O celular continua no WhatsApp.` : "WhatsApp ligado. O celular continua funcionando.";
		if (slot.phone) try {
			const { getSql } = await import("./db-CHKySlAb.mjs").then((n) => n.t).then((n) => n.t);
			await (await getSql())`update wa_connection set display_phone = ${slot.phone} where user_id = ${userId} and display_phone = ''`;
		} catch {}
	}
	if (update.connection === "close") {
		const baileys = await import("../_libs/@whiskeysockets/baileys.mjs").then((n) => n.t);
		const code = update.lastDisconnect?.error?.output?.statusCode;
		const fatal = code === baileys.DisconnectReason.loggedOut || code === baileys.DisconnectReason.forbidden || code === baileys.DisconnectReason.badSession;
		slot.sock = null;
		slot.qrDataUrl = null;
		if (!slot.want || fatal) {
			slot.status = "off";
			slot.phone = "";
			slot.note = fatal ? "O WhatsApp encerrou a sessão. Escaneie de novo." : "Desligado.";
			if (fatal) {
				await rm(folderFor(userId), {
					recursive: true,
					force: true
				});
				slot.jids.clear();
			}
			return;
		}
		slot.status = "connecting";
		slot.note = "Reconectando…";
		const wait = code === baileys.DisconnectReason.restartRequired ? 500 : 1600;
		setTimeout(() => {
			if (slot.want && slot.generation === generation) kick(userId);
		}, wait);
	}
}
async function onMessages(userId, generation, payload) {
	const slot = getSlot(userId);
	if (slot.generation !== generation || payload.type !== "notify") return;
	for (const message of payload.messages ?? []) slot.tail = slot.tail.then(() => handleOne(userId, generation, message)).catch((error) => {
		console.error("wa message", error instanceof Error ? error.message : "fail");
	});
}
async function handleOne(userId, generation, message) {
	const slot = getSlot(userId);
	if (slot.generation !== generation || slot.status !== "open" || !slot.sock) return;
	if (message.key.fromMe || !message.key.remoteJid || !message.message) return;
	const baileys = await import("../_libs/@whiskeysockets/baileys.mjs").then((n) => n.t);
	const jid = message.key.remoteJid;
	if (baileys.isJidGroup(jid) || baileys.isJidBroadcast(jid) || baileys.isJidStatusBroadcast(jid) || baileys.isJidNewsletter(jid)) return;
	const sentAt = stampOf(message.messageTimestamp);
	const now = Math.floor(Date.now() / 1e3);
	if (sentAt > 0 && now - sentAt > 120) return;
	const content = unwrap(message.message);
	if (!content) return;
	const kind = baileys.getContentType(content);
	if (!kind || kind === "protocolMessage" || kind === "reactionMessage" || kind === "senderKeyDistributionMessage") return;
	const waId = jid.split("@")[0]?.split(":")[0] || "";
	if (!waId) return;
	await writeJid(folderFor(userId), waId, jid, slot);
	try {
		await slot.sock.readMessages?.([message.key]);
	} catch {}
	const inbound = {
		userId,
		waId,
		profileName: message.pushName || "",
		waMessageId: message.key.id || null,
		kind: "outro",
		text: "",
		bytes: void 0,
		mime: void 0,
		filename: void 0,
		deliver: false
	};
	if (kind === "conversation") {
		inbound.kind = "text";
		inbound.text = String(content.conversation ?? "");
	} else if (kind === "extendedTextMessage") {
		inbound.kind = "text";
		inbound.text = String(content.extendedTextMessage?.text ?? "");
	} else if (kind === "imageMessage") {
		inbound.kind = "image";
		inbound.text = String(content.imageMessage?.caption ?? "");
		inbound.mime = String(content.imageMessage?.mimetype ?? "image/jpeg");
		inbound.bytes = await downloadBytes(slot, message);
	} else if (kind === "audioMessage") {
		inbound.kind = "audio";
		inbound.mime = String(content.audioMessage?.mimetype ?? "audio/ogg");
		inbound.bytes = await downloadBytes(slot, message);
	} else if (kind === "documentMessage") {
		const doc = content.documentMessage;
		const mime = doc?.mimetype || "";
		inbound.text = doc?.caption || doc?.fileName || "";
		inbound.filename = doc?.fileName;
		inbound.mime = mime;
		inbound.bytes = await downloadBytes(slot, message);
		if (mime.includes("pdf")) inbound.kind = "pdf";
		else if (mime.startsWith("image/")) inbound.kind = "image";
		else inbound.kind = "outro";
		if (inbound.kind === "outro" && !inbound.text) inbound.text = "[a pessoa mandou um arquivo]";
	} else if (kind === "videoMessage") inbound.text = String(content.videoMessage?.caption || "[a pessoa mandou um vídeo]");
	else if (kind === "stickerMessage") inbound.text = "[a pessoa mandou uma figurinha]";
	else if (kind === "locationMessage") {
		const name = content.locationMessage?.name;
		inbound.text = name ? `[localização: ${name}]` : "[a pessoa mandou uma localização]";
	} else if (kind === "contactMessage") {
		inbound.kind = "text";
		inbound.text = String(content.contactMessage?.displayName || "[contato]");
	} else if (kind === "buttonsResponseMessage") {
		inbound.kind = "text";
		inbound.text = String(content.buttonsResponseMessage?.selectedDisplayText ?? "");
	} else if (kind === "listResponseMessage") {
		inbound.kind = "text";
		const list = content.listResponseMessage;
		inbound.text = list?.title || list?.singleSelectReply?.selectedRowId || "";
	} else inbound.text = "[mensagem de um tipo que o balcão não abre]";
	if (!inbound.text && !inbound.bytes) return;
	const { handleIncoming } = await import("./flow.server-BifjJqaR.mjs");
	const result = await handleIncoming(inbound);
	if (!result.reply || slot.generation !== generation || !slot.sock || slot.status !== "open") return;
	try {
		try {
			await slot.sock.sendPresenceUpdate?.("composing", jid);
		} catch {}
		await slot.sock.sendMessage(jid, { text: result.reply });
		try {
			await slot.sock.sendPresenceUpdate?.("paused", jid);
		} catch {}
	} catch (error) {
		const { insertMessage } = await import("./repo.server-Bz69yhlu.mjs");
		const detail = error instanceof Error ? error.message : "falha";
		await insertMessage(userId, result.contactId, "out", "nota", `Não saiu no WhatsApp: ${detail}`);
	}
}
async function downloadBytes(slot, message) {
	try {
		const baileys = await import("../_libs/@whiskeysockets/baileys.mjs").then((n) => n.t);
		const { default: pino } = await import("../_libs/@whiskeysockets/baileys.mjs").then((n) => /* @__PURE__ */ __toESM(n.n()));
		const buf = await baileys.downloadMediaMessage(message, "buffer", {}, {
			logger: pino({ level: "silent" }),
			reuploadRequest: async (current) => {
				if (!slot.sock?.updateMediaMessage) return current;
				return slot.sock.updateMediaMessage(current);
			}
		});
		const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
		if (bytes.byteLength > 8e6) return void 0;
		return bytes;
	} catch {
		return;
	}
}
//#endregion
export { ensureLink, resumeIfPaired, sendTextToContact, stopLink };
