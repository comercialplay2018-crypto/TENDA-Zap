import { i as getSql } from "./db-CHKySlAb.mjs";
import { i as clockIn, l as promoIsLive, r as brl, s as openState, u as shiftDate } from "./time-kqQZUT9n.mjs";
import { countRecentInbound, insertMessage, insertReceipt, loadBundle, pauseContact, recentHistory, seenOnce, upsertContact } from "./repo.server-Bz69yhlu.mjs";
import { n as getDocumentProxy, t as extractText } from "../_libs/unpdf.mjs";
import { createHmac, timingSafeEqual } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/flow.server-BifjJqaR.js
var STOP = /* @__PURE__ */ new Set([
	"de",
	"da",
	"do",
	"dos",
	"das",
	"e"
]);
function norm(s) {
	return s.normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
}
function tokens(s) {
	return norm(s).split(" ").filter((t) => t.length >= 2 && !STOP.has(t));
}
function namesMatch(expected, found) {
	const a = tokens(expected);
	const b = tokens(found);
	if (a.length === 0 || b.length === 0) return null;
	if (!b.some((x) => x === a[0] || x.startsWith(a[0]) || a[0].startsWith(x))) return false;
	const hit = a.filter((t) => b.some((x) => x === t || x.startsWith(t) || t.startsWith(x)));
	return hit.length === a.length || hit.length >= Math.min(a.length, 2);
}
function decideReceipt(input) {
	if (!input.isReceipt) return {
		status: "recusado",
		nameMatches: null,
		decision: "Não parece comprovante de Pix."
	};
	const nameMatches = namesMatch(input.expectedFavorecido, input.favorecido);
	const bits = [];
	if (!input.expectedFavorecido.trim()) bits.push("cadastre o nome de quem recebe o Pix");
	else if (nameMatches === false) bits.push("o favorecido não bate com o cadastrado");
	else if (nameMatches === null) bits.push("não deu para ler o favorecido");
	if (input.amountCents == null) bits.push("sem valor");
	if (!input.paidDate) bits.push("sem data");
	else if (input.paidDate !== input.today && input.paidDate !== input.yesterday) bits.push("a data não é de hoje nem de ontem");
	if (input.confidence === "baixa") bits.push("leitura fraca");
	if (input.banco) bits.push(`banco lido: ${input.banco}`);
	if (bits.some((b) => !b.startsWith("banco lido"))) return {
		status: nameMatches === false ? "recusado" : "duvida",
		nameMatches,
		decision: bits.join(". ") + "."
	};
	return {
		status: "liberado",
		nameMatches: true,
		decision: `Liberado para a conferência no banco. ${bits.join(". ")}.`.replace("..", ".")
	};
}
function parseBrlToCents(raw) {
	const t = raw.trim().replace(/\s/g, "").replace(/^R\$/i, "");
	if (!t) return null;
	const normalized = t.includes(",") ? t.replace(/\./g, "").replace(",", ".") : t;
	const n = Number(normalized);
	if (!Number.isFinite(n) || n < 0 || n > 1e6) return null;
	return Math.round(n * 100);
}
var MODEL = "grok-4.5";
function key() {
	const value = process.env.XAI_API_KEY;
	return value && value.trim() ? value.trim() : null;
}
async function grok(messages, temperature, maxTokens) {
	const apiKey = key();
	if (!apiKey) throw new Error("A inteligência do atendente não está disponível agora.");
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		signal: AbortSignal.timeout(28e3),
		body: JSON.stringify({
			model: MODEL,
			temperature,
			max_tokens: maxTokens,
			messages
		})
	});
	if (!res.ok) throw new Error(`Falha ao pensar a resposta (${res.status}).`);
	return ((await res.json()).choices?.[0]?.message?.content ?? "").trim();
}
async function transcribe(bytes, mime, hints) {
	const apiKey = key();
	if (!apiKey) throw new Error("Sem transcrição agora.");
	const form = new FormData();
	form.append("model", "grok-voice-transcribe-2.0");
	form.append("language", "pt");
	form.append("format", "true");
	for (const hint of hints.slice(0, 8)) if (hint.trim()) form.append("keyterm", hint.trim().slice(0, 50));
	const copy = new ArrayBuffer(bytes.byteLength);
	new Uint8Array(copy).set(bytes);
	const type = mime.split(";")[0] || "audio/wav";
	const ext = type.includes("ogg") ? "ogg" : type.includes("mpeg") || type.includes("mp3") ? "mp3" : type.includes("mp4") ? "m4a" : "wav";
	form.append("file", new Blob([copy], { type }), `audio.${ext}`);
	const res = await fetch("https://api.x.ai/v1/stt", {
		method: "POST",
		headers: { Authorization: `Bearer ${apiKey}` },
		body: form,
		signal: AbortSignal.timeout(28e3)
	});
	if (!res.ok) throw new Error(`Não ouvi o áudio (${res.status}).`);
	return ((await res.json()).text ?? "").trim();
}
function asRecord(text) {
	const raw = text.match(/```(?:json)?\s*([\s\S]*?)```/)?.[1] ?? text;
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start < 0 || end <= start) return null;
	try {
		const value = JSON.parse(raw.slice(start, end + 1));
		return value && typeof value === "object" ? value : null;
	} catch {
		return null;
	}
}
function str(value, max = 180) {
	return typeof value === "string" ? value.trim().slice(0, max) : "";
}
var PIX_PROMPT = `Você lê comprovantes brasileiros de Pix (foto ou texto de PDF) e também descreve outras imagens.
Responda só um JSON, sem markdown, neste formato:
{"isReceipt":false,"description":"","amount":"","paidAt":"","paidDate":"","payerName":"","favorecido":"","banco":"","e2eId":"","confidence":"baixa"}
Regras:
- isReceipt true só se for comprovante de pagamento/Pix/transferência.
- amount exatamente como impresso, ex "50,00".
- paidAt é data e hora impressas, ex "26/10/2026 10:22".
- paidDate só a data AAAA-MM-DD impressa no comprovante. Não converta fuso.
- favorecido é quem RECEBEU. Não confunda com o pagador.
- banco é o banco do favorecido ou o que aparece como instituição de destino.
- e2eId é o identificador da transação se houver.
- confidence: alta, media ou baixa.
- description: uma frase do que é a imagem, mesmo quando não for comprovante.`;
async function readVisual(input) {
	const content = [{
		type: "text",
		text: PIX_PROMPT
	}];
	if (input.pdfText) content.push({
		type: "text",
		text: `Texto extraído do PDF:\n${input.pdfText.slice(0, 8e3)}`
	});
	if (input.bytes && input.mime?.startsWith("image/")) {
		const mime = input.mime.split(";")[0] || "image/jpeg";
		const b64 = Buffer.from(input.bytes).toString("base64");
		content.push({
			type: "image_url",
			image_url: { url: `data:${mime};base64,${b64}` }
		});
	}
	let raw = "";
	try {
		raw = await grok([{
			role: "system",
			content: "Você extrai dados. Só JSON."
		}, {
			role: "user",
			content
		}], .1, 450);
	} catch {
		raw = "";
	}
	const json = asRecord(raw) ?? {};
	const amountRaw = str(json.amount, 40);
	const paidDate = /^\d{4}-\d{2}-\d{2}$/.test(str(json.paidDate, 10)) ? str(json.paidDate, 10) : "";
	const read = {
		isReceipt: json.isReceipt === true,
		description: str(json.description, 240),
		amountCents: parseBrlToCents(amountRaw),
		paidAtText: str(json.paidAt, 40),
		paidDate,
		payerName: str(json.payerName),
		favorecido: str(json.favorecido),
		banco: str(json.banco),
		e2eId: str(json.e2eId, 80),
		confidence: str(json.confidence, 12).toLowerCase() || "baixa"
	};
	const decision = decideReceipt({
		isReceipt: read.isReceipt,
		amountCents: read.amountCents,
		favorecido: read.favorecido,
		expectedFavorecido: input.expectedFavorecido,
		paidDate: read.paidDate,
		today: input.today,
		yesterday: input.yesterday,
		confidence: read.confidence,
		banco: read.banco
	});
	return {
		...read,
		decision
	};
}
function facts(desk) {
	const clock = clockIn(desk.shop.timezone);
	const state = openState(clock, desk.hours, desk.exceptions);
	const lines = [];
	lines.push(`Agora: ${clock.label} (${desk.shop.timezone}).`);
	lines.push(state.reason);
	const shopName = desk.shop.name || "comércio sem nome cadastrado";
	lines.push(`Loja: ${shopName}.`);
	if (desk.shop.attendantName) lines.push(`Quem fala se chama ${desk.shop.attendantName}.`);
	if (desk.shop.about) lines.push(`O que fazem: ${desk.shop.about}`);
	if (desk.shop.voice) lines.push(`Jeito pedido pelo dono: ${desk.shop.voice}`);
	if (desk.products.length === 0) lines.push("Nenhum produto cadastrado. Não invente preço.");
	else {
		lines.push("Produtos:");
		for (const product of desk.products) {
			const flag = product.available ? "disponível" : "em falta";
			lines.push(`- ${product.name}: ${brl(product.priceCents)} / ${product.unit} (${flag})${product.details ? ` — ${product.details}` : ""}`);
		}
	}
	const promos = desk.promos.filter((p) => promoIsLive(p));
	if (promos.length === 0) lines.push("Nenhuma promoção relâmpago valendo agora.");
	else {
		lines.push("Promoções valendo agora (só cite se o assunto for preço, promoção ou o item):");
		for (const promo of promos) lines.push(`- ${promo.title}: ${promo.details}`);
	}
	const notices = desk.notices.filter((n) => n.active);
	if (notices.length) {
		lines.push("Avisos que importam:");
		for (const notice of notices) lines.push(`- ${notice.body}`);
	}
	if (desk.shop.pixFavorecido || desk.shop.pixKey) lines.push(`Pix cadastrado: favorecido "${desk.shop.pixFavorecido || "?"}", banco "${desk.shop.pixBanco || "?"}", chave "${desk.shop.pixKey || "?"}". Só passe a chave se pedirem para pagar.`);
	return lines.join("\n");
}
function cleanReply(text) {
	let out = text.replace(/^["“]|["”]$/g, "").replace(/\*\*/g, "").trim();
	out = out.replace(/^(atendente|assistente|balcão)\s*:\s*/i, "");
	if (out.length > 700) out = out.slice(0, 700).trim();
	return out;
}
async function composeReply(input) {
	const who = input.desk.shop.attendantName ? `Você é ${input.desk.shop.attendantName} e atende no WhatsApp` : "Você atende no WhatsApp";
	const place = input.desk.shop.name ? ` da ${input.desk.shop.name}` : " deste comércio";
	let pixBlock = "Nenhum comprovante nesta mensagem.";
	if (input.pix?.isReceipt) {
		const amount = input.pix.amountCents != null ? brl(input.pix.amountCents) : "valor não lido";
		pixBlock = [
			`Parecer do comprovante: ${input.pix.decision.status.toUpperCase()}.`,
			input.pix.decision.decision,
			`Valor ${amount}. Quando: ${input.pix.paidAtText || "sem hora"}. Favorecido lido: ${input.pix.favorecido || "?"}. Banco: ${input.pix.banco || "?"}. Pagador: ${input.pix.payerName || "?"}.`,
			"Nunca diga que o dinheiro já caiu na conta. Se LIBERADO, diga que recebeu e que segue o pedido, com a conferência final rapidinha no banco. Se DÚVIDA ou RECUSADO, explique o problema numa frase e peça outro comprovante ou a correção, sem ser seco."
		].join(" ");
	} else if (input.pix?.description) pixBlock = `A pessoa mandou uma imagem ou PDF que não é comprovante: ${input.pix.description}`;
	const system = `${who}${place}. Escreva como gente de verdade no Zap, em português do Brasil.

Regras:
- 1 a 3 frases. Só passe de umas 40 palavras se pedirem preços ou a lista.
- Proibido: "Olá! Como posso ajudar?", "Claro!", "Certamente", "fico à disposição", menu numerado, "sou uma inteligência artificial", "sou um assistente virtual".
- Não comece igual às mensagens anteriores. Varie o jeito.
- Uma pergunta por vez, e só se precisar.
- Não invente produto, preço, horário, estoque ou promoção. Use só os FATOS.
- Se estiver fechado, diga isso com naturalidade e ofereça anotar para quando abrir. Não prometa entrega agora.
- Promoção relâmpago só entra se a pessoa falar de preço, de promoção, ou do item. Não cole em toda fala.
- Áudio já vem transcrito. Se parecer torto, confirme em uma frase o que entendeu.
- Emoji: no máximo um, e na maioria das vezes nenhum.
- Sem markdown e sem asterisco.
- Se perguntarem se é robô, não faça discurso. Responda curto, no tom do balcão, e volte pro pedido.

FATOS:
${facts(input.desk)}

${pixBlock}`;
	const history = input.history.slice(0, -1).map((item) => ({
		role: item.direction === "out" ? "assistant" : "user",
		content: item.body.slice(0, 800)
	}));
	const messages = [
		{
			role: "system",
			content: system
		},
		...history,
		{
			role: "user",
			content: input.customerText.slice(0, 2e3)
		}
	];
	try {
		return cleanReply(await grok(messages, .9, 220)) || "Manda de novo? Não peguei direito.";
	} catch {
		return "Deu uma travada aqui. Manda de novo daqui a pouco?";
	}
}
function todayPair(timeZone) {
	const clock = clockIn(timeZone);
	return {
		today: clock.date,
		yesterday: shiftDate(clock.date, -1)
	};
}
var PROVA_ID = "local:prova";
async function sendWhatsApp(phoneNumberId, token, to, body) {
	const res = await fetch(`https://graph.facebook.com/v21.0/${phoneNumberId}/messages`, {
		method: "POST",
		headers: {
			Authorization: `Bearer ${token}`,
			"Content-Type": "application/json"
		},
		signal: AbortSignal.timeout(2e4),
		body: JSON.stringify({
			messaging_product: "whatsapp",
			to,
			type: "text",
			text: {
				body,
				preview_url: false
			}
		})
	});
	if (res.ok) return null;
	let detail = `erro ${res.status}`;
	try {
		const json = await res.json();
		if (json.error?.message) detail = json.error.message;
	} catch {}
	return detail;
}
async function pdfText(bytes) {
	const doc = await getDocumentProxy(bytes.slice());
	const result = await extractText(doc, { mergePages: true });
	return Array.isArray(result.text) ? result.text.join("\n") : result.text;
}
function dataUrl(bytes, mime) {
	if (bytes.byteLength > 35e4) return null;
	return `data:${mime.split(";")[0]};base64,${Buffer.from(bytes).toString("base64")}`;
}
async function understand(desk, inbound) {
	const { today, yesterday } = todayPair(desk.shop.timezone);
	if (inbound.kind === "audio" && inbound.bytes) {
		if (inbound.bytes.byteLength > 8e6) return {
			body: "[áudio grande demais]",
			pix: null,
			storeImage: null
		};
		try {
			const hints = [
				desk.shop.name,
				desk.shop.pixFavorecido,
				"Pix",
				...desk.products.slice(0, 5).map((p) => p.name)
			];
			return {
				body: await transcribe(inbound.bytes, inbound.mime || "audio/wav", hints) || "[áudio sem fala entendida]",
				pix: null,
				storeImage: null
			};
		} catch {
			return {
				body: "[áudio que não deu para ouvir]",
				pix: null,
				storeImage: null
			};
		}
	}
	if ((inbound.kind === "image" || inbound.kind === "pdf") && (inbound.bytes || inbound.text)) {
		if (inbound.bytes && inbound.bytes.byteLength > 4e6) return {
			body: `${inbound.text}\n[arquivo grande demais para ler]`.trim(),
			pix: null,
			storeImage: null
		};
		let extracted = "";
		if (inbound.kind === "pdf" && inbound.bytes) try {
			extracted = (await pdfText(inbound.bytes)).slice(0, 8e3);
		} catch {
			extracted = "";
		}
		const pix = await readVisual({
			bytes: inbound.kind === "image" ? inbound.bytes : void 0,
			mime: inbound.mime,
			pdfText: extracted || void 0,
			expectedFavorecido: desk.shop.pixFavorecido,
			today,
			yesterday
		});
		const caption = inbound.text ? `${inbound.text}\n` : "";
		if (!extracted && inbound.kind === "pdf" && !pix.isReceipt) return {
			body: `${caption}[PDF sem texto. Peça uma foto do comprovante.]`.trim(),
			pix,
			storeImage: null
		};
		if (pix.isReceipt) return {
			body: `${caption}Comprovante: ${pix.amountCents != null ? `R$ ${(pix.amountCents / 100).toFixed(2).replace(".", ",")}` : "valor ?"}. ${pix.favorecido || "favorecido ?"}. ${pix.banco || "banco ?"}. ${pix.paidAtText || pix.paidDate || "sem data"}.`,
			pix,
			storeImage: inbound.kind === "image" && inbound.bytes && inbound.mime ? dataUrl(inbound.bytes, inbound.mime) : null
		};
		return {
			body: `${caption}${pix.description || extracted.slice(0, 500) || "[arquivo sem leitura]"}`.trim(),
			pix: pix.description || extracted ? pix : null,
			storeImage: null
		};
	}
	return {
		body: inbound.text || "[mensagem vazia]",
		pix: null,
		storeImage: null
	};
}
async function handleIncoming(inbound) {
	if (inbound.waMessageId) {
		if (!await seenOnce(inbound.userId, inbound.waMessageId)) return {
			reply: null,
			contactId: (await upsertContact(inbound.userId, inbound.waId, inbound.profileName)).id
		};
	}
	const desk = await loadBundle(inbound.userId);
	const contact = await upsertContact(inbound.userId, inbound.waId, inbound.profileName);
	let understood;
	try {
		understood = await understand(desk, inbound);
	} catch {
		understood = {
			body: inbound.text || "[não consegui ler esta mensagem]",
			pix: null,
			storeImage: null
		};
	}
	await insertMessage(inbound.userId, contact.id, "in", inbound.kind, understood.body);
	if (understood.pix?.isReceipt) await insertReceipt({
		userId: inbound.userId,
		contactId: contact.id,
		contactName: contact.name || inbound.profileName,
		waId: inbound.waId,
		payerName: understood.pix.payerName,
		favorecido: understood.pix.favorecido,
		banco: understood.pix.banco,
		amountCents: understood.pix.amountCents,
		paidAtText: understood.pix.paidAtText,
		paidDate: understood.pix.paidDate,
		e2eId: understood.pix.e2eId,
		confidence: understood.pix.confidence,
		nameMatches: understood.pix.decision.nameMatches,
		decision: understood.pix.decision.decision,
		status: understood.pix.decision.status,
		note: understood.pix.description,
		mediaDataUrl: understood.storeImage
	});
	if (await countRecentInbound(contact.id) > 20) {
		await pauseContact(contact.id, inbound.userId);
		await insertMessage(inbound.userId, contact.id, "out", "nota", "Pausa automática: muitas mensagens seguidas. O atendente parou nesta conversa.");
		return {
			reply: null,
			contactId: contact.id
		};
	}
	if (!desk.shop.botEnabled || contact.botPaused) return {
		reply: null,
		contactId: contact.id
	};
	const reply = await composeReply({
		desk,
		history: await recentHistory(contact.id),
		customerText: understood.body,
		pix: understood.pix && (understood.pix.isReceipt || understood.pix.description) ? understood.pix : null
	});
	await insertMessage(inbound.userId, contact.id, "out", "text", reply);
	if (inbound.deliver && desk.secrets.phoneNumberId && desk.secrets.accessToken && !inbound.waId.startsWith("local:")) {
		const error = await sendWhatsApp(desk.secrets.phoneNumberId, desk.secrets.accessToken, inbound.waId, reply);
		if (error) await insertMessage(inbound.userId, contact.id, "out", "nota", `Não saiu no WhatsApp: ${error}`);
	}
	return {
		reply,
		contactId: contact.id
	};
}
async function sendHuman(userId, contactId, text) {
	const body = text.trim();
	if (!body) throw new Error("Escreva a mensagem.");
	const waId = (await (await getSql())`select wa_id from contacts where id = ${contactId} and user_id = ${userId}`)[0]?.wa_id;
	if (!waId) throw new Error("Conversa não encontrada.");
	const desk = await loadBundle(userId);
	await insertMessage(userId, contactId, "out", "text", body);
	if (!waId.startsWith("local:")) {
		const { sendTextToContact } = await import("./wa-link.server-_dZ8_V2n.mjs");
		const via = await sendTextToContact(userId, waId, body);
		if (via === "sent") return;
		if (via === "failed") throw new Error("Não saiu no WhatsApp ligado.");
		if (desk.secrets.phoneNumberId && desk.secrets.accessToken) {
			const error = await sendWhatsApp(desk.secrets.phoneNumberId, desk.secrets.accessToken, waId, body);
			if (error) throw new Error(error);
		}
	}
}
async function sendTest(userId, to, text) {
	const digits = to.replace(/\D/g, "");
	if (digits.length < 10 || digits.length > 15) throw new Error("Número com DDI, só dígitos. Exemplo: 5591999999999.");
	const body = text.trim();
	if (!body) throw new Error("Escreva o teste.");
	const { sendTextToContact } = await import("./wa-link.server-_dZ8_V2n.mjs");
	const via = await sendTextToContact(userId, digits, body);
	if (via === "sent") return;
	if (via === "failed") throw new Error("O WhatsApp ligado não enviou. Tente de novo.");
	const desk = await loadBundle(userId);
	if (!desk.secrets.phoneNumberId || !desk.secrets.accessToken) throw new Error("Ligue o WhatsApp pelo QR antes de testar.");
	const error = await sendWhatsApp(desk.secrets.phoneNumberId, desk.secrets.accessToken, digits, body);
	if (error) throw new Error(error);
}
function provaWaId() {
	return PROVA_ID;
}
function verifyMetaSignature(raw, header, secret) {
	if (!secret) return true;
	if (!header?.startsWith("sha256=")) return false;
	const expected = createHmac("sha256", secret).update(raw).digest("hex");
	const got = header.slice(7);
	if (got.length !== expected.length) return false;
	return timingSafeEqual(Buffer.from(got), Buffer.from(expected));
}
async function downloadMedia(mediaId, token) {
	const metaRes = await fetch(`https://graph.facebook.com/v21.0/${mediaId}`, {
		headers: { Authorization: `Bearer ${token}` },
		signal: AbortSignal.timeout(15e3)
	});
	if (!metaRes.ok) throw new Error("mídia");
	const meta = await metaRes.json();
	if (!meta.url) throw new Error("mídia sem url");
	const fileRes = await fetch(meta.url, {
		headers: { Authorization: `Bearer ${token}` },
		signal: AbortSignal.timeout(2e4)
	});
	if (!fileRes.ok) throw new Error("download");
	return {
		bytes: new Uint8Array(await fileRes.arrayBuffer()),
		mime: meta.mime_type || fileRes.headers.get("content-type") || "application/octet-stream"
	};
}
async function handleWebhookPayload(userId, value) {
	const messages = value.messages ?? [];
	if (messages.length === 0) return;
	const desk = await loadBundle(userId);
	const metaPhone = value.metadata?.phone_number_id ?? "";
	if (desk.secrets.phoneNumberId && metaPhone && desk.secrets.phoneNumberId !== metaPhone) return;
	for (const message of messages) {
		const from = message.from ?? "";
		if (!from || !message.id) continue;
		const profile = value.contacts?.find((c) => c.wa_id === from)?.profile?.name ?? "";
		const type = message.type ?? "outro";
		const inbound = {
			userId,
			waId: from,
			profileName: profile,
			waMessageId: message.id,
			kind: "outro",
			text: "",
			deliver: true
		};
		try {
			if (type === "text") {
				inbound.kind = "text";
				inbound.text = message.text?.body ?? "";
			} else if (type === "button" || type === "interactive") {
				inbound.kind = "text";
				inbound.text = message.button?.text || message.interactive?.button_reply?.title || message.interactive?.list_reply?.title || "";
			} else if (type === "audio" && message.audio?.id && desk.secrets.accessToken) {
				inbound.kind = "audio";
				const media = await downloadMedia(message.audio.id, desk.secrets.accessToken);
				inbound.bytes = media.bytes;
				inbound.mime = media.mime;
			} else if (type === "image" && message.image?.id && desk.secrets.accessToken) {
				inbound.kind = "image";
				inbound.text = message.image.caption ?? "";
				const media = await downloadMedia(message.image.id, desk.secrets.accessToken);
				inbound.bytes = media.bytes;
				inbound.mime = media.mime || message.image.mime_type || "image/jpeg";
			} else if (type === "document" && message.document?.id && desk.secrets.accessToken) {
				const mime = message.document.mime_type || "";
				inbound.text = message.document.caption || message.document.filename || "";
				const media = await downloadMedia(message.document.id, desk.secrets.accessToken);
				inbound.bytes = media.bytes;
				inbound.mime = media.mime || mime;
				if ((inbound.mime || mime).includes("pdf")) inbound.kind = "pdf";
				else if ((inbound.mime || mime).startsWith("image/")) inbound.kind = "image";
				else inbound.kind = "outro";
			} else if (type === "video") {
				inbound.kind = "outro";
				inbound.text = message.video?.caption || "[a pessoa mandou um vídeo]";
			} else if (type === "sticker") {
				inbound.kind = "outro";
				inbound.text = "[a pessoa mandou uma figurinha]";
			} else if (type === "location") {
				inbound.kind = "outro";
				inbound.text = `[a pessoa mandou uma localização${message.location?.name ? `: ${message.location.name}` : ""}]`;
			} else {
				inbound.kind = "outro";
				inbound.text = "[mensagem de um tipo que o balcão não abre]";
			}
			await handleIncoming(inbound);
		} catch (error) {
			console.error("webhook message", error instanceof Error ? error.message : "fail");
		}
	}
}
async function ingestWebhook(userId, payload) {
	const entries = payload.entry ?? [];
	for (const entry of entries) for (const change of entry.changes ?? []) if (change.value) await handleWebhookPayload(userId, change.value);
}
//#endregion
export { handleIncoming, ingestWebhook, provaWaId, sendHuman, sendTest, verifyMetaSignature };
