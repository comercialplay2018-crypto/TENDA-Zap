import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DfSO64Q1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fns-BrpCejyC.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function fail(error) {
	return {
		ok: false,
		error: error instanceof Error ? error.message : "Não deu."
	};
}
var getDesk_createServerFn_handler = createServerRpc({
	id: "c100cb27a8eb6d1815ac7e0afe44773e77d530c78978cc1a500d7c9454bc126b",
	name: "getDesk",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => getDesk.__executeServer(opts));
var getDesk = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getDesk_createServerFn_handler, async ({ context }) => {
	const { loadDesk } = await import("./repo.server-Bz69yhlu.mjs");
	const desk = await loadDesk(context.userId);
	import("./wa-link.server-_dZ8_V2n.mjs").then((mod) => mod.resumeIfPaired(context.userId)).catch(() => void 0);
	return desk;
});
var saveShopFn_createServerFn_handler = createServerRpc({
	id: "03c9e35ca84f657d9bce86a0b1a3c5ced65edc6afd9a6bdb7c27548d567c8eb0",
	name: "saveShopFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => saveShopFn.__executeServer(opts));
var saveShopFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveShopFn_createServerFn_handler, async ({ context, data }) => {
	try {
		const { saveShop } = await import("./repo.server-Bz69yhlu.mjs");
		await saveShop(context.userId, data);
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
});
var saveHoursFn_createServerFn_handler = createServerRpc({
	id: "4a9cbf585f495b9a09cb186debdef1c7fff052027531c7280ac554e50a7e4031",
	name: "saveHoursFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => saveHoursFn.__executeServer(opts));
var saveHoursFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveHoursFn_createServerFn_handler, async ({ context, data }) => {
	try {
		const { saveHours } = await import("./repo.server-Bz69yhlu.mjs");
		await saveHours(context.userId, data);
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
});
var addExceptionFn_createServerFn_handler = createServerRpc({
	id: "65dcea6d12994228cade5fb43a93dbec908ff1cf9da0481b217efeb244fa7b18",
	name: "addExceptionFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => addExceptionFn.__executeServer(opts));
var addExceptionFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(addExceptionFn_createServerFn_handler, async ({ context, data }) => {
	try {
		const { addException } = await import("./repo.server-Bz69yhlu.mjs");
		await addException(context.userId, data);
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
});
var deleteExceptionFn_createServerFn_handler = createServerRpc({
	id: "e94ec28e863ba7e11ea48234e3d4bc9c3898dbd9edae8f4b31a2c3c08f5a00d8",
	name: "deleteExceptionFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => deleteExceptionFn.__executeServer(opts));
var deleteExceptionFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(deleteExceptionFn_createServerFn_handler, async ({ context, data }) => {
	const { deleteException } = await import("./repo.server-Bz69yhlu.mjs");
	await deleteException(context.userId, data);
	return { ok: true };
});
var saveProductFn_createServerFn_handler = createServerRpc({
	id: "fdca48bda453fad5097fa80a13707596b8957c4a5cee99e8bba208131c05c77b",
	name: "saveProductFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => saveProductFn.__executeServer(opts));
var saveProductFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveProductFn_createServerFn_handler, async ({ context, data }) => {
	try {
		const { saveProduct } = await import("./repo.server-Bz69yhlu.mjs");
		await saveProduct(context.userId, data);
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
});
var deleteProductFn_createServerFn_handler = createServerRpc({
	id: "8e5ba1ac0036eec913be77fc054f62f7ac6bf27b39240cd9cdca64e9b27ae9ab",
	name: "deleteProductFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => deleteProductFn.__executeServer(opts));
var deleteProductFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(deleteProductFn_createServerFn_handler, async ({ context, data }) => {
	const { deleteProduct } = await import("./repo.server-Bz69yhlu.mjs");
	await deleteProduct(context.userId, data);
	return { ok: true };
});
var addPromoFn_createServerFn_handler = createServerRpc({
	id: "daa95f4d9d627bf03d56b177a2a7bf115bfc66d1865b4dee72781b65fa260576",
	name: "addPromoFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => addPromoFn.__executeServer(opts));
var addPromoFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(addPromoFn_createServerFn_handler, async ({ context, data }) => {
	try {
		const { addPromo } = await import("./repo.server-Bz69yhlu.mjs");
		await addPromo(context.userId, data);
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
});
var setPromoFn_createServerFn_handler = createServerRpc({
	id: "4235933d7163e0543fea07fff0a5f795bdf36810afcae5dad05294a15bc52e57",
	name: "setPromoFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => setPromoFn.__executeServer(opts));
var setPromoFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(setPromoFn_createServerFn_handler, async ({ context, data }) => {
	const { setPromoActive } = await import("./repo.server-Bz69yhlu.mjs");
	await setPromoActive(context.userId, data.id, data.active);
	return { ok: true };
});
var deletePromoFn_createServerFn_handler = createServerRpc({
	id: "26ede987a57dba3c99616aa19b630264fe783a067aed5383712b0aa41fb51708",
	name: "deletePromoFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => deletePromoFn.__executeServer(opts));
var deletePromoFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(deletePromoFn_createServerFn_handler, async ({ context, data }) => {
	const { deletePromo } = await import("./repo.server-Bz69yhlu.mjs");
	await deletePromo(context.userId, data);
	return { ok: true };
});
var addNoticeFn_createServerFn_handler = createServerRpc({
	id: "e1bc417ee11bc0afe5d1b9b8c1f6e76e2ac269fb22160d59ccd2be3dec2d3931",
	name: "addNoticeFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => addNoticeFn.__executeServer(opts));
var addNoticeFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((body) => body).handler(addNoticeFn_createServerFn_handler, async ({ context, data }) => {
	try {
		const { addNotice } = await import("./repo.server-Bz69yhlu.mjs");
		await addNotice(context.userId, data);
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
});
var setNoticeFn_createServerFn_handler = createServerRpc({
	id: "0ae7a9aa283b88394ab8978296ca01543c221fe1c48a69956cfdab2bc6feca17",
	name: "setNoticeFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => setNoticeFn.__executeServer(opts));
var setNoticeFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(setNoticeFn_createServerFn_handler, async ({ context, data }) => {
	const { setNoticeActive } = await import("./repo.server-Bz69yhlu.mjs");
	await setNoticeActive(context.userId, data.id, data.active);
	return { ok: true };
});
var deleteNoticeFn_createServerFn_handler = createServerRpc({
	id: "7f1ec421bd1cec9452635dfdd30e6251b6cb66754e77c3cb2ca4eb2600951bcb",
	name: "deleteNoticeFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => deleteNoticeFn.__executeServer(opts));
var deleteNoticeFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(deleteNoticeFn_createServerFn_handler, async ({ context, data }) => {
	const { deleteNotice } = await import("./repo.server-Bz69yhlu.mjs");
	await deleteNotice(context.userId, data);
	return { ok: true };
});
var saveConnectionFn_createServerFn_handler = createServerRpc({
	id: "14078abf4f394a6328989485f2eb2bed107c8204a2b3cd99823cf1c864c5aca7",
	name: "saveConnectionFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => saveConnectionFn.__executeServer(opts));
var saveConnectionFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveConnectionFn_createServerFn_handler, async ({ context, data }) => {
	try {
		const { saveConnection } = await import("./repo.server-Bz69yhlu.mjs");
		await saveConnection(context.userId, data);
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
});
var setBotFn_createServerFn_handler = createServerRpc({
	id: "33856ae5ec7f0893c01202822c418f7913a692391c9fff02f14b11fe15e30542",
	name: "setBotFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => setBotFn.__executeServer(opts));
var setBotFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((enabled) => enabled).handler(setBotFn_createServerFn_handler, async ({ context, data }) => {
	const { setBotEnabled } = await import("./repo.server-Bz69yhlu.mjs");
	await setBotEnabled(context.userId, data);
	return { ok: true };
});
var getThreads_createServerFn_handler = createServerRpc({
	id: "ac8c4800bfac3d416baf01328d7c0fc9bf0109313b08a2b74ef5a041c6e24983",
	name: "getThreads",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => getThreads.__executeServer(opts));
var getThreads = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getThreads_createServerFn_handler, async ({ context }) => {
	const { listThreads, mapThread } = await import("./repo.server-Bz69yhlu.mjs");
	return (await listThreads(context.userId)).map(mapThread);
});
var getMessages_createServerFn_handler = createServerRpc({
	id: "2d45c76e53c0248a1fa735a1050eb864aced8a2c8fb5680ae33a958f1ebc97d8",
	name: "getMessages",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => getMessages.__executeServer(opts));
var getMessages = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((contactId) => contactId).handler(getMessages_createServerFn_handler, async ({ context, data }) => {
	const { listMessages, mapMessage } = await import("./repo.server-Bz69yhlu.mjs");
	return (await listMessages(context.userId, data)).map(mapMessage).reverse();
});
var setPausedFn_createServerFn_handler = createServerRpc({
	id: "458109eb40dce13ab9062c81cc735e2c56de3b147df6f8e7c71b7e12cfb49c43",
	name: "setPausedFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => setPausedFn.__executeServer(opts));
var setPausedFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(setPausedFn_createServerFn_handler, async ({ context, data }) => {
	const { setPaused } = await import("./repo.server-Bz69yhlu.mjs");
	await setPaused(context.userId, data.contactId, data.paused);
	return { ok: true };
});
var humanSendFn_createServerFn_handler = createServerRpc({
	id: "49b297728949e9e84419adc8158ad34fd855b26331a26d80fa7b992fd4625a42",
	name: "humanSendFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => humanSendFn.__executeServer(opts));
var humanSendFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(humanSendFn_createServerFn_handler, async ({ context, data }) => {
	try {
		const { sendHuman } = await import("./flow.server-BifjJqaR.mjs");
		await sendHuman(context.userId, data.contactId, data.text);
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
});
var getReceipts_createServerFn_handler = createServerRpc({
	id: "ad4ac18a2a778e89d6de899ae83167e53f6d04d88dc293d8b2164468d866fefc",
	name: "getReceipts",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => getReceipts.__executeServer(opts));
var getReceipts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getReceipts_createServerFn_handler, async ({ context }) => {
	const { listReceipts } = await import("./repo.server-Bz69yhlu.mjs");
	return (await listReceipts(context.userId)).map((row) => ({
		id: row.id,
		contactId: row.contact_id,
		contactName: row.contact_name,
		waId: row.wa_id,
		payerName: row.payer_name,
		favorecido: row.favorecido,
		banco: row.banco,
		amountCents: row.amount_cents,
		paidAtText: row.paid_at_text,
		paidDate: row.paid_date,
		e2eId: row.e2e_id,
		confidence: row.confidence,
		nameMatches: row.name_matches,
		decision: row.decision,
		status: row.status,
		note: row.note,
		mediaDataUrl: row.media_data_url,
		createdAt: row.created_at instanceof Date ? row.created_at.toISOString() : String(row.created_at ?? "")
	}));
});
var setReceiptFn_createServerFn_handler = createServerRpc({
	id: "0a2eb8e21c2f98087f89e986a8dfaad2e2aff4d11d76c7e9add683fe33ec1966",
	name: "setReceiptFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => setReceiptFn.__executeServer(opts));
var setReceiptFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(setReceiptFn_createServerFn_handler, async ({ context, data }) => {
	try {
		const { setReceiptStatus } = await import("./repo.server-Bz69yhlu.mjs");
		await setReceiptStatus(context.userId, data.id, data.status);
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
});
var provaSendFn_createServerFn_handler = createServerRpc({
	id: "8a75b92dea75cff780e4c1f81c5267a236fc0a2895a275a2a5b3c02ec4fa6d2f",
	name: "provaSendFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => provaSendFn.__executeServer(opts));
var provaSendFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(provaSendFn_createServerFn_handler, async ({ context, data }) => {
	try {
		const attachment = data.attachment;
		if (attachment && attachment.base64.length > 6e6) return {
			ok: false,
			error: "Arquivo grande demais."
		};
		const { handleIncoming, provaWaId } = await import("./flow.server-BifjJqaR.mjs");
		const { listMessages, mapMessage } = await import("./repo.server-Bz69yhlu.mjs");
		const bytes = attachment ? Buffer.from(attachment.base64, "base64") : void 0;
		const result = await handleIncoming({
			userId: context.userId,
			waId: provaWaId(),
			profileName: "Prova",
			waMessageId: null,
			kind: attachment?.kind ?? "text",
			text: data.text ?? "",
			bytes,
			mime: attachment?.mime,
			filename: attachment?.filename,
			deliver: false
		});
		return {
			ok: true,
			messages: (await listMessages(context.userId, result.contactId)).map(mapMessage).reverse(),
			reply: result.reply
		};
	} catch (error) {
		return {
			ok: false,
			error: error instanceof Error ? error.message : "Não deu.",
			messages: []
		};
	}
});
var getProvaFn_createServerFn_handler = createServerRpc({
	id: "de9b0edbf5f02bb5e15195ad7b21fdfbf642304c82087223fc9f0124ec1b6214",
	name: "getProvaFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => getProvaFn.__executeServer(opts));
var getProvaFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getProvaFn_createServerFn_handler, async ({ context }) => {
	const { provaWaId } = await import("./flow.server-BifjJqaR.mjs");
	const { listMessages, mapMessage, upsertContact } = await import("./repo.server-Bz69yhlu.mjs");
	const contact = await upsertContact(context.userId, provaWaId(), "Prova");
	return (await listMessages(context.userId, contact.id)).map(mapMessage).reverse();
});
var getWaLinkFn_createServerFn_handler = createServerRpc({
	id: "973da2453305b429a5f3fbd6309b7b61a849dd13e90bcbb06291e85146b2e2c5",
	name: "getWaLinkFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => getWaLinkFn.__executeServer(opts));
var getWaLinkFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getWaLinkFn_createServerFn_handler, async ({ context }) => {
	const { resumeIfPaired } = await import("./wa-link.server-_dZ8_V2n.mjs");
	return resumeIfPaired(context.userId);
});
var startWaLinkFn_createServerFn_handler = createServerRpc({
	id: "e4d5b76ff96012975a47020267f6f80365d099df333c5eb421f19b2bc13df762",
	name: "startWaLinkFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => startWaLinkFn.__executeServer(opts));
var startWaLinkFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(startWaLinkFn_createServerFn_handler, async ({ context }) => {
	const { ensureLink } = await import("./wa-link.server-_dZ8_V2n.mjs");
	return ensureLink(context.userId);
});
var stopWaLinkFn_createServerFn_handler = createServerRpc({
	id: "f4cff9d47386f20a7ec17d0b62a868ae9502328cc3469a9fc8893fffcbec14fc",
	name: "stopWaLinkFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => stopWaLinkFn.__executeServer(opts));
var stopWaLinkFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(stopWaLinkFn_createServerFn_handler, async ({ context }) => {
	const { stopLink } = await import("./wa-link.server-_dZ8_V2n.mjs");
	return stopLink(context.userId);
});
var testSendFn_createServerFn_handler = createServerRpc({
	id: "c730ad2ff765f70ef056eacdce193c53ece8cb745fe56d6df02a19f88cf034d3",
	name: "testSendFn",
	filename: "src/lib/balcao/fns.ts"
}, (opts) => testSendFn.__executeServer(opts));
var testSendFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(testSendFn_createServerFn_handler, async ({ context, data }) => {
	try {
		const { sendTest } = await import("./flow.server-BifjJqaR.mjs");
		await sendTest(context.userId, data.to, data.text);
		return { ok: true };
	} catch (error) {
		return fail(error);
	}
});
//#endregion
export { addExceptionFn_createServerFn_handler, addNoticeFn_createServerFn_handler, addPromoFn_createServerFn_handler, deleteExceptionFn_createServerFn_handler, deleteNoticeFn_createServerFn_handler, deleteProductFn_createServerFn_handler, deletePromoFn_createServerFn_handler, getDesk_createServerFn_handler, getMessages_createServerFn_handler, getProvaFn_createServerFn_handler, getReceipts_createServerFn_handler, getThreads_createServerFn_handler, getWaLinkFn_createServerFn_handler, humanSendFn_createServerFn_handler, provaSendFn_createServerFn_handler, saveConnectionFn_createServerFn_handler, saveHoursFn_createServerFn_handler, saveProductFn_createServerFn_handler, saveShopFn_createServerFn_handler, setBotFn_createServerFn_handler, setNoticeFn_createServerFn_handler, setPausedFn_createServerFn_handler, setPromoFn_createServerFn_handler, setReceiptFn_createServerFn_handler, startWaLinkFn_createServerFn_handler, stopWaLinkFn_createServerFn_handler, testSendFn_createServerFn_handler };
