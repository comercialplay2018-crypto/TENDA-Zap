import { o as __toESM } from "../_runtime.mjs";
import { J as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as signOut } from "./client-IWHfIGH2.mjs";
import { a as formatStamp, i as clockIn, l as promoIsLive, n as WEEKDAY_LABELS, r as brl, s as openState, t as TIMEZONES } from "./time-kqQZUT9n.mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DfSO64Q1.mjs";
import { a as hasGateSessionMarker } from "./server-u-bqf-jA.mjs";
import { n as useCurrentUser, r as useCurrentUserState, t as Welcome } from "./welcome-BDmmblnC.mjs";
import { a as MessageCircle, i as Mic, n as Store, o as Cable, r as Receipt } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BEXx9Yly.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getDesk = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("c100cb27a8eb6d1815ac7e0afe44773e77d530c78978cc1a500d7c9454bc126b"));
var saveShopFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("03c9e35ca84f657d9bce86a0b1a3c5ced65edc6afd9a6bdb7c27548d567c8eb0"));
var saveHoursFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("4a9cbf585f495b9a09cb186debdef1c7fff052027531c7280ac554e50a7e4031"));
var addExceptionFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("65dcea6d12994228cade5fb43a93dbec908ff1cf9da0481b217efeb244fa7b18"));
var deleteExceptionFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(createSsrRpc("e94ec28e863ba7e11ea48234e3d4bc9c3898dbd9edae8f4b31a2c3c08f5a00d8"));
var saveProductFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("fdca48bda453fad5097fa80a13707596b8957c4a5cee99e8bba208131c05c77b"));
var deleteProductFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(createSsrRpc("8e5ba1ac0036eec913be77fc054f62f7ac6bf27b39240cd9cdca64e9b27ae9ab"));
var addPromoFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("daa95f4d9d627bf03d56b177a2a7bf115bfc66d1865b4dee72781b65fa260576"));
var setPromoFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("4235933d7163e0543fea07fff0a5f795bdf36810afcae5dad05294a15bc52e57"));
var deletePromoFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(createSsrRpc("26ede987a57dba3c99616aa19b630264fe783a067aed5383712b0aa41fb51708"));
var addNoticeFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((body) => body).handler(createSsrRpc("e1bc417ee11bc0afe5d1b9b8c1f6e76e2ac269fb22160d59ccd2be3dec2d3931"));
var setNoticeFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("0ae7a9aa283b88394ab8978296ca01543c221fe1c48a69956cfdab2bc6feca17"));
var deleteNoticeFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((id) => id).handler(createSsrRpc("7f1ec421bd1cec9452635dfdd30e6251b6cb66754e77c3cb2ca4eb2600951bcb"));
var saveConnectionFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("14078abf4f394a6328989485f2eb2bed107c8204a2b3cd99823cf1c864c5aca7"));
var setBotFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((enabled) => enabled).handler(createSsrRpc("33856ae5ec7f0893c01202822c418f7913a692391c9fff02f14b11fe15e30542"));
var getThreads = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("ac8c4800bfac3d416baf01328d7c0fc9bf0109313b08a2b74ef5a041c6e24983"));
var getMessages = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((contactId) => contactId).handler(createSsrRpc("2d45c76e53c0248a1fa735a1050eb864aced8a2c8fb5680ae33a958f1ebc97d8"));
var setPausedFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("458109eb40dce13ab9062c81cc735e2c56de3b147df6f8e7c71b7e12cfb49c43"));
var humanSendFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("49b297728949e9e84419adc8158ad34fd855b26331a26d80fa7b992fd4625a42"));
var getReceipts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("ad4ac18a2a778e89d6de899ae83167e53f6d04d88dc293d8b2164468d866fefc"));
var setReceiptFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("0a2eb8e21c2f98087f89e986a8dfaad2e2aff4d11d76c7e9add683fe33ec1966"));
var provaSendFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("8a75b92dea75cff780e4c1f81c5267a236fc0a2895a275a2a5b3c02ec4fa6d2f"));
var getProvaFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("de9b0edbf5f02bb5e15195ad7b21fdfbf642304c82087223fc9f0124ec1b6214"));
var getWaLinkFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("973da2453305b429a5f3fbd6309b7b61a849dd13e90bcbb06291e85146b2e2c5"));
var startWaLinkFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("e4d5b76ff96012975a47020267f6f80365d099df333c5eb421f19b2bc13df762"));
var stopWaLinkFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("f4cff9d47386f20a7ec17d0b62a868ae9502328cc3469a9fc8893fffcbec14fc"));
var testSendFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("c730ad2ff765f70ef056eacdce193c53ece8cb745fe56d6df02a19f88cf034d3"));
var KIND = {
	audio: "Áudio",
	image: "Foto",
	pdf: "PDF",
	nota: "Nota"
};
function Bubbles({ messages, timeZone }) {
	if (messages.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm leading-6 text-muted",
		children: "Nada por aqui ainda."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-2",
		children: messages.map((message) => {
			const note = message.kind === "nota";
			const mine = message.direction === "out" && !note;
			const label = KIND[message.kind];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: mine ? "ml-8" : note ? "" : "mr-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: note ? "text-xs leading-5 text-warn" : mine ? "rounded-2xl rounded-tr-md bg-moss px-3 py-2 text-sm leading-6 text-ink" : "rounded-2xl rounded-tl-md border border-line bg-surface px-3 py-2 text-sm leading-6 text-ink",
					children: [label && !note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-xs font-medium text-muted",
						children: label
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-wrap",
						children: message.body
					})]
				}), !note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: formatStamp(message.createdAt, timeZone)
				}) : null]
			}, message.id);
		})
	});
}
var inputClass = "w-full rounded-xl border border-line bg-surface px-3 py-3 text-base text-ink outline-none focus:border-pine";
var btnPrimary = "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-pine px-4 text-sm font-medium text-pine-ink disabled:opacity-50";
var btnGhost = "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-4 text-sm font-medium text-ink disabled:opacity-50";
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-sm text-muted",
			children: label
		}), children]
	});
}
function Card({ children, title, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-line bg-surface p-4",
		children: [
			title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl text-ink",
				children: title
			}) : null,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-6 text-muted",
				children: hint
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: title ? "mt-4 flex flex-col gap-3" : "flex flex-col gap-3",
				children
			})
		]
	});
}
function Note({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm leading-6 text-warn",
		children
	});
}
function Inbox({ timeZone, openId, onOpen }) {
	const [threads, setThreads] = (0, import_react.useState)([]);
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [text, setText] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)("");
	async function refreshThreads() {
		setThreads(await getThreads());
	}
	(0, import_react.useEffect)(() => {
		let stop = false;
		const tick = () => {
			getThreads().then((rows) => {
				if (!stop) setThreads(rows);
			});
		};
		tick();
		const id = window.setInterval(tick, 8e3);
		return () => {
			stop = true;
			window.clearInterval(id);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (openId == null) return;
		let stop = false;
		const tick = () => {
			getMessages({ data: openId }).then((rows) => {
				if (!stop) setMessages(rows);
			});
		};
		tick();
		const id = window.setInterval(tick, 5e3);
		return () => {
			stop = true;
			window.clearInterval(id);
		};
	}, [openId]);
	const current = threads.find((thread) => thread.id === openId);
	if (openId != null && current) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: btnGhost,
					onClick: () => onOpen(null),
					children: "Voltar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: btnGhost,
					onClick: () => void setPausedFn({ data: {
						contactId: current.id,
						paused: !current.botPaused
					} }).then(refreshThreads),
					children: current.botPaused ? "Devolver ao atendente" : "Eu assumo"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: current.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: current.waId
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bubbles, {
				messages,
				timeZone
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: inputClass,
				rows: 2,
				value: text,
				placeholder: "Responder você mesmo",
				onChange: (e) => setText(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: btnPrimary,
				onClick: () => void humanSendFn({ data: {
					contactId: current.id,
					text
				} }).then(async (res) => {
					if (!res.ok) setErr(res.error);
					else {
						setText("");
						setErr("");
						setMessages(await getMessages({ data: current.id }));
					}
				}),
				children: "Enviar no WhatsApp"
			}),
			err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-warn",
				children: err
			}) : null
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [threads.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-6 text-muted",
			children: "Quando alguém falar no número ligado, a conversa aparece aqui. Pra treinar o jeito de falar agora, abra Prova."
		}) : null, threads.map((thread) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onOpen(thread.id),
			className: "rounded-2xl border border-line bg-surface px-4 py-3 text-left",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: thread.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: formatStamp(thread.updatedAt, timeZone)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block truncate text-sm text-muted",
					children: thread.preview || "Sem texto"
				}),
				thread.botPaused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block text-xs text-clay",
					children: "Você assumiu"
				}) : null
			]
		}, thread.id))]
	});
}
function Ligar({ desk, onChange }) {
	const [phoneNumberId, setPhoneNumberId] = (0, import_react.useState)(desk.connection.phoneNumberId);
	const [displayPhone, setDisplayPhone] = (0, import_react.useState)(desk.connection.displayPhone);
	const [accessToken, setAccessToken] = (0, import_react.useState)("");
	const [appSecret, setAppSecret] = (0, import_react.useState)("");
	const [pixKey, setPixKey] = (0, import_react.useState)(desk.shop.pixKey);
	const [pixFavorecido, setPixFavorecido] = (0, import_react.useState)(desk.shop.pixFavorecido);
	const [pixBanco, setPixBanco] = (0, import_react.useState)(desk.shop.pixBanco);
	const [to, setTo] = (0, import_react.useState)("");
	const [text, setText] = (0, import_react.useState)("oi, teste do balcão");
	const [msg, setMsg] = (0, import_react.useState)("");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [link, setLink] = (0, import_react.useState)(null);
	const [linking, setLinking] = (0, import_react.useState)(false);
	const path = `/api/whatsapp/webhook/${desk.connection.verifyToken}`;
	const full = typeof window !== "undefined" ? `${window.location.origin}${path}` : path;
	(0, import_react.useEffect)(() => {
		let stop = false;
		async function tick() {
			try {
				const next = await getWaLinkFn();
				if (!stop) setLink(next);
			} catch (error) {
				if (!stop) setMsg(error instanceof Error ? error.message : "Não li o WhatsApp.");
			}
		}
		tick();
		const id = window.setInterval(() => void tick(), 2e3);
		return () => {
			stop = true;
			window.clearInterval(id);
		};
	}, []);
	async function saveLink() {
		const res = await saveConnectionFn({ data: {
			phoneNumberId,
			displayPhone,
			accessToken,
			appSecret,
			clearSecret: false
		} });
		if (!res.ok) setMsg(res.error);
		else {
			setAccessToken("");
			setAppSecret("");
			setMsg("Ligação salva.");
			await onChange();
		}
	}
	async function savePix() {
		const res = await saveShopFn({ data: {
			...desk.shop,
			pixKey,
			pixFavorecido,
			pixBanco
		} });
		if (!res.ok) setMsg(res.error);
		else {
			setMsg("Pix salvo.");
			await onChange();
		}
	}
	async function showQr() {
		setLinking(true);
		try {
			setLink(await startWaLinkFn());
		} catch (error) {
			setMsg(error instanceof Error ? error.message : "Não gerou o QR.");
		} finally {
			setLinking(false);
		}
	}
	async function disconnect() {
		setLinking(true);
		try {
			setLink(await stopWaLinkFn());
		} catch (error) {
			setMsg(error instanceof Error ? error.message : "Não desligou.");
		} finally {
			setLinking(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: "WhatsApp neste celular",
				hint: "O Balcão entra como aparelho conectado. Você continua usando o WhatsApp no telefone, e o atendente responde sozinho com a mesma conversa da aba Prova.",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-6 text-ink",
						children: link?.note || "Ainda não ligado."
					}),
					link?.qrDataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: link.qrDataUrl,
						alt: "QR Code para conectar o WhatsApp",
						className: "mx-auto w-56 rounded-xl bg-white p-3"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: link?.status === "open" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: btnGhost,
							disabled: linking,
							onClick: () => void disconnect(),
							children: "Desligar"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: btnPrimary,
							disabled: linking || link?.status === "connecting" || link?.status === "qr",
							onClick: () => void showQr(),
							children: link?.status === "qr" ? "Aguardando a leitura" : linking || link?.status === "connecting" ? "Conectando…" : "Mostrar QR"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-6 text-muted",
						children: "A sessão fica neste servidor. Se ele reiniciar, religa sozinho depois do primeiro pareamento. Áudio, foto e PDF seguem o mesmo caminho de sempre."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: "Teste de envio",
				hint: "Com o QR ligado, manda uma frase para um número com DDI.",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Para",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							inputMode: "numeric",
							value: to,
							placeholder: "5591999999999",
							onChange: (e) => setTo(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Texto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: text,
							onChange: (e) => setText(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: btnPrimary,
						onClick: () => void testSendFn({ data: {
							to,
							text
						} }).then((res) => {
							setMsg(res.ok ? "Enviado. Olha o WhatsApp." : res.error);
						}),
						children: "Enviar teste"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				title: "Pix que você recebe",
				hint: "O nome tem que ser o do comprovante, do favorecido. É com ele que o atendente libera ou segura.",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nome do favorecido",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: pixFavorecido,
							onChange: (e) => setPixFavorecido(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Banco",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: pixBanco,
							onChange: (e) => setPixBanco(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Chave",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: inputClass,
							value: pixKey,
							onChange: (e) => setPixKey(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: btnPrimary,
						onClick: () => void savePix(),
						children: "Salvar Pix"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer text-sm font-medium text-ink",
					children: "API oficial da Meta, se um dia quiser"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Identificador do número",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								value: phoneNumberId,
								onChange: (e) => setPhoneNumberId(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Número visível",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								value: displayPhone,
								placeholder: "5591…",
								onChange: (e) => setDisplayPhone(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: desk.connection.tokenSet ? `Token (salvo, final ${desk.connection.tokenTail})` : "Token",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								type: "password",
								value: accessToken,
								placeholder: desk.connection.tokenSet ? "Em branco mantém o atual" : "Cole o token",
								onChange: (e) => setAccessToken(e.target.value),
								autoComplete: "off"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: desk.connection.secretSet ? "Segredo do app (opcional, já salvo)" : "Segredo do app (opcional)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								type: "password",
								value: appSecret,
								placeholder: "Só se for conferir a assinatura",
								onChange: (e) => setAppSecret(e.target.value),
								autoComplete: "off"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btnPrimary,
								onClick: () => void saveLink(),
								children: "Salvar ligação"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Endereço do webhook",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								readOnly: true,
								value: full
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Token de verificação",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: inputClass,
								readOnly: true,
								value: desk.connection.verifyToken
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: btnGhost,
							onClick: () => {
								navigator.clipboard.writeText(`${full}\n${desk.connection.verifyToken}`).then(() => {
									setCopied(true);
								});
							},
							children: copied ? "Copiado" : "Copiar endereço e token"
						})
					]
				})]
			}),
			msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: msg }) : null
		]
	});
}
function Loja({ desk, onChange }) {
	const [slice, setSlice] = (0, import_react.useState)("fala");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto",
				children: [
					["fala", "Fala"],
					["produtos", "Produtos"],
					["horario", "Horário"],
					["avisos", "Avisos"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSlice(id),
					className: slice === id ? "min-h-11 shrink-0 rounded-full bg-ink px-4 text-sm text-surface" : "min-h-11 shrink-0 rounded-full border border-line bg-surface px-4 text-sm text-ink",
					children: label
				}, id))
			}),
			slice === "fala" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fala, {
				shop: desk.shop,
				onChange
			}) : null,
			slice === "produtos" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Produtos, {
				products: desk.products,
				onChange
			}) : null,
			slice === "horario" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Horario, {
				hours: desk.hours,
				exceptions: desk.exceptions,
				onChange
			}) : null,
			slice === "avisos" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avisos, {
				desk,
				onChange
			}) : null
		]
	});
}
function Fala({ shop, onChange }) {
	const [form, setForm] = (0, import_react.useState)(shop);
	const [msg, setMsg] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save() {
		setBusy(true);
		setMsg("");
		const res = await saveShopFn({ data: form });
		setBusy(false);
		if (!res.ok) setMsg(res.error);
		else {
			setMsg("Salvo.");
			await onChange();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "Como a loja fala",
		hint: "O atendente usa isso em toda conversa. Sem isso, ele não inventa preço nem horário.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nome da loja",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: form.name,
					onChange: (e) => setForm({
						...form,
						name: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nome de quem atende",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: form.attendantName,
					placeholder: "Pode ficar em branco",
					onChange: (e) => setForm({
						...form,
						attendantName: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "O que vocês fazem",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: inputClass,
					rows: 3,
					value: form.about,
					onChange: (e) => setForm({
						...form,
						about: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Jeito de falar",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: inputClass,
					rows: 3,
					value: form.voice,
					onChange: (e) => setForm({
						...form,
						voice: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Fuso",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: inputClass,
					value: form.timezone,
					onChange: (e) => setForm({
						...form,
						timezone: e.target.value
					}),
					children: TIMEZONES.map((zone) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: zone.id,
						children: zone.label
					}, zone.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: btnPrimary,
				disabled: busy,
				onClick: () => void save(),
				children: busy ? "Salvando…" : "Salvar a fala"
			}),
			msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: msg }) : null
		]
	});
}
function Produtos({ products, onChange }) {
	const [form, setForm] = (0, import_react.useState)({
		id: 0,
		name: "",
		price: "",
		unit: "un",
		details: "",
		available: true
	});
	const [msg, setMsg] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save() {
		setBusy(true);
		const res = await saveProductFn({ data: form });
		setBusy(false);
		if (!res.ok) setMsg(res.error);
		else {
			setForm({
				id: 0,
				name: "",
				price: "",
				unit: "un",
				details: "",
				available: true
			});
			setMsg("");
			await onChange();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "Produtos",
		hint: "Preço do jeito que você fala: 10 ou 12,50.",
		children: [
			products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nenhum produto ainda."
			}) : null,
			products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3 border-b border-line pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-medium",
					children: [
						product.name,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-muted",
							children: brl(product.priceCents)
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						product.unit,
						product.available ? "" : " · em falta",
						product.details ? ` · ${product.details}` : ""
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 text-sm text-clay",
					onClick: () => void deleteProductFn({ data: product.id }).then(onChange),
					children: "Tirar"
				})]
			}, product.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Nome",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: form.name,
					onChange: (e) => setForm({
						...form,
						name: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Preço",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						inputMode: "decimal",
						value: form.price,
						onChange: (e) => setForm({
							...form,
							price: e.target.value
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Unidade",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: form.unit,
						onChange: (e) => setForm({
							...form,
							unit: e.target.value
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Detalhe",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: inputClass,
					value: form.details,
					onChange: (e) => setForm({
						...form,
						details: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: btnPrimary,
				disabled: busy,
				onClick: () => void save(),
				children: busy ? "Salvando…" : "Adicionar produto"
			}),
			msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: msg }) : null
		]
	});
}
function Horario({ hours, exceptions, onChange }) {
	const [rows, setRows] = (0, import_react.useState)(hours);
	const [date, setDate] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("fechado");
	const [atTime, setAtTime] = (0, import_react.useState)("14:00");
	const [note, setNote] = (0, import_react.useState)("");
	const [msg, setMsg] = (0, import_react.useState)("");
	async function saveHours() {
		const res = await saveHoursFn({ data: rows });
		if (!res.ok) setMsg(res.error);
		else {
			setMsg("Horário salvo.");
			await onChange();
		}
	}
	async function addEx() {
		const res = await addExceptionFn({ data: {
			onDate: date,
			kind,
			atTime,
			note
		} });
		if (!res.ok) setMsg(res.error);
		else {
			setNote("");
			setMsg("");
			await onChange();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "Horário da semana",
			hint: "Domingo começa fechado. Ajuste do seu jeito.",
			children: [rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 border-b border-line pb-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: WEEKDAY_LABELS[row.weekday]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: row.closed ? btnGhost : btnPrimary,
						onClick: () => setRows(rows.map((item, i) => i === index ? {
							...item,
							closed: !item.closed
						} : item)),
						children: row.closed ? "Fechado neste dia" : "Abre neste dia"
					}),
					row.closed ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"aria-label": `Abre ${WEEKDAY_LABELS[row.weekday]}`,
							className: inputClass,
							type: "time",
							value: row.opens,
							onChange: (e) => setRows(rows.map((item, i) => i === index ? {
								...item,
								opens: e.target.value
							} : item))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"aria-label": `Fecha ${WEEKDAY_LABELS[row.weekday]}`,
							className: inputClass,
							type: "time",
							value: row.closes,
							onChange: (e) => setRows(rows.map((item, i) => i === index ? {
								...item,
								closes: e.target.value
							} : item))
						})]
					})
				]
			}, row.weekday)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: btnPrimary,
				onClick: () => void saveHours(),
				children: "Salvar horário"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "Um dia diferente",
			hint: "Fechar o dia, abrir mais tarde ou fechar mais cedo.",
			children: [
				exceptions.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm leading-6",
						children: [
							item.onDate.split("-").reverse().join("/"),
							" · ",
							item.kind.replace("_", " "),
							item.atTime ? ` ${item.atTime}` : "",
							item.note ? ` · ${item.note}` : ""
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 text-sm text-clay",
						onClick: () => void deleteExceptionFn({ data: item.id }).then(onChange),
						children: "Tirar"
					})]
				}, item.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Data",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						type: "date",
						value: date,
						onChange: (e) => setDate(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "O que muda",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: inputClass,
						value: kind,
						onChange: (e) => setKind(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "fechado",
								children: "Não abre"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "abre_tarde",
								children: "Abre mais tarde"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "fecha_cedo",
								children: "Fecha mais cedo"
							})
						]
					})
				}),
				kind !== "fechado" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Horário",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						type: "time",
						value: atTime,
						onChange: (e) => setAtTime(e.target.value)
					})
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Aviso",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: note,
						placeholder: "Inventário, jogo, feriado…",
						onChange: (e) => setNote(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: btnGhost,
					onClick: () => void addEx(),
					children: "Guardar este dia"
				}),
				msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: msg }) : null
			]
		})]
	});
}
function Avisos({ desk, onChange }) {
	const [body, setBody] = (0, import_react.useState)("");
	const [title, setTitle] = (0, import_react.useState)("");
	const [details, setDetails] = (0, import_react.useState)("");
	const [starts, setStarts] = (0, import_react.useState)("");
	const [ends, setEnds] = (0, import_react.useState)("");
	const [msg, setMsg] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "Promoções relâmpago",
			hint: "Só vale no intervalo. O atendente cita quando a conversa for de preço ou do item, não em toda frase.",
			children: [
				desk.promos.map((promo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-line pb-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: promo.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: promo.details
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: promoIsLive(promo) && promo.active ? "Valendo agora" : promo.active ? "Fora do horário" : "Pausada"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btnGhost,
								onClick: () => void setPromoFn({ data: {
									id: promo.id,
									active: !promo.active
								} }).then(onChange),
								children: promo.active ? "Pausar" : "Ativar"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 px-2 text-sm text-clay",
								onClick: () => void deletePromoFn({ data: promo.id }).then(onChange),
								children: "Tirar"
							})]
						})
					]
				}, promo.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nome da promoção",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: title,
						onChange: (e) => setTitle(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Como é",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						value: details,
						onChange: (e) => setDetails(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Começa",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						type: "datetime-local",
						value: starts,
						onChange: (e) => setStarts(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Termina",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: inputClass,
						type: "datetime-local",
						value: ends,
						onChange: (e) => setEnds(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: btnPrimary,
					onClick: () => void addPromoFn({ data: {
						title,
						details,
						startsLocal: starts,
						endsLocal: ends,
						active: true
					} }).then(async (res) => {
						if (!res.ok) setMsg(res.error);
						else {
							setTitle("");
							setDetails("");
							setMsg("");
							await onChange();
						}
					}),
					children: "Criar promoção"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			title: "Avisos soltos",
			hint: "Algo que o atendente precisa saber hoje, além do horário.",
			children: [
				desk.notices.map((notice) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-6",
						children: notice.body
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 text-sm",
							onClick: () => void setNoticeFn({ data: {
								id: notice.id,
								active: !notice.active
							} }).then(onChange),
							children: notice.active ? "Ativo" : "Pausado"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 text-sm text-clay",
							onClick: () => void deleteNoticeFn({ data: notice.id }).then(onChange),
							children: "Tirar"
						})]
					})]
				}, notice.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Aviso",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: inputClass,
						rows: 2,
						value: body,
						onChange: (e) => setBody(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: btnGhost,
					onClick: () => void addNoticeFn({ data: body }).then(async (res) => {
						if (!res.ok) setMsg(res.error);
						else {
							setBody("");
							await onChange();
						}
					}),
					children: "Guardar aviso"
				}),
				msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Note, { children: msg }) : null
			]
		})]
	});
}
var LABEL = {
	liberado: "Liberado — falta o banco",
	duvida: "Segurou",
	recusado: "Segurou",
	conferido: "Conferido no banco",
	nao_caiu: "Não caiu"
};
function PixPanel({ rows, onChange, onOpen }) {
	const liberados = rows.filter((row) => row.status === "liberado");
	const others = rows.filter((row) => row.status !== "liberado");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Fila do banco"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-6 text-muted",
					children: "O atendente lê data, hora, favorecido, banco e valor. O que ele libera, você confirma no app do banco. Ele nunca diz que o dinheiro já caiu."
				})]
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Nenhum comprovante ainda."
			}) : null,
			[...liberados, ...others].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-pine",
						children: LABEL[row.status] ?? row.status
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display mt-1 text-3xl tabular-nums",
						children: row.amountCents != null ? brl(row.amountCents) : "Valor ?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-1 gap-1 text-sm leading-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Favorecido: ", row.favorecido || "—"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Banco: ", row.banco || "—"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Quando: ", row.paidAtText || row.paidDate || "—"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Pagador: ", row.payerName || "—"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Id: ", row.e2eId || "—"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Cliente: ", row.contactName || row.waId] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-muted",
						children: row.decision
					}),
					row.mediaDataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: row.mediaDataUrl,
						alt: "Comprovante enviado",
						className: "mt-3 max-h-56 rounded-xl border border-line object-contain"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btnPrimary,
								onClick: () => void setReceiptFn({ data: {
									id: row.id,
									status: "conferido"
								} }).then(onChange),
								children: "Conferi no banco"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btnGhost,
								onClick: () => void setReceiptFn({ data: {
									id: row.id,
									status: "nao_caiu"
								} }).then(onChange),
								children: "Não caiu"
							}),
							row.contactId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btnGhost,
								onClick: () => onOpen(row.contactId),
								children: "Abrir conversa"
							}) : null
						]
					})
				]
			}, row.id))
		]
	});
}
function downsample(input, fromRate, toRate) {
	if (fromRate === toRate) return input;
	const ratio = fromRate / toRate;
	const len = Math.max(1, Math.floor(input.length / ratio));
	const out = new Float32Array(len);
	for (let i = 0; i < len; i += 1) {
		const start = Math.floor(i * ratio);
		const end = Math.min(input.length, Math.floor((i + 1) * ratio));
		let sum = 0;
		let n = 0;
		for (let j = start; j < end; j += 1) {
			sum += input[j] ?? 0;
			n += 1;
		}
		out[i] = n ? sum / n : 0;
	}
	return out;
}
function encodeWavPCM(samples, sampleRate) {
	const buffer = /* @__PURE__ */ new ArrayBuffer(44 + samples.length * 2);
	const view = new DataView(buffer);
	const write = (offset, text) => {
		for (let i = 0; i < text.length; i += 1) view.setUint8(offset + i, text.charCodeAt(i));
	};
	write(0, "RIFF");
	view.setUint32(4, 36 + samples.length * 2, true);
	write(8, "WAVE");
	write(12, "fmt ");
	view.setUint32(16, 16, true);
	view.setUint16(20, 1, true);
	view.setUint16(22, 1, true);
	view.setUint32(24, sampleRate, true);
	view.setUint32(28, sampleRate * 2, true);
	view.setUint16(32, 2, true);
	view.setUint16(34, 16, true);
	write(36, "data");
	view.setUint32(40, samples.length * 2, true);
	let offset = 44;
	for (let i = 0; i < samples.length; i += 1) {
		const s = Math.max(-1, Math.min(1, samples[i] ?? 0));
		view.setInt16(offset, s < 0 ? s * 32768 : s * 32767, true);
		offset += 2;
	}
	return new Uint8Array(buffer);
}
function bytesToBase64(bytes) {
	let bin = "";
	const size = 32768;
	for (let i = 0; i < bytes.length; i += size) bin += String.fromCharCode(...bytes.subarray(i, i + size));
	return btoa(bin);
}
function Prova({ timeZone }) {
	const [messages, setMessages] = (0, import_react.useState)([]);
	const [text, setText] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)("");
	const [rec, setRec] = (0, import_react.useState)(false);
	const chunks = (0, import_react.useRef)([]);
	const audio = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		getProvaFn().then(setMessages);
	}, []);
	async function send(payload) {
		setBusy(payload.attachment?.kind === "audio" ? "Ouvindo…" : payload.attachment ? "Lendo…" : "Respondendo…");
		setErr("");
		const res = await provaSendFn({ data: payload });
		setBusy("");
		if (!res.ok) {
			setErr(res.error);
			return;
		}
		setText("");
		setMessages(res.messages);
	}
	async function toggleMic() {
		if (rec && audio.current) {
			const { ctx, stream } = audio.current;
			const rate = ctx.sampleRate;
			stream.getTracks().forEach((track) => track.stop());
			await ctx.close();
			audio.current = null;
			setRec(false);
			const length = chunks.current.reduce((sum, chunk) => sum + chunk.length, 0);
			const merged = new Float32Array(length);
			let offset = 0;
			for (const chunk of chunks.current) {
				merged.set(chunk, offset);
				offset += chunk.length;
			}
			chunks.current = [];
			if (merged.length < rate / 4) {
				setErr("Áudio curto demais.");
				return;
			}
			await send({
				text: "",
				attachment: {
					kind: "audio",
					base64: bytesToBase64(encodeWavPCM(downsample(merged, rate, 16e3), 16e3)),
					mime: "audio/wav",
					filename: "audio.wav"
				}
			});
			return;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			const ctx = new AudioContext();
			await ctx.resume();
			const source = ctx.createMediaStreamSource(stream);
			const processor = ctx.createScriptProcessor(4096, 1, 1);
			const gain = ctx.createGain();
			gain.gain.value = 0;
			processor.onaudioprocess = (event) => {
				chunks.current.push(new Float32Array(event.inputBuffer.getChannelData(0)));
			};
			source.connect(processor);
			processor.connect(gain);
			gain.connect(ctx.destination);
			audio.current = {
				ctx,
				stream
			};
			chunks.current = [];
			setRec(true);
		} catch {
			setErr("Não consegui usar o microfone.");
			setRec(false);
		}
	}
	async function onFile(file, kind) {
		await send({
			text: "",
			attachment: {
				kind,
				base64: await fileToBase64(file),
				mime: file.type || (kind === "pdf" ? "application/pdf" : "application/octet-stream"),
				filename: file.name
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Prova"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-6 text-muted",
					children: "O mesmo atendente das conversas reais. Manda texto, áudio, foto ou PDF. Nada disso sai para um cliente."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bubbles, {
				messages,
				timeZone
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: inputClass,
				rows: 2,
				value: text,
				placeholder: "Escreve como um cliente",
				onChange: (e) => setText(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: btnPrimary,
						disabled: Boolean(busy),
						onClick: () => void send({ text }),
						children: busy || "Mandar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: rec ? "inline-flex min-h-11 items-center rounded-xl bg-clay px-4 text-sm text-clay-ink" : btnGhost,
						onClick: () => void toggleMic(),
						children: rec ? "Parar e enviar áudio" : "Gravar áudio"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: btnGhost,
						children: ["Foto", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "sr-only",
							type: "file",
							accept: "image/*",
							onChange: (e) => {
								const file = e.target.files?.[0];
								e.target.value = "";
								if (file) onFile(file, "image");
							}
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: btnGhost,
						children: ["PDF", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "sr-only",
							type: "file",
							accept: "application/pdf,.pdf",
							onChange: (e) => {
								const file = e.target.files?.[0];
								e.target.value = "";
								if (file) onFile(file, "pdf");
							}
						})]
					})
				]
			}),
			err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-warn",
				children: err
			}) : null
		]
	});
}
function fileToBase64(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => {
			const value = String(reader.result ?? "");
			const index = value.indexOf(",");
			resolve(index >= 0 ? value.slice(index + 1) : value);
		};
		reader.onerror = () => reject(reader.error);
		reader.readAsDataURL(file);
	});
}
var TABS$1 = [
	{
		id: "conversas",
		label: "Conversas",
		icon: MessageCircle
	},
	{
		id: "prova",
		label: "Prova",
		icon: Mic
	},
	{
		id: "loja",
		label: "Loja",
		icon: Store
	},
	{
		id: "pix",
		label: "Pix",
		icon: Receipt
	},
	{
		id: "ligar",
		label: "Ligar",
		icon: Cable
	}
];
function Desk() {
	const [desk, setDesk] = (0, import_react.useState)(null);
	const [receipts, setReceipts] = (0, import_react.useState)([]);
	const [tab, setTab] = (0, import_react.useState)("loja");
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)("");
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	async function reload() {
		try {
			const [next, pix] = await Promise.all([getDesk(), getReceipts()]);
			setDesk(next);
			setReceipts(pix);
			setErr("");
		} catch (error) {
			setErr(error instanceof Error ? error.message : "Não carregou.");
		}
	}
	(0, import_react.useEffect)(() => {
		reload();
		const clock = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 3e4);
		return () => window.clearInterval(clock);
	}, []);
	const state = desk ? openState(clockIn(desk.shop.timezone, now), desk.hours, desk.exceptions) : null;
	const pending = receipts.filter((row) => row.status === "liberado").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-screen w-full max-w-xl flex-col px-4 pb-24 pt-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-pine",
						children: desk?.shop.name || "Sua loja"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl",
						children: "Balcão"
					}),
					state ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: state.open ? "mt-1 text-sm text-pine" : "mt-1 text-sm text-clay",
						children: state.reason
					}) : null
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}), desk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: desk.shop.botEnabled ? "min-h-11 rounded-full bg-pine px-3 text-sm text-pine-ink" : "min-h-11 rounded-full bg-line px-3 text-sm text-ink",
						onClick: () => void setBotFn({ data: !desk.shop.botEnabled }).then(reload),
						children: desk.shop.botEnabled ? "Atendendo" : "Pausado"
					}) : null]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex-1",
				children: [
					!desk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-2xl bg-line" }) : null,
					err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-warn",
						children: err
					}) : null,
					desk && tab === "conversas" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, {
						timeZone: desk.shop.timezone,
						openId,
						onOpen: (id) => {
							setOpenId(id);
							setTab("conversas");
						}
					}) : null,
					desk && tab === "prova" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prova, { timeZone: desk.shop.timezone }) : null,
					desk && tab === "loja" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loja, {
						desk,
						onChange: reload
					}) : null,
					desk && tab === "pix" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixPanel, {
						rows: receipts,
						onChange: reload,
						onOpen: (id) => {
							setOpenId(id);
							setTab("conversas");
						}
					}) : null,
					desk && tab === "ligar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ligar, {
						desk,
						onChange: reload
					}) : null
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "fixed inset-x-0 bottom-0 border-t border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-xl grid-cols-5",
				children: TABS$1.map((item) => {
					const Icon = item.icon;
					const on = tab === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setTab(item.id),
						className: on ? "flex min-h-16 flex-col items-center justify-center gap-1 text-pine" : "flex min-h-16 flex-col items-center justify-center gap-1 text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								size: 20,
								strokeWidth: 1.75
							}), item.id === "pix" && pending > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -right-2 -top-2 h-2.5 w-2.5 rounded-full bg-clay" }) : null]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs",
							children: item.label
						})]
					}, item.id);
				})
			})
		})]
	});
}
var TABS = [
	{
		label: "Conversas",
		icon: MessageCircle
	},
	{
		label: "Prova",
		icon: Mic
	},
	{
		label: "Loja",
		icon: Store
	},
	{
		label: "Pix",
		icon: Receipt
	},
	{
		label: "Ligar",
		icon: Cable
	}
];
function Home() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Opening, {});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Welcome, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, {});
}
function Opening() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-screen w-full max-w-xl flex-col px-4 pb-24 pt-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-pine",
					children: "WhatsApp do comércio"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl",
					children: "Balcão"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-6 text-muted",
					children: "Abrindo o balcão…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-5 rounded-2xl border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "O que entra aqui"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6",
						children: "Produtos, horário, promoção relâmpago, áudio, foto e comprovante de Pix."
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "fixed inset-x-0 bottom-0 border-t border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-xl grid-cols-5",
				children: TABS.map((item) => {
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-16 flex-col items-center justify-center gap-1 text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							size: 20,
							strokeWidth: 1.75
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs",
							children: item.label
						})]
					}, item.label);
				})
			})
		})]
	});
}
//#endregion
export { Home as component };
