import { i as getSql } from "./db-CHKySlAb.mjs";
import { c as parsePriceToCents, o as localInZoneToIso } from "./time-kqQZUT9n.mjs";
import { randomBytes } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/repo.server-Bz69yhlu.js
function clip(value, max) {
	return value.trim().slice(0, max);
}
function iso(value) {
	if (value == null || value === "") return null;
	if (value instanceof Date) return value.toISOString();
	const s = String(value);
	const d = new Date(s);
	return Number.isNaN(d.getTime()) ? s : d.toISOString();
}
function stamp(value) {
	return iso(value) ?? (/* @__PURE__ */ new Date()).toISOString();
}
var ZONES = /* @__PURE__ */ new Set([
	"America/Belem",
	"America/Fortaleza",
	"America/Recife",
	"America/Sao_Paulo",
	"America/Manaus",
	"America/Cuiaba",
	"America/Rio_Branco"
]);
async function ensureShop(userId) {
	const sql = await getSql();
	const token = randomBytes(16).toString("hex");
	await sql`insert into shop (user_id) values (${userId}) on conflict (user_id) do nothing`;
	await sql`insert into wa_connection (user_id, verify_token) values (${userId}, ${token}) on conflict (user_id) do nothing`;
	if (((await sql`select count(*)::int as n from shop_hours where user_id = ${userId}`)[0]?.n ?? 0) > 0) return;
	for (let weekday = 0; weekday < 7; weekday += 1) await sql`
      insert into shop_hours (user_id, weekday, closed, opens, closes)
      values (${userId}, ${weekday}, ${weekday === 0}, '08:00', '18:00')
    `;
}
async function loadDesk(userId) {
	await ensureShop(userId);
	const sql = await getSql();
	const row = (await sql`select name, attendant_name, about, voice, pix_key, pix_favorecido, pix_banco, timezone, bot_enabled from shop where user_id = ${userId}`)[0];
	const shop = {
		name: row?.name ?? "",
		attendantName: row?.attendant_name ?? "",
		about: row?.about ?? "",
		voice: row?.voice ?? "",
		pixKey: row?.pix_key ?? "",
		pixFavorecido: row?.pix_favorecido ?? "",
		pixBanco: row?.pix_banco ?? "",
		timezone: row?.timezone ?? "America/Belem",
		botEnabled: Boolean(row?.bot_enabled)
	};
	const hours = await sql`
    select weekday, closed, opens, closes from shop_hours where user_id = ${userId} order by weekday
  `;
	const exceptions = await sql`
    select id, on_date::text as on_date, kind, at_time, note from shop_exceptions
    where user_id = ${userId} order by on_date desc, id desc limit 40
  `;
	const products = await sql`select id, name, price_cents, unit, details, available from products where user_id = ${userId} order by id desc limit 60`;
	const promos = await sql`select id, title, details, starts_at, ends_at, active from promos where user_id = ${userId} order by id desc limit 30`;
	const notices = await sql`
    select id, body, active from notices where user_id = ${userId} order by id desc limit 30
  `;
	const c = (await sql`select phone_number_id, display_phone, verify_token, access_token, app_secret from wa_connection where user_id = ${userId}`)[0];
	const token = c?.access_token ?? "";
	const connection = {
		phoneNumberId: c?.phone_number_id ?? "",
		displayPhone: c?.display_phone ?? "",
		verifyToken: c?.verify_token ?? "",
		tokenSet: token.length > 0,
		tokenTail: token.length >= 4 ? token.slice(-4) : "",
		secretSet: (c?.app_secret ?? "").length > 0
	};
	return {
		shop,
		hours: hours.map((h) => ({
			weekday: h.weekday,
			closed: Boolean(h.closed),
			opens: h.opens,
			closes: h.closes
		})),
		exceptions: exceptions.map((e) => ({
			id: e.id,
			onDate: String(e.on_date).slice(0, 10),
			kind: e.kind === "abre_tarde" || e.kind === "fecha_cedo" ? e.kind : "fechado",
			atTime: e.at_time,
			note: e.note
		})),
		products: products.map((p) => ({
			id: p.id,
			name: p.name,
			priceCents: p.price_cents,
			unit: p.unit,
			details: p.details,
			available: Boolean(p.available)
		})),
		promos: promos.map((p) => ({
			id: p.id,
			title: p.title,
			details: p.details,
			startsAt: iso(p.starts_at),
			endsAt: iso(p.ends_at),
			active: Boolean(p.active)
		})),
		notices: notices.map((n) => ({
			id: n.id,
			body: n.body,
			active: Boolean(n.active)
		})),
		connection
	};
}
async function saveShop(userId, shop) {
	await ensureShop(userId);
	const zone = ZONES.has(shop.timezone) ? shop.timezone : "America/Belem";
	await (await getSql())`
    update shop set
      name = ${clip(shop.name, 80)},
      attendant_name = ${clip(shop.attendantName, 40)},
      about = ${clip(shop.about, 800)},
      voice = ${clip(shop.voice, 600)},
      pix_key = ${clip(shop.pixKey, 120)},
      pix_favorecido = ${clip(shop.pixFavorecido, 120)},
      pix_banco = ${clip(shop.pixBanco, 80)},
      timezone = ${zone},
      bot_enabled = ${Boolean(shop.botEnabled)}
    where user_id = ${userId}
  `;
}
async function saveHours(userId, hours) {
	await ensureShop(userId);
	const sql = await getSql();
	for (const hour of hours) {
		if (hour.weekday < 0 || hour.weekday > 6) continue;
		const opens = /^\d{2}:\d{2}$/.test(hour.opens) ? hour.opens : "08:00";
		const closes = /^\d{2}:\d{2}$/.test(hour.closes) ? hour.closes : "18:00";
		await sql`
      insert into shop_hours (user_id, weekday, closed, opens, closes)
      values (${userId}, ${hour.weekday}, ${Boolean(hour.closed)}, ${opens}, ${closes})
      on conflict (user_id, weekday) do update
      set closed = excluded.closed, opens = excluded.opens, closes = excluded.closes
    `;
	}
}
async function addException(userId, input) {
	await ensureShop(userId);
	if (!/^\d{4}-\d{2}-\d{2}$/.test(input.onDate)) throw new Error("Data inválida.");
	const kind = input.kind === "abre_tarde" || input.kind === "fecha_cedo" ? input.kind : "fechado";
	const at = /^\d{2}:\d{2}$/.test(input.atTime) ? input.atTime : null;
	const sql = await getSql();
	if (((await sql`select count(*)::int as n from shop_exceptions where user_id = ${userId}`)[0]?.n ?? 0) >= 40) throw new Error("Limite de avisos de data.");
	await sql`
    insert into shop_exceptions (user_id, on_date, kind, at_time, note)
    values (${userId}, ${input.onDate}, ${kind}, ${at}, ${clip(input.note, 240)})
  `;
}
async function deleteException(userId, id) {
	await (await getSql())`delete from shop_exceptions where id = ${id} and user_id = ${userId}`;
}
async function saveProduct(userId, input) {
	await ensureShop(userId);
	const name = clip(input.name, 80);
	if (!name) throw new Error("Dê um nome ao produto.");
	const cents = parsePriceToCents(input.price);
	if (cents == null) throw new Error("Preço inválido.");
	const unit = clip(input.unit, 16) || "un";
	const details = clip(input.details, 300);
	const sql = await getSql();
	if (input.id > 0) {
		await sql`
      update products set name = ${name}, price_cents = ${cents}, unit = ${unit}, details = ${details}, available = ${Boolean(input.available)}
      where id = ${input.id} and user_id = ${userId}
    `;
		return;
	}
	if (((await sql`select count(*)::int as n from products where user_id = ${userId}`)[0]?.n ?? 0) >= 60) throw new Error("Limite de produtos.");
	await sql`
    insert into products (user_id, name, price_cents, unit, details, available)
    values (${userId}, ${name}, ${cents}, ${unit}, ${details}, ${Boolean(input.available)})
  `;
}
async function deleteProduct(userId, id) {
	await (await getSql())`delete from products where id = ${id} and user_id = ${userId}`;
}
async function addPromo(userId, input) {
	await ensureShop(userId);
	const title = clip(input.title, 80);
	if (!title) throw new Error("A promoção precisa de um nome.");
	const sql = await getSql();
	const zone = (await sql`select timezone from shop where user_id = ${userId}`)[0]?.timezone ?? "America/Belem";
	const starts = input.startsLocal ? localInZoneToIso(input.startsLocal, zone) : null;
	const ends = input.endsLocal ? localInZoneToIso(input.endsLocal, zone) : null;
	if (input.startsLocal && !starts) throw new Error("Início da promoção inválido.");
	if (input.endsLocal && !ends) throw new Error("Fim da promoção inválido.");
	if (((await sql`select count(*)::int as n from promos where user_id = ${userId}`)[0]?.n ?? 0) >= 30) throw new Error("Limite de promoções.");
	await sql`
    insert into promos (user_id, title, details, starts_at, ends_at, active)
    values (${userId}, ${title}, ${clip(input.details, 300)}, ${starts}, ${ends}, ${Boolean(input.active)})
  `;
}
async function setPromoActive(userId, id, active) {
	await (await getSql())`update promos set active = ${active} where id = ${id} and user_id = ${userId}`;
}
async function deletePromo(userId, id) {
	await (await getSql())`delete from promos where id = ${id} and user_id = ${userId}`;
}
async function addNotice(userId, body) {
	await ensureShop(userId);
	const text = clip(body, 400);
	if (!text) throw new Error("Escreva o aviso.");
	const sql = await getSql();
	if (((await sql`select count(*)::int as n from notices where user_id = ${userId}`)[0]?.n ?? 0) >= 30) throw new Error("Limite de avisos.");
	await sql`insert into notices (user_id, body) values (${userId}, ${text})`;
}
async function setNoticeActive(userId, id, active) {
	await (await getSql())`update notices set active = ${active} where id = ${id} and user_id = ${userId}`;
}
async function deleteNotice(userId, id) {
	await (await getSql())`delete from notices where id = ${id} and user_id = ${userId}`;
}
async function saveConnection(userId, input) {
	await ensureShop(userId);
	const sql = await getSql();
	const phone = clip(input.phoneNumberId, 40).replace(/\s/g, "");
	const display = clip(input.displayPhone, 40);
	const token = input.accessToken.trim();
	const secret = input.appSecret.trim();
	if (token.length > 0 && token.length > 500) throw new Error("Token longo demais.");
	await sql`
    update wa_connection set
      phone_number_id = ${phone},
      display_phone = ${display},
      access_token = case when ${token} = '' then access_token else ${token} end,
      app_secret = case
        when ${input.clearSecret} then ''
        when ${secret} = '' then app_secret
        else ${secret}
      end
    where user_id = ${userId}
  `;
}
async function setBotEnabled(userId, enabled) {
	await ensureShop(userId);
	await (await getSql())`update shop set bot_enabled = ${enabled} where user_id = ${userId}`;
}
async function loadSecrets(userId) {
	const row = (await (await getSql())`
    select phone_number_id, access_token, app_secret, verify_token from wa_connection where user_id = ${userId}
  `)[0];
	if (!row) return null;
	return {
		phoneNumberId: row.phone_number_id,
		accessToken: row.access_token,
		appSecret: row.app_secret,
		verifyToken: row.verify_token
	};
}
async function userIdByVerifyToken(token) {
	if (!/^[a-f0-9]{32}$/.test(token)) return null;
	return (await (await getSql())`select user_id from wa_connection where verify_token = ${token}`)[0]?.user_id ?? null;
}
async function listThreads(userId) {
	return (await getSql())`
    select c.id, c.wa_id, c.name, c.bot_paused, c.updated_at,
      (select body from messages m where m.contact_id = c.id order by m.id desc limit 1) as preview
    from contacts c
    where c.user_id = ${userId} and c.wa_id <> 'local:prova'
    order by c.updated_at desc
    limit 50
  `;
}
async function listMessages(userId, contactId) {
	const sql = await getSql();
	if (!(await sql`select id from contacts where id = ${contactId} and user_id = ${userId}`)[0]) return [];
	return sql`
    select id, direction, kind, body, created_at from messages
    where contact_id = ${contactId} and user_id = ${userId}
    order by id desc limit 40
  `;
}
async function listReceipts(userId) {
	return (await getSql())`
    select id, contact_id, contact_name, wa_id, payer_name, favorecido, banco, amount_cents,
      paid_at_text, paid_date, e2e_id, confidence, name_matches, decision, status, note,
      case when media_data_url is not null and length(media_data_url) < 500000 then media_data_url else null end as media_data_url,
      created_at
    from receipts where user_id = ${userId}
    order by id desc limit 40
  `;
}
function mapThread(row) {
	return {
		id: row.id,
		waId: row.wa_id,
		name: row.name || row.wa_id,
		botPaused: Boolean(row.bot_paused),
		preview: (row.preview ?? "").slice(0, 140),
		updatedAt: stamp(row.updated_at)
	};
}
function mapMessage(row) {
	return {
		id: row.id,
		direction: row.direction === "out" ? "out" : "in",
		kind: row.kind,
		body: row.body,
		createdAt: stamp(row.created_at)
	};
}
async function setPaused(userId, contactId, paused) {
	await (await getSql())`update contacts set bot_paused = ${paused} where id = ${contactId} and user_id = ${userId}`;
}
async function setReceiptStatus(userId, id, status) {
	if (status !== "conferido" && status !== "nao_caiu" && status !== "liberado") throw new Error("Situação inválida.");
	await (await getSql())`update receipts set status = ${status} where id = ${id} and user_id = ${userId}`;
}
async function loadBundle(userId) {
	const desk = await loadDesk(userId);
	const secrets = await loadSecrets(userId);
	if (!secrets) throw new Error("Ligação do WhatsApp ainda não existe.");
	return {
		...desk,
		secrets
	};
}
async function upsertContact(userId, waId, name) {
	const row = (await (await getSql())`
    insert into contacts (user_id, wa_id, name)
    values (${userId}, ${waId}, ${clip(name, 80)})
    on conflict (user_id, wa_id) do update set
      name = case when excluded.name <> '' then excluded.name else contacts.name end,
      updated_at = now()
    returning id, bot_paused, name, wa_id
  `)[0];
	if (!row) throw new Error("Não consegui abrir a conversa.");
	return {
		id: row.id,
		botPaused: Boolean(row.bot_paused),
		name: row.name,
		waId: row.wa_id
	};
}
async function touchContact(contactId) {
	await (await getSql())`update contacts set updated_at = now() where id = ${contactId}`;
}
async function seenOnce(userId, waMessageId) {
	const rows = await (await getSql())`
    insert into wa_seen (user_id, wa_message_id) values (${userId}, ${waMessageId})
    on conflict do nothing
    returning wa_message_id
  `;
	return Boolean(rows[0]);
}
async function insertMessage(userId, contactId, direction, kind, body) {
	const sql = await getSql();
	if (!(await sql`select id from contacts where id = ${contactId} and user_id = ${userId}`)[0]) throw new Error("Conversa não encontrada.");
	const rows = await sql`
    insert into messages (user_id, contact_id, direction, kind, body)
    values (${userId}, ${contactId}, ${direction}, ${kind}, ${clip(body, 4e3)})
    returning id
  `;
	await touchContact(contactId);
	return rows[0]?.id ?? 0;
}
async function countRecentInbound(contactId) {
	return (await (await getSql())`
    select count(*)::int as n from messages
    where contact_id = ${contactId} and direction = 'in' and created_at > now() - interval '10 minutes'
  `)[0]?.n ?? 0;
}
async function recentHistory(contactId) {
	return (await (await getSql())`
    select direction, body, kind from messages
    where contact_id = ${contactId} and kind <> 'nota'
    order by id desc limit 12
  `).reverse();
}
async function insertReceipt(input) {
	await (await getSql())`
    insert into receipts (
      user_id, contact_id, contact_name, wa_id, payer_name, favorecido, banco, amount_cents,
      paid_at_text, paid_date, e2e_id, confidence, name_matches, decision, status, note, media_data_url
    ) values (
      ${input.userId}, ${input.contactId}, ${clip(input.contactName, 80)}, ${input.waId},
      ${clip(input.payerName, 120)}, ${clip(input.favorecido, 120)}, ${clip(input.banco, 80)},
      ${input.amountCents}, ${clip(input.paidAtText, 40)}, ${clip(input.paidDate, 10)},
      ${clip(input.e2eId, 80)}, ${clip(input.confidence, 20)}, ${input.nameMatches},
      ${clip(input.decision, 400)}, ${input.status}, ${clip(input.note, 400)}, ${input.mediaDataUrl}
    )
  `;
}
async function pauseContact(contactId, userId) {
	await (await getSql())`update contacts set bot_paused = true where id = ${contactId} and user_id = ${userId}`;
}
//#endregion
export { addException, addNotice, addPromo, countRecentInbound, deleteException, deleteNotice, deleteProduct, deletePromo, insertMessage, insertReceipt, listMessages, listReceipts, listThreads, loadBundle, loadDesk, loadSecrets, mapMessage, mapThread, pauseContact, recentHistory, saveConnection, saveHours, saveProduct, saveShop, seenOnce, setBotEnabled, setNoticeActive, setPaused, setPromoActive, setReceiptStatus, upsertContact, userIdByVerifyToken };
