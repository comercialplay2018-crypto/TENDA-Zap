//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CWK4pt-M.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/api/auth/$",
			"/api/whatsapp/webhook/$token"
		],
		preloads: ["/assets/index-DxzCAW9j.js", "/assets/react-DB-4Zxce.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DxzCAW9j.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BQINCOl-.js", "/assets/welcome-BE9S0YmQ.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-d4U6qJDN.js", "/assets/welcome-BE9S0YmQ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
