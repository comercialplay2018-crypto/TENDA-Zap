//#region node_modules/.nitro/vite/services/ssr/assets/time-kqQZUT9n.js
var WEEKDAY_LABELS = [
	"Domingo",
	"Segunda",
	"Terça",
	"Quarta",
	"Quinta",
	"Sexta",
	"Sábado"
];
var TIMEZONES = [
	{
		id: "America/Belem",
		label: "Belém, Macapá"
	},
	{
		id: "America/Fortaleza",
		label: "Fortaleza, Nordeste"
	},
	{
		id: "America/Recife",
		label: "Recife"
	},
	{
		id: "America/Sao_Paulo",
		label: "Brasília, São Paulo"
	},
	{
		id: "America/Manaus",
		label: "Manaus"
	},
	{
		id: "America/Cuiaba",
		label: "Cuiabá"
	},
	{
		id: "America/Rio_Branco",
		label: "Rio Branco"
	}
];
function brl(cents) {
	return (cents / 100).toLocaleString("pt-BR", {
		style: "currency",
		currency: "BRL"
	});
}
function parsePriceToCents(input) {
	const t = input.trim().replace(/\s/g, "").replace(/^R\$/i, "");
	if (!t) return null;
	const normalized = t.includes(",") ? t.replace(/\./g, "").replace(",", ".") : t;
	const n = Number(normalized);
	if (!Number.isFinite(n) || n < 0 || n > 1e6) return null;
	return Math.round(n * 100);
}
var WEEKDAYS_PT = [
	"domingo",
	"segunda",
	"terça",
	"quarta",
	"quinta",
	"sexta",
	"sábado"
];
function parts(date, timeZone) {
	const list = new Intl.DateTimeFormat("en-US", {
		timeZone,
		weekday: "short",
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		hourCycle: "h23"
	}).formatToParts(date);
	const get = (type) => list.find((p) => p.type === type)?.value ?? "";
	return get;
}
function clockIn(timeZone, now = /* @__PURE__ */ new Date()) {
	const get = parts(now, timeZone);
	const map = {
		Sun: 0,
		Mon: 1,
		Tue: 2,
		Wed: 3,
		Thu: 4,
		Fri: 5,
		Sat: 6
	};
	let hour = Number(get("hour"));
	if (hour === 24) hour = 0;
	const minute = Number(get("minute"));
	const weekday = map[get("weekday")] ?? 0;
	const date = `${get("year")}-${get("month")}-${get("day")}`;
	const hh = String(hour).padStart(2, "0");
	const mm = String(minute).padStart(2, "0");
	return {
		weekday,
		date,
		minutes: hour * 60 + minute,
		label: `${WEEKDAYS_PT[weekday]}, ${get("day")}/${get("month")} às ${hh}:${mm}`
	};
}
function shiftDate(date, days) {
	const [y, m, d] = date.split("-").map(Number);
	const dt = new Date(Date.UTC(y, (m ?? 1) - 1, d ?? 1));
	dt.setUTCDate(dt.getUTCDate() + days);
	return dt.toISOString().slice(0, 10);
}
function hmToMinutes(hm) {
	const [h, m] = hm.split(":").map(Number);
	if (!Number.isFinite(h) || !Number.isFinite(m)) return 0;
	return h * 60 + m;
}
function fmt(mins) {
	const h = Math.floor(mins / 60);
	const m = mins % 60;
	return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}
function openState(clock, hours, exceptions) {
	const ex = exceptions.find((e) => e.onDate === clock.date);
	const today = hours.find((h) => h.weekday === clock.weekday);
	if (ex?.kind === "fechado") return {
		open: false,
		reason: ex.note ? `Não abre hoje. ${ex.note}` : "Não abre hoje."
	};
	if (!today || today.closed) return {
		open: false,
		reason: "Fechado neste dia da semana."
	};
	let opens = hmToMinutes(today.opens);
	let closes = hmToMinutes(today.closes);
	if (ex?.kind === "abre_tarde" && ex.atTime) opens = hmToMinutes(ex.atTime);
	if (ex?.kind === "fecha_cedo" && ex.atTime) closes = hmToMinutes(ex.atTime);
	const span = `${fmt(opens)}–${fmt(closes)}`;
	const note = ex?.note ? ` ${ex.note}` : "";
	if (clock.minutes >= opens && clock.minutes < closes) return {
		open: true,
		reason: `Aberto agora. Hoje: ${span}.${note}`
	};
	if (clock.minutes < opens) return {
		open: false,
		reason: `Ainda fechado. Abre às ${fmt(opens)}.${note}`
	};
	return {
		open: false,
		reason: `Já fechou. Hoje era ${span}.${note}`
	};
}
function localInZoneToIso(local, timeZone) {
	if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(local)) return null;
	const asUtc = (/* @__PURE__ */ new Date(`${local}:00Z`)).getTime();
	if (Number.isNaN(asUtc)) return null;
	const get = parts(new Date(asUtc), timeZone);
	let hour = Number(get("hour"));
	if (hour === 24) hour = 0;
	const offset = Date.UTC(Number(get("year")), Number(get("month")) - 1, Number(get("day")), hour, Number(get("minute"))) - asUtc;
	return new Date(asUtc - offset).toISOString();
}
function formatStamp(iso, timeZone) {
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return "";
	const get = parts(d, timeZone);
	let hour = Number(get("hour"));
	if (hour === 24) hour = 0;
	return `${get("day")}/${get("month")} ${String(hour).padStart(2, "0")}:${get("minute")}`;
}
function promoIsLive(promo, now = /* @__PURE__ */ new Date()) {
	if (!promo.active) return false;
	if (promo.startsAt && new Date(promo.startsAt).getTime() > now.getTime()) return false;
	if (promo.endsAt && new Date(promo.endsAt).getTime() < now.getTime()) return false;
	return true;
}
//#endregion
export { formatStamp as a, parsePriceToCents as c, clockIn as i, promoIsLive as l, WEEKDAY_LABELS as n, localInZoneToIso as o, brl as r, openState as s, TIMEZONES as t, shiftDate as u };
