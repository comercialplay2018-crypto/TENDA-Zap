import { o as __toESM } from "../_runtime.mjs";
import { J as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn, t as authClient } from "./client-IWHfIGH2.mjs";
import { t as GROK_PROVIDERS } from "./server-u-bqf-jA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/welcome-BDmmblnC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	return useSessionUserState();
}
function useSessionUserState() {
	const { data, isPending } = authClient.useSession();
	const id = data?.user.id;
	const displayName = data?.user.name ?? null;
	const primaryEmail = data?.user.email ?? null;
	const profileImageUrl = data?.user.image ?? null;
	const user = (0, import_react.useMemo)(() => id ? {
		id,
		displayName,
		primaryEmail,
		profileImageUrl,
		isDevFallback: false
	} : null, [
		id,
		displayName,
		primaryEmail,
		profileImageUrl
	]);
	return (0, import_react.useMemo)(() => ({
		user,
		isPending
	}), [user, isPending]);
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
function Welcome() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-screen w-full max-w-xl flex-col gap-6 px-5 py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium tracking-wide text-pine",
					children: "WhatsApp do comércio"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display mt-2 text-5xl text-ink",
					children: "Balcão"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-lg leading-7 text-ink",
					children: "Um atendente que fala solto, lê áudio, foto e comprovante de Pix, e responde no WhatsApp de verdade."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 rounded-2xl border border-line bg-sand p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-[85%] rounded-2xl rounded-tl-md bg-surface px-3 py-2 text-sm leading-6",
						children: "tem a promoção da lata ainda?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ml-auto max-w-[85%] rounded-2xl rounded-tr-md bg-moss px-3 py-2 text-sm leading-6",
						children: "tem sim, as três por dez até as 18h. quer que eu separe quantas?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-[85%] rounded-2xl rounded-tl-md bg-surface px-3 py-2 text-sm leading-6",
						children: "áudio: manda duas geladas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ml-auto max-w-[85%] rounded-2xl rounded-tr-md bg-moss px-3 py-2 text-sm leading-6",
						children: "duas então. quando mandar o Pix, manda o comprovante que eu olho na hora."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "flex flex-col gap-3 text-sm leading-6 text-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Cadastra produto, horário, promoção relâmpago e o dia que vai abrir mais tarde ou nem abrir." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Áudio vira texto. Foto e PDF de Pix mostram valor, hora, favorecido e banco." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Ele libera o que parece certo. Você só confere no app do banco o que foi liberado." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-2 pb-8 md:mt-auto",
				children: GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => signIn(provider.providerId, { callbackURL: "/" }),
					className: "inline-flex min-h-11 items-center justify-center rounded-xl bg-pine px-4 text-sm font-medium text-pine-ink",
					children: ["Entrar com ", provider.label]
				}, provider.providerId))
			})
		]
	});
}
//#endregion
export { useCurrentUser as n, useCurrentUserState as r, Welcome as t };
